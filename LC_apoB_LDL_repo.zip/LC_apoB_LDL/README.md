# ApoB–LDL-C discordance in the LipidCardio cohort

Analysis code for: *Discordantly high apolipoprotein B in patients undergoing elective coronary angiography* (LipidCardio, n = 926).

**No patient data are stored in this repository.** The LipidCardio data are available from the study team on reasonable request.

## How to run

1. Set the two paths at the top of `R/analysis.R`:
   - `DATA` – the LipidCardio follow-up export (CSV)
   - `OUT`  – folder for tables and figures (kept outside this repository)
2. Run `R/analysis.R` first (reads the CSV, derives all variables, saves `an.rds` to `OUT`).
3. Then run any analysis script in a clean session:

| Script | Content |
|---|---|
| `01_table1.R` | Table 1, baseline characteristics |
| `02_prevalence_du.R` | Prevalence of discordance (percentile gap; residual method as sensitivity) |
| `03d_extent_all.R`, `03e_spline_gap.R` | Coronary disease extent |
| `04_mace_final.R`, `04d_spline_mace.R` | 3-year MACE (death, MI, stroke): KM, Cox models, sensitivity |
| `08_pwv.R`, `09_vessels.R` | Pulse-wave velocity; vessel-level data |
| `10_text_numbers.R`, `10b_pvalues.R` | Numbers and p-values reported in the text |
| `11_sex.R` | Sex-specific analysis (exploratory) |
| `12_additional.R` | Residual-definition MACE, subgroups, non-HDL-C |
| `FIGURE1.R`, `FIGURE2.R` | Main figures |
| `DAG.R` | Directed acyclic graph for covariate selection |

`R/archive/` holds superseded scripts (earlier median-split and rapid-communication versions), kept for traceability.
`mockups/` holds Python scripts for mock figures and the graphical abstract (illustrative data only).

## Key definitions

- **Discordance (primary):** percentile gap = apoB percentile − LDL-C percentile; > +10 discordantly high, < −10 discordantly low.
- **Sensitivity:** residual method (apoB regressed on LDL-C, ±1 SD).
- **MACE:** death, myocardial infarction or stroke within 3 years; HF hospitalisation only in sensitivity analysis.

## Software

R ≥ 4.3; packages: dplyr, ggplot2, patchwork, survival, splines, rms, mice, relaimpo.
