# =============================================================================
# Coronary disease extent - WHOLE COHORT, no subgroups, no exclusions beyond a
# missing vessel count. Primary definition: percentile gap (Du et al.).
# Complete-case analysis. Run after analysis.R.
# =============================================================================

library(dplyr); library(ggplot2)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
# Use the current cohort; reload the cache if the session copy is incomplete.
if (!exists("an")) an <- readRDS(out("an.rds"))

# The exposure and treatment variables are derived here if they are absent,
# so this script does not depend on having the latest copy of analysis.R.
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
if (!all(c("gap_z", "du") %in% names(an)))
  an <- an %>% mutate(
    gap   = pctile(apob_mgdl) - pctile(ldl),
    gap_z = gap / sd(gap, na.rm = TRUE),
    du    = factor(case_when(gap >  10 ~ "Discordantly high apoB",
                             gap < -10 ~ "Discordantly low apoB",
                             TRUE      ~ "Concordant"),
                   levels = c("Concordant", "Discordantly high apoB",
                              "Discordantly low apoB")))
if (!"llt" %in% names(an))
  an <- an %>% mutate(llt = factor(case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
      on_statin & high                 ~ "High-intensity statin",
      on_statin                        ~ "Moderate-intensity statin",
      TRUE                             ~ "No lipid-lowering therapy"),
    levels = c("No lipid-lowering therapy", "Moderate-intensity statin",
               "High-intensity statin", "Other lipid-lowering therapy")))

# These must come from analysis.R section 1b; if absent, that section has not run.
NEED <- c("obstr", "mvd", "female", "dm", "htn", "smoke", "age")
miss <- setdiff(NEED, names(an))
if (length(miss)) stop("Missing from `an`: ", paste(miss, collapse = ", "),
                       ". Your analysis.R does not contain section 1b - use the latest copy.")
message("Groups: "); print(table(an$du)); print(table(an$llt, useNA = "ifany"))

COV <- "I(age/10) + female + dm + htn + smoke + llt"      # age per 10 years
EXP <- list(c("du", "^du"), c("gap_z", "^gap_z"))

fit1 <- function(o, e, adj) {
  # Unadjusted and adjusted models use the SAME patients - those with complete
  # covariates - so that any difference between them reflects adjustment, not a
  # change in sample.
  dat <- an[complete.cases(an[c(o, e[1], "age", "female", "dm", "htn",
                                "smoke", "llt")]), ]
  f <- paste(o, "~", e[1], if (adj) paste("+", COV) else "")
  m <- glm(as.formula(f), binomial, data = dat)
  s <- summary(m)$coefficients; j <- grepl(e[2], rownames(s))
  data.frame(outcome = o, model = if (adj) "Adjusted" else "Unadjusted",
             term = rownames(s)[j], or = exp(s[j, 1]),
             lo = exp(s[j, 1] - 1.96*s[j, 2]), hi = exp(s[j, 1] + 1.96*s[j, 2]),
             p = s[j, 4], n = nobs(m), events = sum(m$y))
}

fits <- bind_rows(lapply(c("obstr", "mvd"), function(o)
          bind_rows(lapply(EXP, function(e)
            bind_rows(fit1(o, e, FALSE), fit1(o, e, TRUE)))))) %>%
  mutate(outcome  = recode(outcome, obstr = "Obstructive CAD",
                           mvd = "Multivessel disease"),
         exposure = recode(sub("^du", "", term), gap_z = "Percentile gap, per SD"),
         model    = factor(model, c("Unadjusted", "Adjusted")),
         lab  = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < .001, "p < 0.001", sprintf("p = %.3f", p)))
rownames(fits) <- NULL

message("\n=== Disease extent, whole cohort. Reference: concordant. ===")
message("Adjusted: age, sex, diabetes, hypertension, smoking, lipid-lowering therapy.")
print(fits %>% select(outcome, exposure, model, lab, plab, n, events), row.names = FALSE)
write.csv(fits, out("TABLE_extent_all.csv"), row.names = FALSE)

# --- figure -------------------------------------------------------------------
# One row per estimate, so the printed numbers never collide. The exposure is
# named once per pair; unadjusted and adjusted are told apart by colour only.
# One tick and one label per exposure; the two models sit just above and below
# it, told apart by colour, so the printed numbers never collide.
ex  <- unique(fits$exposure)
pos <- setNames(rev(seq_along(ex)), ex)                  # first exposure at top
pf  <- fits %>% mutate(y = pos[exposure] + ifelse(model == "Unadjusted", .18, -.18))
xhi <- max(pf$hi)

FIG <- ggplot(pf, aes(or, y, colour = model)) +
  geom_vline(xintercept = 1, linetype = "22", colour = "grey55") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .12,
                linewidth = .6) +
  geom_point(size = 2.6) +
  geom_text(aes(label = paste0(lab, "   ", plab)), x = log10(xhi * 1.12),
            hjust = 0, size = 3.3, colour = "grey20", show.legend = FALSE) +
  facet_wrap(~ outcome, ncol = 1) +
  scale_y_continuous(breaks = pos, labels = names(pos),
                     expand = expansion(add = .45)) +
  scale_colour_manual(values = c(Unadjusted = "grey60", Adjusted = "#0072B2")) +
  scale_x_log10(limits = c(min(pf$lo) * .9, xhi * 2.6)) +
  labs(x = "Odds ratio (vs concordant)", y = NULL) +
  theme_bw(12) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       legend.position = "top", legend.title = element_blank(),
                       strip.text = element_text(face = "bold", hjust = 0))
ggsave(out("FIGURE_extent_all.png"), FIG, width = 10, height = 6, dpi = 300)
message("Written: TABLE_extent_all.csv and FIGURE_extent_all.png")
