# =============================================================================
# Prevalence of apoB-LDL-C discordance - PRIMARY: percentile gap (Du et al.)
#   gap = apoB percentile - LDL-C percentile; > +10 high, < -10 low
# Residual method (Cole et al.) shown underneath as sensitivity analysis.
# Overall, by lipid-lowering therapy, and among patients at LDL-C target.
# Replaces section 1 of 07_prevalence_phenotypes.R (residual only).
# Run after analysis.R.
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))
stopifnot(c("du", "disc", "llt") %in% names(an))

wil <- function(k, n) { p <- k/n; z <- 1.96; d0 <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d0; m <- (p + z^2/(2*n))/d0
  c(pct = 100*p, lo = 100*max(0, m-h), hi = 100*min(1, m+h)) }

FLAG <- list(
  "Percentile gap: discordantly high apoB" = an$du == "Discordantly high apoB",
  "Percentile gap: discordantly low apoB"  = an$du == "Discordantly low apoB",
  "Residual (sensitivity): apoB high"      = an$disc == "apoB high",
  "Residual (sensitivity): apoB low"       = an$disc == "apoB low")

GRP <- c(list(Overall = rep(TRUE, nrow(an))),
         setNames(lapply(levels(an$llt), function(l) an$llt == l), levels(an$llt)),
         list("LDL-C < 70 mg/dL" = an$ldl < 70, "LDL-C < 55 mg/dL" = an$ldl < 55))

prev <- bind_rows(lapply(names(FLAG), function(f) bind_rows(lapply(names(GRP), function(g) {
  x <- FLAG[[f]][GRP[[g]] %in% TRUE]; x <- x[!is.na(x)]; ci <- wil(sum(x), length(x))
  data.frame(definition = f, group = g, k = sum(x), n = length(x),
             pct = ci[["pct"]], lo = ci[["lo"]], hi = ci[["hi"]])
})))) %>% mutate(group = factor(group, names(GRP)),
                 txt = sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, pct, lo, hi))

TABLE_prev <- prev %>% select(definition, group, txt) %>%
  pivot_wider(names_from = group, values_from = txt) %>% as.data.frame()
print(TABLE_prev, right = FALSE, row.names = FALSE)
write.csv(TABLE_prev, out("TABLE_prevalence_du.csv"), row.names = FALSE)

# difference across lipid-lowering therapy (simulated p: "Other" has few patients)
set.seed(1)
message(sprintf("Percentile gap category across LLT: p = %.3g",
  chisq.test(table(an$llt, an$du), simulate.p.value = TRUE, B = 1e4)$p.value))

# figure: primary definition only; "Other LLT" left out (n too small for a CI)
pf <- prev %>% filter(grepl("^Percentile", definition),
                      group != "Other lipid-lowering therapy") %>%
  mutate(direction = sub("Percentile gap: d", "D", definition),
         group = droplevels(group))
nlab <- pf %>% distinct(group, n) %>% mutate(lab = paste0(group, "\n(n = ", n, ")"))

FIG <- ggplot(pf, aes(group, pct, fill = direction)) +
  geom_col(position = position_dodge(.75), width = .66) +
  geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(.75),
                width = .15, colour = "grey30", linewidth = .5) +
  geom_text(aes(y = hi + 1, label = sprintf("%.1f", pct)),
            position = position_dodge(.75), size = 3.8, colour = "grey20") +
  scale_fill_manual(values = c("Discordantly high apoB" = "#D55E00",
                               "Discordantly low apoB"  = "#0072B2")) +
  scale_x_discrete(labels = setNames(nlab$lab, nlab$group)) +
  scale_y_continuous(expand = expansion(mult = c(0, .12))) +
  labs(x = NULL, y = "Prevalence (%)") +
  theme_bw(13) + theme(legend.position = "top", legend.title = element_blank(),
                       panel.grid.minor = element_blank(),
                       panel.grid.major.x = element_blank())
ggsave(out("FIGURE_prevalence_du.png"), FIG, width = 10, height = 5.5, dpi = 300)
