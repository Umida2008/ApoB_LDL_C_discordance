# =============================================================================
# MACE (3-point: death, MI, stroke), 3-year follow-up. Percentile gap (Du).
# Prints every number for the MACE paragraph and draws the figure
# (cumulative incidence + hazard ratios). Replaces 04c_mace_all.R.
# Run after analysis.R (clean session).
# =============================================================================
library(dplyr); library(survival); library(ggplot2); library(patchwork)
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("an"))  an  <- readRDS(file.path(OUT, "an.rds"))
stopifnot("mace4" %in% names(an))          # else an comes from an old analysis.R

num <- function(x) suppressWarnings(as.numeric(as.character(x)))
fp  <- function(p) ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))
has <- function(x) !is.na(x) & trimws(as.character(x)) != ""
GRP <- c("Concordant", "Discordantly high apoB", "Discordantly low apoB")
PAL <- setNames(c("grey45", "#D55E00", "#0072B2"), GRP)
COV <- "+ I(age/10) + female + dm + htn + smoke + llt"

cc <- an %>% mutate(time = num(mace_yrs), event = num(mace)) %>%
  filter(!is.na(time), !is.na(event), time > 0) %>%
  filter(complete.cases(across(c(age, female, dm, htn, smoke, llt))))

# --- 1  events -------------------------------------------------------------------
cat(sprintf("n = %d; MACE %d (%.1f%%): deaths %d, MI %d, strokes %d (a patient can have >1)\n",
            nrow(cc), sum(cc$event), 100*mean(cc$event),
            sum(has(cc$death)), sum(has(cc$fu_mi_day)), sum(has(cc$stroke))))
print(cc %>% group_by(du) %>% summarise(n = n(), events = sum(event), .groups = "drop"))

# --- 2  cumulative incidence at 3 years + log-rank -------------------------------
km <- survfit(Surv(time, event) ~ du, cc)
s3 <- summary(km, times = 3, extend = TRUE)
ci <- data.frame(group = sub("du=", "", s3$strata), pct = 100*(1 - s3$surv),
                 lo = 100*(1 - s3$upper), hi = 100*(1 - s3$lower))
print(ci %>% mutate(across(-group, ~ round(.x, 1))))
lr <- survdiff(Surv(time, event) ~ du, cc)
p_lr <- pchisq(lr$chisq, length(lr$n) - 1, lower.tail = FALSE)
cat(sprintf("Log-rank p %s\n", fp(p_lr)))

# --- 3  Cox models: unadjusted / adjusted, groups and gap per SD ------------------
hr <- function(f, data = cc) {
  m <- coxph(as.formula(f), data); s <- summary(m)
  j <- grep("^du|^gap_z", rownames(s$coefficients))
  data.frame(term = sub("^du", "", sub("^gap_z$", "Percentile gap, per SD", rownames(s$coefficients)[j])),
             hr = s$conf.int[j, 1], lo = s$conf.int[j, 3], hi = s$conf.int[j, 4],
             p = s$coefficients[j, 5], n = m$n, events = m$nevent)
}
fits <- bind_rows(
  mutate(bind_rows(hr("Surv(time, event) ~ du"), hr("Surv(time, event) ~ gap_z")), model = "Unadjusted"),
  mutate(bind_rows(hr(paste("Surv(time, event) ~ du", COV)),
                   hr(paste("Surv(time, event) ~ gap_z", COV))), model = "Adjusted"))
cat("\n=== Hazard ratios vs concordant ===\n")
with(fits, cat(sprintf("%-10s %-24s %.2f (%.2f-%.2f)  p %s\n", model, term, hr, lo, hi, fp(p)), sep = ""))
write.csv(fits, file.path(OUT, "TABLE_mace.csv"), row.names = FALSE)

# --- 4  sensitivity analyses ---------------------------------------------------------
cat("\n=== Sensitivity ===\n")
s1 <- hr(paste("Surv(time, event) ~ du", COV, "+ mvd"), cc[!is.na(cc$mvd), ])
cat("+ multivessel disease:\n")
with(s1, cat(sprintf("  %-24s %.2f (%.2f-%.2f)  p %s\n", term, hr, lo, hi, fp(p)), sep = ""))
c4 <- an %>% mutate(time = num(mace4_yrs), event = num(mace4)) %>%
  filter(!is.na(time), !is.na(event), time > 0) %>%
  filter(complete.cases(across(c(age, female, dm, htn, smoke, llt))))
s2 <- hr(paste("Surv(time, event) ~ du", COV), c4)
cat(sprintf("MACE + heart-failure hospitalisation (n = %d, %d events):\n", s2$n[1], s2$events[1]))
with(s2, cat(sprintf("  %-24s %.2f (%.2f-%.2f)  p %s\n", term, hr, lo, hi, fp(p)), sep = ""))
print(cox.zph(coxph(as.formula(paste("Surv(time, event) ~ du", COV)), cc)))   # proportional hazards

# --- 5  figure: cumulative incidence (left) + hazard ratios (right) ---------------
g  <- sub("du=", "", names(km$strata))
kd <- bind_rows(data.frame(time = 0, cum = 0, du = g),
                data.frame(time = km$time, cum = 100*(1 - km$surv), du = rep(g, km$strata))) %>%
  mutate(du = factor(du, GRP))
th <- theme_bw(15) + theme(panel.grid.minor = element_blank(),
                           text = element_text(colour = "black"),
                           axis.text = element_text(colour = "black"),
                           plot.tag = element_text(face = "bold", size = 18))
A <- ggplot(kd, aes(time, cum, colour = du)) + geom_step(linewidth = 1) +
  annotate("text", x = 0, y = Inf, hjust = 0, vjust = 1.5, size = 4.5,
           label = sprintf("Log-rank p %s", fp(p_lr))) +
  scale_colour_manual(values = PAL, name = NULL) +
  scale_x_continuous(breaks = 0:3, limits = c(0, 3)) +
  labs(x = "Years since index angiography", y = "Cumulative incidence of MACE (%)", tag = "A") +
  guides(colour = guide_legend(ncol = 1)) + th + theme(legend.position = "top")

ex  <- unique(fits$term); pos <- setNames(rev(seq_along(ex)), ex)
pf  <- fits %>% mutate(y = pos[term] + ifelse(model == "Unadjusted", .17, -.17))
B <- ggplot(pf, aes(hr, y, colour = factor(model, c("Unadjusted", "Adjusted")))) +
  geom_vline(xintercept = 1, linetype = "22", colour = "grey40") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .15, linewidth = .7) +
  geom_point(size = 3) +
  scale_y_continuous(breaks = pos, labels = names(pos), expand = expansion(add = .5)) +
  scale_x_log10() +
  scale_colour_manual(values = c(Unadjusted = "grey60", Adjusted = "#0072B2"), name = NULL) +
  labs(x = sprintf("Hazard ratio for MACE vs concordant\n(n = %d, %d events)",
                   nrow(cc), sum(cc$event)), y = NULL, tag = "B") +
  th + theme(legend.position = "top", panel.grid.major.y = element_blank())
ggsave(file.path(OUT, "FIGURE_mace.png"), (A | B) + plot_layout(widths = c(1.2, 1)),
       width = 15, height = 6.5, dpi = 300)
message("Written: TABLE_mace.csv and FIGURE_mace.png")
