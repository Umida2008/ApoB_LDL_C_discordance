# =============================================================================
# Vessel territory (interveniertes_gef) - exploratory, PCI patients only.
# Codebook: checkbox, shown only if khk_intervention = 1; records the treated
# vessel AND other vessels with >= 50% stenosis (not separable).
#   ___1 RCA  ___2 RIVA (LAD)  ___3 RCX  ___4 other  ___5 unknown
# Outcome here: LAD involvement. Run after analysis.R.
# =============================================================================
library(dplyr)
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("an"))  an  <- readRDS(file.path(OUT, "an.rds"))
num <- function(x) suppressWarnings(as.numeric(as.character(x)))
cb  <- function(k) num(an[[paste0("interveniertes_gef___", k)]]) %in% 1

v <- an %>% mutate(pci = num(khk_intervention) == 1,
                   rca = cb(1), lad = cb(2), rcx = cb(3), unk = cb(5),
                   n_terr = rca + lad + rcx) %>%
  filter(pci %in% TRUE, !unk, n_terr > 0)
message(sprintf("PCI with a known territory: n = %d of %d", nrow(v), nrow(an)))
print(v %>% group_by(du) %>% summarise(n = n(), LAD = round(100*mean(lad), 1),
        RCA = round(100*mean(rca), 1), RCX = round(100*mean(rcx), 1), .groups = "drop"))

# consistency with the vessel count at the index angiography
print(table(territories = v$n_terr, khk_status_akt = v$n_vessel, useNA = "ifany"))

m <- glm(lad ~ du + I(age/10) + female + dm + htn + smoke + llt, binomial, v)
print(round(exp(cbind(OR = coef(m), confint.default(m)))[grep("^du", names(coef(m))), ], 2))
