# =============================================================================
# Pulse wave velocity (PWV) and apoB-LDL-C discordance (percentile gap, Du).
# PWV = mean of right and left arm (pwv_re, pwv_li, m/s); one arm if only one.
# Linear regression, difference in PWV (m/s) vs concordant, and per SD of gap:
#   M1 unadjusted
#   M2 + age, sex, systolic BP, heart rate   (the main determinants of PWV)
#   M3 + diabetes, smoking, lipid-lowering therapy, BMI, eGFR   (DAG set)
# All models on the same complete-case sample. Run after analysis.R.
# =============================================================================

library(dplyr); library(ggplot2)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num <- function(x) suppressWarnings(as.numeric(gsub(",", ".", as.character(x))))
PAL <- c("Concordant" = "grey55", "Discordantly high apoB" = "#D55E00",
         "Discordantly low apoB" = "#0072B2")

pw <- an %>% mutate(
  re  = num(pwv_re), li = num(pwv_li),
  re  = ifelse(re >= 3 & re <= 25, re, NA),          # implausible values out
  li  = ifelse(li >= 3 & li <= 25, li, NA),
  pwv = rowMeans(cbind(re, li), na.rm = TRUE),
  pwv = ifelse(is.nan(pwv), NA, pwv),
  sbp = num(rrsyst_re), hr = num(puls_gemessen), bmi = num(bmi))

message(sprintf("PWV available in %d of %d; right-left correlation r = %.2f",
                sum(!is.na(pw$pwv)), nrow(pw), cor(pw$re, pw$li, use = "complete.obs")))
print(pw %>% filter(!is.na(pwv)) %>% group_by(du) %>%
        summarise(n = n(), median = median(pwv),
                  IQR = sprintf("%.1f-%.1f", quantile(pwv, .25), quantile(pwv, .75)),
                  .groups = "drop"))
message(sprintf("Kruskal-Wallis p = %.3g", kruskal.test(pwv ~ du, pw)$p.value))

# --- models ---------------------------------------------------------------------
M <- list(M1 = "",
          M2 = "+ age + female + sbp + hr",
          M3 = "+ age + female + sbp + hr + dm + smoke + llt + bmi + egfr")
cc <- pw[complete.cases(pw[c("pwv", "du", "gap_z", "age", "female", "sbp", "hr",
                             "dm", "smoke", "llt", "bmi", "egfr")]), ]
message(sprintf("Complete-case sample for all models: n = %d", nrow(cc)))

fit1 <- function(e, m) {
  s <- summary(lm(as.formula(paste("pwv ~", e, M[[m]])), cc))$coefficients
  j <- grep(paste0("^", e), rownames(s))
  data.frame(model = m, term = sub("^du", "", sub("^gap_z$", "Percentile gap, per SD", rownames(s)[j])),
             beta = s[j, 1], lo = s[j, 1] - 1.96*s[j, 2], hi = s[j, 1] + 1.96*s[j, 2],
             p = s[j, 4], n = nrow(cc))
}
TAB <- bind_rows(lapply(names(M), function(m) bind_rows(fit1("du", m), fit1("gap_z", m)))) %>%
  mutate(txt = sprintf("%.2f (%.2f to %.2f), p %s", beta, lo, hi,
                       ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))))
rownames(TAB) <- NULL
message("\nDifference in PWV (m/s) vs concordant; gap per SD")
print(TAB %>% select(model, term, txt), row.names = FALSE)
write.csv(TAB, out("TABLE_pwv.csv"), row.names = FALSE)

# --- figure: PWV by group ---------------------------------------------------------
FIG <- ggplot(pw %>% filter(!is.na(pwv)), aes(du, pwv, colour = du)) +
  geom_jitter(width = .2, height = 0, size = .9, alpha = .5) +
  geom_boxplot(outlier.shape = NA, fill = NA, width = .5, colour = "grey20") +
  scale_colour_manual(values = PAL) +
  labs(x = NULL, y = "Pulse wave velocity (m/s)") +
  theme_bw(12) + theme(legend.position = "none", panel.grid.minor = element_blank(),
                       panel.grid.major.x = element_blank())
ggsave(out("FIGURE_pwv.png"), FIG, width = 6, height = 4.5, dpi = 300)
message("Written: TABLE_pwv.csv and FIGURE_pwv.png")
