# =============================================================================
# DAG for discordantly high apoB -> CAD extent / MACE.
# Prints the minimal sufficient adjustment sets and saves DAG.png.
# install.packages("dagitty") once.
# =============================================================================
library(dagitty)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"

dag <- dagitty('dag {
  Disc     [exposure, pos="0,0"]
  Extent   [pos="3.2,0"]
  MACE     [outcome, pos="6.4,0"]
  TG       [pos="-2.6,-1"]
  Lpa      [pos="-2.6,1"]
  Age      [pos="-1.6,-3.2"]
  Sex      [pos="0.2,-3.2"]
  Obesity  [pos="2,-3.2"]
  DM       [pos="3.8,-3.2"]
  Smoking  [pos="5.6,-3.2"]
  LLT      [pos="0.2,3.2"]
  PriorCAD [pos="2,3.2"]
  HTN      [pos="3.8,3.2"]
  CKD      [pos="5.6,3.2"]

  Age      -> {Disc DM HTN CKD LLT PriorCAD Extent MACE}
  Sex      -> {Disc Obesity LLT Extent MACE}
  Obesity  -> {DM HTN TG Extent MACE}
  DM       -> {TG LLT CKD Extent MACE}
  HTN      -> {CKD LLT Extent MACE}
  Smoking  -> {TG Extent MACE}
  CKD      -> {TG Extent MACE}
  PriorCAD -> {LLT Extent MACE}
  LLT      -> {Disc Extent MACE}
  TG       -> Disc
  Lpa      -> Disc
  Disc     -> {Extent MACE}
  Extent   -> MACE
}')

# disease extent: outcome = Extent; MACE: total effect, Extent is a mediator
print(adjustmentSets(dag, "Disc", "Extent", type = "minimal"))
print(adjustmentSets(dag, "Disc", "MACE",   type = "minimal"))

# is the set used so far sufficient?
cur <- c("Age", "Sex", "DM", "HTN", "Smoking", "LLT")
message("Current set sufficient for extent: ", isAdjustmentSet(dag, cur, "Disc", "Extent"))
message("+ Obesity + CKD sufficient:        ",
        isAdjustmentSet(dag, c(cur, "Obesity", "CKD"), "Disc", "Extent"))

png(file.path(OUT, "DAG.png"), width = 2200, height = 1400, res = 220)
plot(dag); dev.off()
