# =============================================================================
# Sex-specific analysis (percentile gap, Du). Exploratory.
#   1 prevalence of discordance in men and women
#   2 lipid profile by sex (why women are less often discordantly high)
#   3 sensitivity: sex-specific percentiles (apoB and LDL-C ranked within sex)
#   4 effect modification: discordantly high apoB and MACE / multivessel disease
#     by sex, with interaction p
# Run after analysis.R.
# =============================================================================
library(dplyr); library(survival)
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("an"))  an  <- readRDS(file.path(OUT, "an.rds"))
num  <- function(x) suppressWarnings(as.numeric(as.character(x)))
fp   <- function(p) ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))
mq   <- function(x) sprintf("%.1f (%.1f-%.1f)", median(x, na.rm = TRUE),
                            quantile(x, .25, na.rm = TRUE), quantile(x, .75, na.rm = TRUE))
pct  <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
wil  <- function(k, n) { p <- k/n; z <- 1.96; d0 <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d0; m <- (p + z^2/(2*n))/d0
  sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, 100*p, 100*max(0, m-h), 100*min(1, m+h)) }
H <- "Discordantly high apoB"; L <- "Discordantly low apoB"
d <- an %>% mutate(sex = factor(ifelse(female, "Women", "Men"), c("Men", "Women")),
                   tg = num(triglyceride), hdl = num(hdl), lpa = num(lp_a),
                   ratio = ldl / apob_mgdl)

# --- 1  prevalence by sex -------------------------------------------------------
cat("=== 1. Prevalence by sex ===\n")
for (s in levels(d$sex)) { x <- d$du[d$sex == s]
  cat(sprintf("%-6s high %s | low %s\n", s, wil(sum(x == H), length(x)), wil(sum(x == L), length(x)))) }
cat(sprintf("Distribution of the 3 groups by sex: chi-square p %s\n",
            fp(chisq.test(table(d$sex, d$du))$p.value)))
cat(sprintf("Median percentile gap: men %s, women %s; p %s\n",
            mq(d$gap[d$sex == "Men"]), mq(d$gap[d$sex == "Women"]),
            fp(wilcox.test(gap ~ sex, d)$p.value)))

# --- 2  lipid profile by sex ------------------------------------------------------
cat("\n=== 2. Lipids by sex: median (IQR), Wilcoxon p ===\n")
for (v in c("ldl", "apob_mgdl", "tg", "hdl", "lpa", "ratio"))
  cat(sprintf("%-10s men %s | women %s | p %s\n", v, mq(d[[v]][d$sex == "Men"]),
              mq(d[[v]][d$sex == "Women"]), fp(wilcox.test(d[[v]] ~ d$sex)$p.value)))

# --- 3  sensitivity: percentiles within sex ---------------------------------------
d <- d %>% group_by(sex) %>%
  mutate(gap_sex = pct(apob_mgdl) - pct(ldl),
         du_sex  = factor(case_when(gap_sex > 10 ~ H, gap_sex < -10 ~ L, TRUE ~ "Concordant"),
                          c("Concordant", H, L))) %>% ungroup()
cat("\n=== 3. Sex-specific percentiles: prevalence ===\n")
for (s in levels(d$sex)) { x <- d$du_sex[d$sex == s]
  cat(sprintf("%-6s high %s | low %s\n", s, wil(sum(x == H), length(x)), wil(sum(x == L), length(x)))) }
print(table(`whole-cohort percentiles` = d$du, `sex-specific` = d$du_sex))

# --- 4  effect modification by sex -----------------------------------------------
COV <- "+ I(age/10) + dm + htn + smoke + llt"
cat("\n=== 4a. MACE: discordantly high vs concordant, by sex ===\n")
cc <- d %>% mutate(time = num(mace_yrs), event = num(mace)) %>%
  filter(!is.na(time), !is.na(event), time > 0, du != L) %>%
  filter(complete.cases(across(c(age, dm, htn, smoke, llt)))) %>%
  mutate(high = as.numeric(du == H))
for (s in levels(cc$sex)) { x <- cc[cc$sex == s, ]
  m <- coxph(as.formula(paste("Surv(time, event) ~ high", COV)), x); ci <- summary(m)$conf.int["high", ]
  cat(sprintf("%-6s n = %d, events %d (in high: %d): HR %.2f (%.2f-%.2f)\n", s, m$n, m$nevent,
              sum(x$event[x$high == 1]), ci[1], ci[3], ci[4])) }
mi <- coxph(as.formula(paste("Surv(time, event) ~ high * sex", COV)), cc)
cat(sprintf("Interaction high x sex: p %s\n", fp(summary(mi)$coefficients["high:sexWomen", 5])))

cat("\n=== 4b. Multivessel disease: discordantly high vs concordant, by sex ===\n")
mv <- d %>% filter(!is.na(mvd), du != L) %>% mutate(high = as.numeric(du == H))
for (s in levels(mv$sex)) {
  m <- glm(as.formula(paste("mvd ~ high", COV)), binomial, mv[mv$sex == s, ])
  b <- summary(m)$coefficients["high", ]
  cat(sprintf("%-6s n = %d: OR %.2f (%.2f-%.2f)\n", s, nobs(m), exp(b[1]),
              exp(b[1] - 1.96*b[2]), exp(b[1] + 1.96*b[2]))) }
mg <- glm(as.formula(paste("mvd ~ high * sex", COV)), binomial, mv)
cat(sprintf("Interaction high x sex: p %s\n", fp(summary(mg)$coefficients["high:sexWomen", 4])))
