# =============================================================================
# FIGURE 2: clinical profile by discordance group (percentile gap, Du).
#   A  dot plot   B  share of the percentile gap explained by each variable
# Dot plot: % with each characteristic in concordant / discordantly high /
# discordantly low apoB. Rows sorted by the high-vs-concordant difference;
# label gives the chi-square p across groups.
# Definitions (codebook):
#   T2D            diabtyp2 1 = ja, 2 = nein (3 = missing)
#   Prediabetes    HbA1c 5.7-6.4% among patients WITHOUT T2D
#   eGFR < 60      CKD-EPI 2021 (analysis.R)
#   CRP > 5 mg/L   standard (non-hs) assay, upper reference limit
#   Central obesity  waist-to-height ratio >= 0.5
#   Hypertension   hypertonie 1 = ja, 2 = nein
#   Hypothyroidism TSH > 4.0 mU/L or L-thyroxine (schilddr_se 1-8, 10)
# Run after analysis.R.
# =============================================================================

library(dplyr); library(ggplot2); library(patchwork)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num <- function(x) suppressWarnings(as.numeric(gsub(",", ".", as.character(x))))
yn  <- function(v) { x <- num(an[[v]]); ifelse(x == 1, TRUE, ifelse(x == 2, FALSE, NA)) }
GRP <- c("Concordant", "Discordantly high apoB", "Discordantly low apoB")
PAL <- setNames(c("grey60", "#D55E00", "#0072B2"), GRP)

t2d   <- yn("diabtyp2")
hba1c <- num(an$hba1c)
thyr  <- num(an$schilddr_se) %in% c(1:8, 10)
tsh   <- num(an$tsh)

CH <- list(
  "Type 2 diabetes"                  = t2d,
  "Prediabetes (HbA1c 5.7–6.4%)" = ifelse(t2d %in% FALSE, hba1c >= 5.7 & hba1c < 6.5, NA),
  "eGFR < 60 mL/min/1.73 m²"     = an$egfr < 60,
  "CRP > 5 mg/L"                     = num(an$crp) > 5,
  "Central obesity (WHtR ≥ 0.5)" = num(an$taillenumfang)/num(an$groesse) >= .5,
  "Hypertension"                     = yn("hypertonie"),
  "Hypothyroidism"                   = ifelse(thyr, TRUE, ifelse(is.na(tsh), NA, tsh > 4)))

tab <- bind_rows(lapply(names(CH), function(k) {
  x <- as.logical(CH[[k]]); ok <- !is.na(x)
  p <- suppressWarnings(chisq.test(table(an$du[ok], x[ok]))$p.value)
  data.frame(char = k, n = sum(ok), p = p, du = GRP,
             pct = as.numeric(100*tapply(x[ok], an$du[ok], mean))[1:3])
})) %>% mutate(lab = sprintf("%s (p %s)", char,
                             ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))))
ord <- tab %>% group_by(lab) %>%
  summarise(d = pct[du == GRP[2]] - pct[du == GRP[1]]) %>% arrange(d)
tab$lab <- factor(tab$lab, ord$lab)
write.csv(select(tab, char, n, p, du, pct), out("TABLE_figure2.csv"), row.names = FALSE)

th <- theme_bw(22) + theme(panel.grid.minor = element_blank(),
                           text = element_text(colour = "black"),
                           axis.text = element_text(colour = "black"),
                           plot.tag = element_text(face = "bold", size = 26),
                           legend.position = "bottom")

# --- A  dot plot -----------------------------------------------------------------
A <- ggplot(tab, aes(pct, lab)) +
  geom_line(aes(group = lab), colour = "grey80", linewidth = 2) +
  geom_point(aes(colour = du), size = 4) +
  scale_colour_manual(values = PAL, name = NULL) +
  scale_x_continuous(limits = c(0, 100), expand = expansion(add = 2)) +
  labs(x = "Patients with the characteristic (%)", y = NULL, tag = "A") +
  guides(colour = guide_legend(ncol = 1)) + th

# --- B  ONE multivariable model: determinants of discordantly high apoB --------
# Discordantly high vs all other patients (n = 926). Clinical variables from
# panel A + lipid-lowering therapy + the three lipid measures (per SD:
# log triglycerides, HDL-C, log Lp(a)) + age and sex. Glycaemic status as one
# 3-level variable (normoglycaemia / prediabetes / T2D); HbA1c is not entered
# separately. Missing values: multiple imputation (mice, 20 datasets, BMI as
# auxiliary, outcome and percentile gap in the imputation model), Rubin's rules.
# The same imputed data give the R2 of the continuous gap and the Lp(a)
# subtraction check, so every number comes from one model and one sample.
library(mice)
zs <- function(x) as.numeric(scale(x))
glyc <- factor(case_when(t2d %in% TRUE ~ "T2D",
                         t2d %in% FALSE & hba1c >= 5.7 & hba1c < 6.5 ~ "Prediabetes",
                         t2d %in% FALSE & hba1c < 5.7 ~ "Normoglycaemia"),
               c("Normoglycaemia", "Prediabetes", "T2D"))
fb <- function(x) factor(x, c(FALSE, TRUE))
pct <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
apob_nmol <- an$apob_mgdl * 1e7 / 512000                 # apoB particles, nmol/L
md <- data.frame(y = fb(an$du == GRP[2]), glyc,
                 ckd = fb(CH[[3]]), crp = fb(CH[[4]]), cob = fb(CH[[5]]), htn = fb(CH[[6]]),
                 hypo = fb(CH[[7]]), lltx = fb(an$llt != "No lipid-lowering therapy"),
                 age10 = an$age/10, female = fb(an$female),
                 tg = zs(log(num(an$triglyceride))), hdl = zs(num(an$hdl)),
                 lpa = zs(log1p(num(an$lp_a))), bmi = num(an$bmi),
                 gap = an$gap, gap_nolpa = pct(apob_nmol - num(an$lp_a)) - pct(an$ldl))
VARS <- c("age10", "female", "glyc", "cob", "htn", "ckd", "crp", "hypo", "lltx",
          "tg", "hdl", "lpa")
message("Missing values imputed:"); print(colSums(is.na(md)))
imp <- mice(md, m = 20, seed = 2026, printFlag = FALSE)
RHS <- paste(VARS, collapse = " + ")

LAB <- c(age10 = "Age, per 10 years", femaleTRUE = "Female sex",
         glycPrediabetes = "Prediabetes (vs normoglycaemia)",
         glycT2D = "Type 2 diabetes (vs normoglycaemia)",
         cobTRUE = "Central obesity", htnTRUE = "Hypertension", ckdTRUE = "eGFR < 60",
         crpTRUE = "CRP > 5 mg/L", hypoTRUE = "Hypothyroidism",
         lltxTRUE = "Lipid-lowering therapy (vs none)",
         tg = "Triglycerides, per SD (log)", hdl = "HDL-C, per SD",
         lpa = "Lp(a), per SD (log)")
tidy <- function(f, model) {
  fit <- with(imp, glm(as.formula(paste("y ~", f)), family = binomial))
  s <- summary(pool(fit), conf.int = TRUE, exponentiate = TRUE)
  data.frame(term = as.character(s$term), or = s$estimate, lo = s[["2.5 %"]],
             hi = s[["97.5 %"]], p = s$p.value, model = model) }
fB <- bind_rows(
  bind_rows(lapply(VARS, function(v) tidy(v, "Unadjusted"))),
  tidy(RHS, "Adjusted")) %>%
  filter(term %in% names(LAB)) %>%
  mutate(label = LAB[term], y = rev(seq_along(LAB))[match(term, names(LAB))] +
           ifelse(model == "Unadjusted", .17, -.17))
rownames(fB) <- NULL
write.csv(fB, out("TABLE_figure2B_or.csv"), row.names = FALSE)
cat("\n=== Figure 2B, adjusted model (OR, 95% CI, p) ===\n")
with(filter(fB, model == "Adjusted"),
     cat(sprintf("%-38s %.2f (%.2f-%.2f)  p %s\n", label, or, lo, hi,
                 ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))), sep = ""))

# same covariates, continuous percentile gap: pooled R2 and the Lp(a) check
r2 <- pool.r.squared(with(imp, lm(as.formula(paste("gap ~", RHS)))))
cat(sprintf("\nR2 of the percentile gap: %.1f%%\n", 100*r2[1, "est"]))
for (yv in c("gap", "gap_nolpa")) {
  s <- summary(pool(with(imp, lm(as.formula(paste(yv, "~", RHS))))), conf.int = TRUE)
  s <- s[s$term == "lpa", ]
  cat(sprintf("%-9s: beta for Lp(a) per SD = %.2f (%.2f to %.2f), p = %.3g\n",
              yv, s$estimate, s[["2.5 %"]], s[["97.5 %"]], s$p.value))
}
cat(sprintf("Median Lp(a) share of apoB particles: %.1f%% (IQR %.1f-%.1f)\n",
            median(100*num(an$lp_a)/apob_nmol, na.rm = TRUE),
            quantile(100*num(an$lp_a)/apob_nmol, .25, na.rm = TRUE),
            quantile(100*num(an$lp_a)/apob_nmol, .75, na.rm = TRUE)))

# --- B  how much of the discordance does each variable explain? ---------------
# Relative importance (LMG; relaimpo) of the same covariates for the continuous
# percentile gap: each variable's share of the explained variance, averaged over
# the 20 imputed datasets. The odds ratios above stay in TABLE_figure2B_or.csv
# (text / supplement). Takes 1-2 minutes.
library(relaimpo)
VLAB <- c(age10 = "Age", female = "Sex", glyc = "Glycaemic status",
          cob = "Central obesity", htn = "Hypertension", ckd = "eGFR < 60",
          crp = "CRP > 5 mg/L", hypo = "Hypothyroidism", lltx = "Lipid-lowering therapy",
          tg = "Triglycerides", hdl = "HDL-C", lpa = "Lp(a)")
li <- sapply(seq_len(imp$m), function(i)
  calc.relimp(lm(as.formula(paste("gap ~", RHS)), complete(imp, i)), type = "lmg")@lmg)
ri <- data.frame(var = rownames(li), r2 = 100*rowMeans(li)) %>%
  mutate(label = factor(VLAB[var], VLAB[var][order(r2)]))
tot <- sum(ri$r2)
write.csv(ri, out("TABLE_figure2B_relimp.csv"), row.names = FALSE)
cat(sprintf("\nTotal variance of the percentile gap explained: %.1f%%\n", tot))
print(ri %>% arrange(desc(r2)) %>% mutate(r2 = round(r2, 2), `share of explained %` = round(100*r2/tot, 1)))

B <- ggplot(ri, aes(r2, label)) +
  geom_col(fill = "grey35", width = .65) +
  geom_text(aes(label = sprintf("%.1f%%", r2)), hjust = -.15, size = 7) +
  scale_x_continuous(expand = expansion(mult = c(0, .18))) +
  labs(x = "Variance of the percentile gap explained (%)", y = NULL, tag = "B",
       subtitle = sprintf("All variables together: %.1f%%; unexplained: %.1f%%", tot, 100 - tot)) +
  th + theme(panel.grid.major.y = element_blank())

FIG2 <- (A | B) + plot_layout(widths = c(1, 1))
ggsave(out("FIGURE2.png"), FIG2, width = 22, height = 10, dpi = 300)
message("Written: FIGURE2.png, TABLE_figure2.csv, TABLE_figure2B_or.csv")
