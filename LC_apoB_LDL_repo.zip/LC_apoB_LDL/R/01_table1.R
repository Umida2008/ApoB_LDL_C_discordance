# =============================================================================
# TABLE 1: baseline characteristics, whole cohort (no grouping).
# Median (IQR) or n (%). Missing values are left out; column n = patients with
# data for that row. Codings checked against the LipidCardio codebook:
#   geschlecht 1 = maennlich, 2 = weiblich
#   radio items (diabtyp2, hypertonie, rauchen_*, fa_herz, vorbekannte_khk,
#   bypass_op): 1 = ja, 2 = nein, 3 = keine Angabe (-> missing)
#   herzinfarkt: 1 = nein/keine Angabe, 2-5 = ja
#   erkr_kardiovask: 3/4 HF, 7 PAVK, 10 hirnversorgende Gefaesse, 14 VHF
#   erkr_apoplex: 1-3 stroke, 4 TIA
# Units as in the codebook: lipids/glucose mg/dL, apoB g/L (x100 = mg/dL),
# Lp(a) nmol/L, CRP mg/L, creatinine mg/dL, HbA1c %.
# Run after analysis.R.
# =============================================================================

library(dplyr)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num <- function(x) suppressWarnings(as.numeric(gsub(",", ".", as.character(x))))
has <- function(v) v %in% names(an)
yn  <- function(v) { if (!has(v)) return(NA); x <- num(an[[v]])     # 1 ja, 2 nein
                     ifelse(x == 1, 1, ifelse(x == 2, 0, NA)) }
cb  <- function(...) { v <- c(...); v <- v[sapply(v, has)]          # checkbox ___k
                       if (!length(v)) return(NA)
                       as.numeric(Reduce(`|`, lapply(v, function(k) num(an[[k]]) %in% 1))) }

if (!has("llt"))
  an <- an %>% mutate(llt = case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
      on_statin & high ~ "High-intensity statin",
      on_statin        ~ "Moderate-intensity statin",
      TRUE             ~ "No lipid-lowering therapy"))

scr <- num(an$kreatinin); if (median(scr, na.rm = TRUE) > 20) scr <- scr/88.4
fem <- as.numeric(an$female)                       # built in analysis.R from geschlecht
kk  <- num(an$khk_status_akt)
nv  <- case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0)

t1 <- data.frame(
  age    = num(an$age),
  female = fem,
  bmi    = num(an$bmi),
  waist  = num(an$taillenumfang),
  whtr   = num(an$taillenumfang) / num(an$groesse),
  sbp    = num(an$rrsyst_re),
  dbp    = num(an$rrdiast_re),
  htn    = yn("hypertonie"),
  dm     = yn("diabtyp2"),
  smoke  = yn("rauchen_akt"),
  exsmk  = yn("rauchen_frueher"),
  fam    = yn("fa_herz"),
  cad    = yn("vorbekannte_khk"),
  mi     = ifelse(is.na(num(an$herzinfarkt)), NA, as.numeric(num(an$herzinfarkt) %in% 2:5)),
  cabg   = yn("bypass_op"),
  pad    = cb("erkr_kardiovask___7"),
  carot  = cb("erkr_kardiovask___10"),
  stroke = cb("erkr_apoplex___1", "erkr_apoplex___2", "erkr_apoplex___3"),
  tia    = cb("erkr_apoplex___4"),
  hf     = cb("erkr_kardiovask___3", "erkr_kardiovask___4"),
  af     = cb("erkr_kardiovask___14"),
  egfr   = 142 * pmin(scr/ifelse(fem == 1, .7, .9), 1)^ifelse(fem == 1, -.241, -.302) *
           pmax(scr/ifelse(fem == 1, .7, .9), 1)^-1.2 * .9938^num(an$age) *
           ifelse(fem == 1, 1.012, 1),
  tc     = num(an$cholesterin),
  ldl    = num(an$ldl),
  hdl    = num(an$hdl),
  nonhdl = num(an$cholesterin) - num(an$hdl),
  tg     = num(an$triglyceride),
  apob   = num(an$apob) * 100,
  lpa    = num(an$lp_a),
  hba1c  = num(an$hba1c),
  gluc   = num(an$glucose),
  crp    = num(an$crp),
  llt    = factor(an$llt, c("No lipid-lowering therapy", "Moderate-intensity statin",
                            "High-intensity statin", "Other lipid-lowering therapy")),
  eze    = as.numeric(an$on_eze),
  pcsk9  = as.numeric(an$on_pcsk9),
  nves   = factor(nv, 0:3, c("No obstructive CAD", "1-vessel", "2-vessel", "3-vessel")),
  mvd    = as.numeric(nv >= 2))

t1 <- t1 %>% mutate(
  central = as.numeric(whtr >= .5),
  ckd     = as.numeric(egfr < 60),
  hsi     = 8 * num(an$gpt)/num(an$got) + bmi + 2*female + 2*dm,   # ALT/AST ratio: unit-free
  masld   = as.numeric(hsi > 36),
  lpa125  = as.numeric(lpa >= 125),
  obstr   = as.numeric(nves != "No obstructive CAD"))

LAB <- c(
  .a = "Demographics and anthropometry",
  age = "Age, years", female = "Female sex", bmi = "Body mass index, kg/m²",
  waist = "Waist circumference, cm", whtr = "Waist-to-height ratio",
  central = "Central obesity (WHtR ≥ 0.5)",
  .b = "Cardiovascular risk factors",
  sbp = "Systolic blood pressure, mmHg", dbp = "Diastolic blood pressure, mmHg",
  htn = "Hypertension", dm = "Type 2 diabetes", smoke = "Current smoking",
  exsmk = "Former smoking", fam = "Family history of premature CVD",
  .c = "Cardiovascular history",
  cad = "Known CAD", mi = "Previous myocardial infarction", cabg = "Previous CABG",
  pad = "Peripheral artery disease", carot = "Cerebrovascular artery disease",
  stroke = "Previous stroke", tia = "Previous TIA", hf = "Heart failure",
  af = "Atrial fibrillation",
  .d = "Kidney and liver",
  egfr = "eGFR, mL/min/1.73 m²", ckd = "eGFR < 60 mL/min/1.73 m²",
  hsi = "Hepatic steatosis index", masld = "Suspected MASLD (HSI > 36)",
  .e = "Laboratory",
  tc = "Total cholesterol, mg/dL", ldl = "LDL-C, mg/dL", hdl = "HDL-C, mg/dL",
  nonhdl = "Non-HDL-C, mg/dL", tg = "Triglycerides, mg/dL", apob = "ApoB, mg/dL",
  lpa = "Lp(a), nmol/L", lpa125 = "Lp(a) ≥ 125 nmol/L", hba1c = "HbA1c, %",
  gluc = "Glucose, mg/dL", crp = "C-reactive protein, mg/L",
  .f = "Lipid-lowering therapy",
  llt = "Regimen", eze = "Ezetimibe", pcsk9 = "PCSK9 inhibitor",
  .g = "Index coronary angiography",
  nves = "Extent of CAD", obstr = "Obstructive CAD (≥ 1 vessel > 50%)",
  mvd = "Multivessel disease")

f3 <- function(z) formatC(z, digits = 3, format = "fg")
row1 <- function(v) {
  if (startsWith(v, ".")) return(data.frame(Characteristic = LAB[[v]], n = "", Value = ""))
  x <- t1[[v]]; x <- x[!is.na(x)]
  if (!length(x)) { message("no data, row dropped: ", v); return(NULL) }
  if (is.factor(x)) {
    tb <- table(x)
    return(data.frame(Characteristic = c(LAB[[v]], paste0("   ", names(tb))),
                      n = c(length(x), rep("", length(tb))),
                      Value = c("", sprintf("%d (%.1f)", as.vector(tb), 100*as.vector(tb)/length(x)))))
  }
  val <- if (all(x %in% 0:1)) sprintf("%d (%.1f)", sum(x), 100*mean(x))
         else sprintf("%s (%s–%s)", f3(median(x)), f3(quantile(x, .25)), f3(quantile(x, .75)))
  data.frame(Characteristic = paste0("   ", LAB[[v]]), n = length(x), Value = val)
}

TABLE1 <- rbind(data.frame(Characteristic = "Patients, n", n = "", Value = nrow(t1)),
                do.call(rbind, lapply(names(LAB), row1)))
print(TABLE1, right = FALSE, row.names = FALSE)
write.csv(TABLE1, out("TABLE1_baseline.csv"), row.names = FALSE, fileEncoding = "UTF-8")
message("Values are median (IQR) or n (%). n = patients with data for that row.")
