# =============================================================================
# The composite figure for the rapid communication.
#   A  apoB vs LDL-C, with guideline cut-points and the discordance groups
#   B  prevalence of discordance, overall and by regimen
#   C  composition of the apoB particle pool
#   D  association with coronary disease extent
#   E  association with MACE
# Run after analysis.R and LETTER.R; D and E read the CSVs written by
# 03c_extent_du.R and 04b_mace_du.R.
#
# Palette: Okabe-Ito. The three discordance colours were checked for
# colour-vision separation (worst adjacent pair dE 11.5 protan, 17.9 normal);
# grey is used deliberately as the neutral reference category, not as a hue.
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2)
stopifnot(requireNamespace("patchwork", quietly = TRUE))
library(patchwork)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("L")) {
  .f <- out("L.rds")
  if (file.exists(.f)) { L <- readRDS(.f); message("loaded `L` from ", .f) }
  else stop("Run LETTER.R once first; it builds `L` and saves ", .f)
}

COL_DISC <- c("Concordant" = "#767676",
              "Discordantly high apoB" = "#D55E00",
              "Discordantly low apoB"  = "#0072B2")
COL_PART <- c("LDL" = "#0072B2", "Remnant" = "#E69F00", "Lp(a)" = "#009E73")

base <- theme_bw(9) +
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = .25, colour = "grey88"),
        panel.border = element_rect(linewidth = .4, colour = "grey55"),
        axis.ticks = element_line(linewidth = .3, colour = "grey55"),
        legend.position = "top", legend.title = element_blank(),
        legend.key.size = unit(3.2, "mm"),
        legend.margin = margin(0, 0, 0, 0),
        strip.background = element_rect(fill = "grey94", colour = NA),
        strip.text = element_text(face = "bold", size = 8, hjust = 0),
        plot.title = element_text(face = "bold", size = 9.5))

# =============================================================================
# A  apoB vs LDL-C
# =============================================================================
ct <- cor.test(L$ldl, L$apob_mgdl)
lab_r <- sprintf("r = %.2f (%.2f-%.2f), p %s", ct$estimate, ct$conf.int[1],
                 ct$conf.int[2], ifelse(ct$p.value < .001, "< 0.001", "= n.s."))

pA <- ggplot(L %>% filter(!is.na(du)), aes(ldl, apob_mgdl)) +
  geom_vline(xintercept = c(55, 70, 100), linetype = "22",
             colour = "grey60", linewidth = .3) +
  geom_hline(yintercept = c(65, 80, 100), linetype = "22",
             colour = "grey60", linewidth = .3) +
  geom_point(aes(colour = du), alpha = .55, size = .8, stroke = 0) +
  geom_smooth(method = "lm", formula = y ~ x, colour = "grey15",
              linewidth = .5, se = TRUE, fill = "grey70", alpha = .25) +
  annotate("text", x = -Inf, y = Inf, hjust = -0.08, vjust = 1.6,
           size = 2.6, colour = "grey20", label = lab_r) +
  annotate("text", x = c(55, 70, 100), y = Inf, vjust = -0.6, size = 2.1,
           colour = "grey45", label = c("55", "70", "100")) +
  annotate("text", y = c(65, 80, 100), x = Inf, hjust = -0.3, size = 2.1,
           colour = "grey45", label = c("65", "80", "100")) +
  coord_cartesian(clip = "off") +
  scale_colour_manual(values = COL_DISC) +
  guides(colour = guide_legend(override.aes = list(size = 1.8, alpha = 1))) +
  labs(title = "A", x = "LDL-C (mg/dL)", y = "Apolipoprotein B (mg/dL)") +
  base + theme(plot.margin = margin(10, 12, 4, 4))

# =============================================================================
# B  Prevalence, overall and by regimen
# =============================================================================
wil3 <- function(k, n) { p <- k/n; z <- 1.96; d <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d; m <- (p + z^2/(2*n))/d
  c(100*p, 100*max(0, m-h), 100*min(1, m+h)) }

prev <- bind_rows(
  L %>% filter(!is.na(du)) %>% mutate(g = "Overall"),
  L %>% filter(!is.na(du), !is.na(regimen)) %>% mutate(g = as.character(regimen))) %>%
  group_by(g, du) %>% summarise(k = n(), .groups = "drop_last") %>%
  mutate(n = sum(k)) %>% ungroup() %>%
  filter(du != "Concordant") %>%
  rowwise() %>% mutate(pct = wil3(k, n)[1], lo = wil3(k, n)[2],
                       hi = wil3(k, n)[3]) %>% ungroup() %>%
  mutate(g = factor(g, c("Overall", levels(L$regimen))))

pB <- ggplot(prev, aes(g, pct, fill = du)) +
  geom_col(position = position_dodge(.72), width = .62, colour = "white",
           linewidth = .5) +
  geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(.72),
                width = .12, linewidth = .35, colour = "grey30") +
  geom_text(aes(y = hi + 1.2, label = sprintf("%.0f", pct)),
            position = position_dodge(.72), size = 2.3, colour = "grey20") +
  scale_fill_manual(values = COL_DISC[-1]) +
  scale_y_continuous(expand = expansion(mult = c(0, .16))) +
  scale_x_discrete(labels = function(x) gsub(" statin", "\nstatin", x)) +
  labs(title = "B", x = NULL, y = "Prevalence (%)") + base

# =============================================================================
# C  Composition of the apoB particle pool
# =============================================================================
MW <- 512000; RHO <- 3
B <- L %>% filter(!is.na(apob_mgdl), !is.na(triglyceride), !is.na(lp_a)) %>%
  mutate(apob_p = apob_mgdl * 1e7 / MW)
C_LDL <- median(B$ldl / B$apob_p, na.rm = TRUE)
B <- B %>% mutate(rem_p = rc/(RHO*C_LDL), lpa_p = lp_a,
                  ldl_p = pmax(apob_p - rem_p - lpa_p, 0))

comp <- bind_rows(
  B %>% filter(!is.na(regimen)) %>% mutate(g = as.character(regimen),
                                           panel = "By regimen"),
  B %>% filter(!is.na(du)) %>% mutate(g = as.character(du),
                                      panel = "By discordance group")) %>%
  group_by(panel, g) %>%
  summarise(LDL = 100*sum(ldl_p)/sum(apob_p),
            Remnant = 100*sum(rem_p)/sum(apob_p),
            `Lp(a)` = 100*sum(lpa_p)/sum(apob_p), .groups = "drop") %>%
  pivot_longer(LDL:`Lp(a)`, names_to = "compartment", values_to = "pct") %>%
  mutate(compartment = factor(compartment, c("LDL", "Remnant", "Lp(a)")),
         g = factor(g, c(levels(L$regimen), levels(L$du))),
         panel = factor(panel, c("By regimen", "By discordance group")))

pC <- ggplot(comp, aes(g, pct, fill = compartment)) +
  geom_col(width = .64, colour = "white", linewidth = .6) +
  geom_text(aes(label = ifelse(pct >= 4, sprintf("%.1f", pct), "")),
            position = position_stack(vjust = .5), size = 2.3,
            colour = c("white", "grey10", "white")[as.integer(comp$compartment)]) +
  facet_wrap(~ panel, scales = "free_x") +
  scale_fill_manual(values = COL_PART) +
  scale_y_continuous(expand = expansion(mult = c(0, .02))) +
  scale_x_discrete(labels = function(x) gsub(" ", "\n", x)) +
  labs(title = "C", x = NULL, y = "Share of apoB particles (%)") +
  base + theme(axis.text.x = element_text(size = 6.5))

# =============================================================================
# D and E  Forest plots, read from the tables already written
# =============================================================================
forest <- function(file, xlab, ttl, est = "or", subttl = NULL) {
  if (!file.exists(out(file))) { message("missing: ", file); return(NULL) }
  d <- read.csv(out(file), check.names = FALSE) %>%
    filter(sample == "All patients")
  if ("model" %in% names(d) && any(d$model == "Adjusted"))
    d <- d %>% filter(model == "Adjusted")
  if (!nrow(d)) { message("no rows in ", file); return(NULL) }
  d$e <- d[[est]]
  d <- d %>% mutate(exposure = sub(" vs concordant", "", exposure),
                    exposure = factor(exposure, rev(unique(exposure))),
                    lab = sprintf("%.2f (%.2f-%.2f)", e, lo, hi))
  xhi <- max(d$hi); xlo <- min(d$lo)

  p <- ggplot(d, aes(e, exposure)) +
    geom_vline(xintercept = 1, linetype = "22", colour = "grey55",
               linewidth = .3) +
    geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .14,
                  linewidth = .45, colour = "#0072B2") +
    geom_point(size = 1.9, colour = "#0072B2") +
    geom_text(aes(label = lab), x = log10(xhi * 1.15), hjust = 0, size = 2.3,
              colour = "grey20") +
    scale_x_log10(limits = c(xlo * .9, xhi * 2.4),
                  expand = expansion(mult = c(.02, 0))) +
    labs(title = ttl, subtitle = subttl, x = xlab, y = NULL) +
    base + theme(panel.grid.major.y = element_blank(),
                 legend.position = "none",
                 plot.subtitle = element_text(size = 8, colour = "grey30"))

  # the disease-extent table has two outcomes; the MACE table has one
  if ("outcome" %in% names(d) && dplyr::n_distinct(d$outcome) > 1)
    p <- p + facet_wrap(~ outcome, ncol = 1, scales = "free_y")
  p
}

pD <- forest("TABLE_extent_du.csv", "Adjusted odds ratio", "D", "or")
pE <- forest("TABLE_mace_du.csv",   "Adjusted hazard ratio", "E", "hr",
             subttl = "Major adverse cardiovascular events")

# =============================================================================
# Assemble
# =============================================================================
top <- pA + pB + plot_layout(widths = c(1.15, 1))
bot <- if (is.null(pE)) pD else pD + pE + plot_layout(widths = c(1, 1))
FIG  <- top / pC / bot + plot_layout(heights = c(1, .85, 1))

ggsave(out("FIGURE_main.png"), FIG, width = 180, height = 230, units = "mm",
       dpi = 600)
ggsave(out("FIGURE_main.pdf"), FIG, width = 180, height = 230, units = "mm")
message("Written: FIGURE_main.png (600 dpi) and FIGURE_main.pdf")
