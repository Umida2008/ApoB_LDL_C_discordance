# =============================================================================
# apoB, LDL-C and discordance vs MACE
# Run after analysis.R (needs `an`).
#
# Du et al. (Eur J Prev Cardiol 2025;zwaf750) showed in 375,544 UK Biobank
# participants that discordantly high apoB carries excess MACE (HR 1.11) - but
# they excluded everyone on lipid-lowering therapy and everyone with baseline
# cardiovascular disease. The open question is whether discordance still carries
# risk in TREATED patients with established coronary disease. That is what this
# script tests, with treatment status as the stratifying variable.
#
# Expect this to be underpowered. Read the event counts before the hazard
# ratios, and be prepared to report it as a null with a confidence interval
# rather than as a finding.
# =============================================================================

library(dplyr); library(survival); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
z  <- function(x) as.numeric(scale(x))

# -----------------------------------------------------------------------------
# 1  Survival object and covariates
# -----------------------------------------------------------------------------
sv <- an %>%
  mutate(time  = suppressWarnings(as.numeric(as.character(mace_yrs))),
         event = suppressWarnings(as.numeric(as.character(mace))),
                  treated = factor(ifelse(on_statin | on_eze, "Treated", "Untreated"),
                          c("Untreated","Treated"))) %>%
  filter(!is.na(time), !is.na(event), time > 0)

# ---- continuous forms of discordance ----------------------------------------
# Four parameterisations of the same idea. The residual is the primary one; the
# other three exist so the result can be compared with published work and shown
# not to depend on how discordance is written down.
#   resid    residual of apoB on LDL-C, per SD          (this paper)
#   pct_gap  apoB percentile minus LDL-C percentile      (Du et al. used >10
#            units as their cut-point; this is the continuous version)
#   cpp      LDL-C/apoB, cholesterol per particle        (Drexel et al. report
#            HR 0.87 per unit in 1,687 patients with ASCVD)
#   ratio    apoB/LDL-C, the same quantity inverted so that higher = more
#            particles per unit cholesterol, i.e. same sign as the residual
pctl <- function(x) 100*(rank(x, na.last = "keep") - .5)/sum(!is.na(x))
sv <- sv %>%
  mutate(pct_gap = pctl(apob_mgdl) - pctl(ldl),
         ratio   = apob_mgdl / ldl)

message(sprintf("Followed: %d | MACE: %d (%.1f%%) | median follow-up %.1f years",
                nrow(sv), sum(sv$event), 100*mean(sv$event), median(sv$time)))
print(sv %>% group_by(treated) %>%
        summarise(n = n(), events = sum(event),
                  pct = round(100*mean(event), 1),
                  person_years = round(sum(time)), .groups = "drop"))
print(sv %>% group_by(disc) %>%
        summarise(n = n(), events = sum(event),
                  pct = round(100*mean(event), 1), .groups = "drop"))

# Events per variable: with 5 covariates plus the exposure you want ~60 events.
# If the treated stratum has fewer, use the minimal model only.
COVS_MIN  <- c("z(age)", "sexf")
COVS_FULL <- c("z(age)", "sexf", "dm", "htn", "smoke")

# -----------------------------------------------------------------------------
# 2  Cox models
#    Exposures: apoB per SD, LDL-C per SD, discordance category
#    Strata:    all patients (adjusted for treatment), treated, untreated
# -----------------------------------------------------------------------------
tidy_hr <- function(m, keep, label, stratum) {
  s <- summary(m)$coefficients
  ci <- summary(m)$conf.int
  j <- grep(keep, rownames(s))
  if (!length(j)) return(NULL)
  data.frame(stratum = stratum, exposure = label,
             term = rownames(s)[j],
             hr = s[j, "exp(coef)"], lo = ci[j, "lower .95"],
             hi = ci[j, "upper .95"], p = s[j, "Pr(>|z|)"],
             n = m$n, events = m$nevent, row.names = NULL)
}

cox_one <- function(df, expr, keep, label, stratum, covs) {
  f <- as.formula(paste("Surv(time, event) ~", expr, "+",
                        paste(covs, collapse = " + ")))
  m <- try(coxph(f, data = df), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  tidy_hr(m, keep, label, stratum)
}

run_stratum <- function(df, stratum, covs) {
  bind_rows(
    cox_one(df, "z(apob_mgdl)", "apob",  "apoB, per SD",  stratum, covs),
    cox_one(df, "z(ldl)",       "ldl",   "LDL-C, per SD", stratum, covs),
    # --- discordance, continuous -------------------------------------------
    cox_one(df, "z(resid)",   "resid",   "Discordance residual, per SD",
            stratum, covs),
    cox_one(df, "z(pct_gap)", "pct_gap", "Percentile gap, per SD (Du-style)",
            stratum, covs),
    cox_one(df, "z(cpp)",     "cpp",     "LDL-C/apoB, per SD (Drexel-style)",
            stratum, covs),
    cox_one(df, "z(ratio)",   "ratio",   "apoB/LDL-C, per SD", stratum, covs),
    # --- discordance, categorical, for comparison ---------------------------
    cox_one(df, "disc", "^disc", "Discordance category", stratum, covs),
    # --- apoB and LDL-C together: which one carries the risk -----------------
    cox_one(df, "z(apob_mgdl) + z(ldl)", "apob",
            "apoB, per SD (mutually adjusted)", stratum, covs),
    cox_one(df, "z(apob_mgdl) + z(ldl)", "ldl",
            "LDL-C, per SD (mutually adjusted)", stratum, covs),
    # --- the clean reparameterisation ---------------------------------------
    # The residual is orthogonal to LDL-C by construction, so residual + LDL-C
    # is the same information as apoB + LDL-C but without their collinearity:
    # the residual term is the effect of excess apoB AT A GIVEN LDL-C, which is
    # exactly the paper's question, and the LDL-C term is free of it.
    cox_one(df, "z(resid) + z(ldl)", "resid",
            "Discordance residual, per SD (at fixed LDL-C)", stratum, covs),
    cox_one(df, "z(resid) + z(ldl)", "ldl",
            "LDL-C, per SD (residual held constant)", stratum, covs))
}

res <- bind_rows(
  run_stratum(sv, "All patients", c(COVS_FULL, "treated")),
  run_stratum(sv %>% filter(treated == "Treated"),   "Treated",   COVS_FULL),
  run_stratum(sv %>% filter(treated == "Untreated"), "Untreated", COVS_FULL),
  # minimal adjustment, for the strata where events are thin
  run_stratum(sv %>% filter(treated == "Treated"),
              "Treated, minimal adjustment", COVS_MIN))

res <- res %>%
  mutate(term = sub("^disc", "", term),
         label = ifelse(grepl("category", exposure), paste0(exposure, ": ", term),
                        exposure)) %>%
  select(stratum, exposure = label, hr, lo, hi, p, n, events)

print(res, digits = 3)
write.csv(res, out("tab_mace.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 3  Does the effect of discordance differ by treatment? (interaction)
# -----------------------------------------------------------------------------
m_int <- coxph(Surv(time, event) ~ disc * treated + z(age) + sexf + dm + htn +
                 smoke, data = sv)
print(summary(m_int))
message("\nLikelihood-ratio test for discordance x treatment interaction:")
print(anova(coxph(Surv(time, event) ~ disc + treated + z(age) + sexf + dm +
                    htn + smoke, data = sv), m_int))

# Is the continuous residual linear in the log hazard, or is only one tail
# risky? A spline answers it; if the non-linear term is null, report the linear
# per-SD estimate and say the shape was tested.
if (requireNamespace("splines", quietly = TRUE)) {
  m_lin <- coxph(Surv(time, event) ~ z(resid) + z(age) + sexf + dm + htn + smoke,
                 data = sv)
  m_spl <- coxph(Surv(time, event) ~ splines::ns(resid, 3) + z(age) + sexf +
                   dm + htn + smoke, data = sv)
  message("\nLinear vs spline in the discordance residual:")
  print(anova(m_lin, m_spl))
}

# proportional hazards check on the primary model
ph <- cox.zph(coxph(Surv(time, event) ~ z(resid) + z(age) + sexf + dm + htn +
                      smoke, data = sv))
print(ph)

# -----------------------------------------------------------------------------
# 4  Figure: Kaplan-Meier by discordance category, treated and untreated
# -----------------------------------------------------------------------------
if (requireNamespace("survminer", quietly = TRUE)) {
  fit <- survfit(Surv(time, event) ~ disc, data = sv %>% filter(treated == "Treated"))
  p <- survminer::ggsurvplot(fit, data = sv %>% filter(treated == "Treated"),
                             fun = "event", conf.int = TRUE, risk.table = TRUE,
                             palette = c("grey55", "#D55E00", "#0072B2"),
                             xlab = "Years", ylab = "Cumulative MACE",
                             legend.title = "", ggtheme = theme_bw(14))
  png(out("fig7_km_mace_treated.png"), width = 9, height = 7, units = "in", res = 300); print(p); dev.off()
}

# forest of the hazard ratios
fig <- res %>%
  filter(grepl("per SD", exposure), !grepl("mutually", exposure),
         stratum %in% c("All patients","Treated","Untreated")) %>%
  mutate(lab = sprintf("%.2f (%.2f-%.2f)  p %s", hr, lo, hi,
                       ifelse(p < 0.001, "< 0.001", sprintf("= %.3f", p)))) %>%
  ggplot(aes(hr, exposure)) +
  geom_vline(xintercept = 1, colour = "grey60", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .16,
                colour = "grey35", linewidth = .6) +
  geom_point(size = 3, colour = "#0072B2") +
  geom_text(aes(x = max(hi)*1.1, label = lab), hjust = 0, size = 4.2,
            colour = "grey15") +
  facet_wrap(~ stratum, ncol = 1) +
  scale_x_log10(expand = expansion(mult = c(.05, .85))) +
  labs(x = "Hazard ratio for MACE", y = NULL) +
  theme_bw(14) + theme(panel.grid.minor = element_blank())
ggsave(out("fig7_mace_forest.png"), fig, width = 10, height = 7, dpi = 300)

message("\nDone. MACE analysis written to ", OUT)
