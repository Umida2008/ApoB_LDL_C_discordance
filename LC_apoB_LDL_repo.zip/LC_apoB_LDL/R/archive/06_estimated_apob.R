# =============================================================================
# Can apoB be estimated from the routine lipid panel?
# Run after analysis.R (needs `an`).
#
# Precedent: Hwang et al. derived an equation for apoB from total cholesterol,
# triglycerides and HDL-C in 78,127 health-screening subjects (r = 0.945, 95%
# of estimates within 16 mg/dL) [PLoS One 2012;7:e51607]. That cohort was a
# general screening population. The open question, and the one that matters
# clinically, is whether estimation still works in TREATED patients with
# coronary disease - where the lipid profile has been pharmacologically
# reshaped and where the decision to measure apoB actually arises.
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

APOB_GOAL <- 65
set.seed(1)

dat <- an %>%
  mutate(nonhdl = cholesterin - hdl) %>%
  filter(!is.na(apob_mgdl), !is.na(ldl), !is.na(triglyceride), !is.na(hdl),
         !is.na(cholesterin), !is.na(lp_a)) %>%
  droplevels()
message(sprintf("n = %d with apoB and a complete panel", nrow(dat)))

# -----------------------------------------------------------------------------
# 1  Nested models, 10-fold cross-validated so the performance is honest
# -----------------------------------------------------------------------------
MODS <- list(
  "1 LDL-C alone"            = apob_mgdl ~ ldl,
  "2 + triglycerides"        = apob_mgdl ~ ldl + log(triglyceride),
  "3 + HDL-C and total chol" = apob_mgdl ~ ldl + log(triglyceride) + hdl + cholesterin,
  "4 non-HDL-C + TG"         = apob_mgdl ~ nonhdl + log(triglyceride),
  "5 + Lp(a)"                = apob_mgdl ~ ldl + log(triglyceride) + hdl +
                                            cholesterin + lp_a,
  "6 + age and sex"          = apob_mgdl ~ ldl + log(triglyceride) + hdl +
                                            cholesterin + lp_a + age + sexf)

cv_pred <- function(f, d, k = 10) {
  fold <- sample(rep_len(1:k, nrow(d)))
  p <- rep(NA_real_, nrow(d))
  for (i in 1:k) p[fold == i] <- predict(lm(f, d[fold != i, ]), d[fold == i, ])
  p
}

perf <- bind_rows(lapply(names(MODS), function(nm) {
  p  <- cv_pred(MODS[[nm]], dat)
  e  <- dat$apob_mgdl - p
  data.frame(model = nm,
             R2   = 1 - sum(e^2)/sum((dat$apob_mgdl - mean(dat$apob_mgdl))^2),
             RMSE = sqrt(mean(e^2)),
             bias = mean(e),
             within10 = 100*mean(abs(e) <= 10),
             within16 = 100*mean(abs(e) <= 16),
             # clinical consequence: would the estimate put the patient on the
             # right side of the apoB goal?
             misclass = 100*mean((p < APOB_GOAL) != (dat$apob_mgdl < APOB_GOAL)))
}))
print(perf, digits = 3)
write.csv(perf, out("tab_estimated_apob.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 2  Does estimation get worse in treated patients?
#    Fit in the whole cohort, then report error within each regimen.
# -----------------------------------------------------------------------------
best <- MODS[["3 + HDL-C and total chol"]]
dat$est <- cv_pred(best, dat)
dat$err <- dat$apob_mgdl - dat$est

by_reg <- dat %>%
  filter(!is.na(regimen)) %>%
  bind_rows(dat %>% mutate(regimen = "Overall")) %>%
  mutate(regimen = factor(regimen, c("Overall", levels(an$regimen)))) %>%
  filter(!is.na(regimen)) %>%
  group_by(regimen) %>%
  summarise(n = n(), RMSE = sqrt(mean(err^2)), bias = mean(err),
            within10 = 100*mean(abs(err) <= 10),
            misclass = 100*mean((est < APOB_GOAL) != (apob_mgdl < APOB_GOAL)),
            .groups = "drop")
print(by_reg, digits = 3)
write.csv(by_reg, out("tab_estimated_apob_by_regimen.csv"), row.names = FALSE)

# and across achieved LDL-C, where the decision actually arises
by_ldl <- dat %>% group_by(ldl_stratum) %>%
  summarise(n = n(), RMSE = sqrt(mean(err^2)), bias = mean(err),
            within10 = 100*mean(abs(err) <= 10),
            misclass = 100*mean((est < APOB_GOAL) != (apob_mgdl < APOB_GOAL)),
            .groups = "drop")
print(by_ldl, digits = 3)

# -----------------------------------------------------------------------------
# 3  Does the estimate miss exactly the patients the paper is about?
#    By construction, a patient discordant on the residual is one the estimate
#    gets wrong. Quantify how wrong.
# -----------------------------------------------------------------------------
print(dat %>% group_by(disc) %>%
        summarise(n = n(), median_error = median(err),
                  `|error| > 10 mg/dL, %` = round(100*mean(abs(err) > 10), 1),
                  .groups = "drop"))

# -----------------------------------------------------------------------------
# 4  Figures: agreement and error by regimen
# -----------------------------------------------------------------------------
lim <- c(mean(dat$err) - 1.96*sd(dat$err), mean(dat$err) + 1.96*sd(dat$err))
figA <- ggplot(dat, aes((apob_mgdl + est)/2, err)) +
  geom_hline(yintercept = 0, colour = "grey55") +
  geom_hline(yintercept = lim, linetype = "22", colour = "#D55E00") +
  geom_point(alpha = .25, size = 1.4, colour = "#0072B2") +
  annotate("text", x = Inf, y = lim, hjust = 1.05, vjust = -0.4, size = 4,
           colour = "#D55E00", label = sprintf("%+.1f", lim)) +
  labs(x = "Mean of measured and estimated apoB (mg/dL)",
       y = "Measured - estimated apoB (mg/dL)",
       subtitle = "Bland-Altman, cross-validated estimates") +
  theme_bw(14) + theme(panel.grid.minor = element_blank())
ggsave(out("figC_bland_altman.png"), figA, width = 7.5, height = 5.5, dpi = 300)

figB <- dat %>% filter(!is.na(regimen)) %>%
  ggplot(aes(regimen, err, fill = regimen)) +
  geom_hline(yintercept = 0, colour = "grey55") +
  geom_boxplot(width = .55, alpha = .85, outlier.size = .7) +
  scale_fill_manual(values = c("#0072B2", "#E69F00", "#009E73")) +
  labs(x = NULL, y = "Measured - estimated apoB (mg/dL)") +
  theme_bw(14) + theme(legend.position = "none",
                       panel.grid.minor = element_blank(),
                       axis.text.x = element_text(angle = 15, hjust = 1))
ggsave(out("figC_error_by_regimen.png"), figB, width = 7.5, height = 5, dpi = 300)

message("\nDone. Written to ", OUT)
