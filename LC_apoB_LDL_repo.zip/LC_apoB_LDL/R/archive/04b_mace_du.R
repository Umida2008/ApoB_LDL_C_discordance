# =============================================================================
# SENSITIVITY ANALYSIS: MACE using the discordance definition of Du et al.
# (Eur J Prev Cardiol 2026) - percentile gap of more than 10 units between
# LDL-C and apoB - so that the hazard ratios can be read against theirs.
# Run after analysis.R (needs `an`).
#
# The residual definition remains primary. Both results are reported.
# Expect this to be underpowered: read the event counts before the hazard
# ratios, and read the confidence intervals before the p-values.
# =============================================================================

library(dplyr); library(survival); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

GAP <- 10
y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
tf <- function(x) if (is.logical(x)) x & !is.na(x) else y1(x)
has <- function(v) v %in% names(an)
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(an))[1]
pr <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))

sv <- an %>%
  mutate(time  = suppressWarnings(as.numeric(as.character(mace_yrs))),
         event = suppressWarnings(as.numeric(as.character(mace))),
         p_ldl = pr(ldl), p_apob = pr(apob_mgdl), gap = p_apob - p_ldl,
         du = factor(case_when(gap >  GAP ~ "Discordantly high apoB",
                               gap < -GAP ~ "Discordantly low apoB",
                               TRUE       ~ "Concordant"),
                     levels = c("Concordant", "Discordantly high apoB",
                                "Discordantly low apoB")),
         z_gap = as.numeric(scale(gap)), z_age = as.numeric(scale(age)),
         sexb = droplevels(as.factor(.data[[sexv]])),
                  statin = tf(on_statin),
         eze  = if (has("on_eze")) tf(on_eze) else
                if (has("eze_add")) tf(eze_add) else FALSE,
         pcsk = if (has("on_pcsk9")) tf(on_pcsk9) else FALSE) %>%
  filter(!is.na(time), !is.na(event), time > 0, !is.na(du))

message(sprintf("n = %d, %d events (%.1f%%), median follow-up %.1f years",
                nrow(sv), sum(sv$event), 100*mean(sv$event), median(sv$time)))
message("Prevalence under the Du et al. definition:")
print(addmargins(table(sv$du)))
print(sv %>% group_by(du) %>% summarise(n = n(), events = sum(event),
        pct = round(100*mean(event), 1), person_years = round(sum(time)),
        .groups = "drop"))

# --- models ------------------------------------------------------------------
CONF <- c("z_age", "sexb", "dm", "htn", "smoke")

# Treatment is the dominant confounder in the whole cohort, so it enters the
# model wherever it varies; in the single-treatment strata it is dropped
# because it has only one level there.
covs_for <- function(dat) c(CONF,
  if (exists("regimen", dat) && nlevels(droplevels(as.factor(dat$regimen))) > 1)
    "regimen"
  else if (length(unique(dat$statin)) > 1) "statin")


fit1 <- function(dat, expr, keep, label, covs, model) {
  f <- as.formula(paste("Surv(time, event) ~", expr,
        if (length(covs)) paste("+", paste(covs, collapse = " + ")) else ""))
  m <- try(coxph(f, data = dat), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  s <- summary(m)$coefficients
  j <- grep(keep, rownames(s))[1]
  if (is.na(j)) return(NULL)
  data.frame(exposure = label, model = model,
             hr = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,3]),
             hi = exp(s[j,1] + 1.96*s[j,3]), p = s[j,5],
             n = m$n, events = m$nevent, row.names = NULL)
}

SAMPN <- c("All patients", "Untreated", "On lipid-lowering therapy")
pick  <- function(sn, dat) switch(sn,
  "All patients" = dat,
  "Untreated"    = dat %>% filter(!statin, !eze, !pcsk),
  "On lipid-lowering therapy" = dat %>% filter(statin, !pcsk))

TABLE_mace_du <- bind_rows(lapply(SAMPN, function(sn) {
  dat <- droplevels(pick(sn, sv))
  ev  <- sum(dat$event)
  # with fewer than ~50 events, adjust for age and sex only
  covs <- if (ev >= 50) covs_for(dat) else c("z_age", "sexb")
  bind_rows(
    fit1(dat, "du", "duDiscordantly high", "Discordantly high apoB vs concordant",
         character(0), "Unadjusted"),
    fit1(dat, "du", "duDiscordantly low",  "Discordantly low apoB vs concordant",
         character(0), "Unadjusted"),
    fit1(dat, "z_gap", "z_gap", "Percentile gap, per SD", character(0), "Unadjusted"),
    fit1(dat, "du", "duDiscordantly high", "Discordantly high apoB vs concordant",
         covs, "Adjusted"),
    fit1(dat, "du", "duDiscordantly low",  "Discordantly low apoB vs concordant",
         covs, "Adjusted"),
    fit1(dat, "z_gap", "z_gap", "Percentile gap, per SD", covs, "Adjusted")) %>%
    mutate(sample = sn, covariates = paste(covs, collapse = ", "), .before = 1)
}))

message("\n=== TABLE: MACE, Du et al. discordance definition ===")
print(TABLE_mace_du, digits = 3, row.names = FALSE)
write.csv(TABLE_mace_du, out("TABLE_mace_du.csv"), row.names = FALSE)

# agreement with the residual definition, for the methods section
if ("disc" %in% names(sv))
  print(addmargins(table(residual = sv$disc, Du = sv$du)))

# proportional hazards check on the continuous gap
print(cox.zph(coxph(Surv(time, event) ~ z_gap + z_age + sexb, data = sv)))

# --- figure ------------------------------------------------------------------
pf <- TABLE_mace_du %>% filter(sample == "All patients") %>%
  mutate(row = factor(paste0(exposure, "  -  ", model),
           levels = rev(as.vector(t(outer(unique(exposure),
                    c("Unadjusted", "Adjusted"), paste, sep = "  -  "))))),
         lab  = sprintf("%.2f (%.2f-%.2f)", hr, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)))

FIGURE_mace_du <- ggplot(pf, aes(hr, row, colour = model)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .2,
                linewidth = .7) +
  geom_point(size = 3.2) +
  geom_text(aes(x = max(pf$hi)*1.1, label = paste0(lab, "   ", plab)),
            hjust = 0, size = 3.8, colour = "grey15", show.legend = FALSE) +
  scale_colour_manual(values = c(Unadjusted = "grey60", Adjusted = "#0072B2")) +
  scale_x_log10(expand = expansion(mult = c(.06, .85))) +
  labs(x = "Hazard ratio for MACE", y = NULL) +
  theme_bw(13) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       legend.position = "top", legend.title = element_blank())
ggsave(out("FIGURE_mace_du.png"), FIGURE_mace_du, width = 11, height = 5.5,
       dpi = 300)
message("\nWritten: TABLE_mace_du.csv and FIGURE_mace_du.png")
