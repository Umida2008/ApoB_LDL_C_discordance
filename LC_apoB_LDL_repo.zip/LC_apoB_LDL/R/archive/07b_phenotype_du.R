# =============================================================================
# Baseline characteristics by the Du et al. discordance definition
# (percentile gap of more than 10 units between LDL-C and apoB).
#
# RUN 07_prevalence_phenotypes.R FIRST - this script reuses its table builder
# and its variable list, so the columns, formatting and tests are identical to
# the residual-based table and the two can be read side by side.
# =============================================================================

library(dplyr)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("build_tab") || !exists("VARS"))
  stop("Run 07_prevalence_phenotypes.R first: this script needs build_tab() and VARS.")

# build_tab() calls these three helpers; define them here if 07 was only
# partly run, so a half-loaded session cannot fall through to stats::pf().
if (!exists("fmed")) fmed <- function(x)
  sprintf("%.1f (%.1f-%.1f)", median(x), quantile(x, .25), quantile(x, .75))
if (!exists("fpct")) fpct <- function(x) sprintf("%d (%.1f)", sum(x), 100*mean(x))
if (!is.function(try(get("fmtp"), silent = TRUE))) fmtp <- function(p)
  if (is.na(p)) "-" else if (p < .001) "<0.001" else sprintf("%.3f", p)

GAP <- 10
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))

ph <- ph %>%
  mutate(gap = pctile(apob_mgdl) - pctile(ldl),
         du  = factor(case_when(gap >  GAP ~ "Discordantly high apoB",
                                gap < -GAP ~ "Discordantly low apoB",
                                TRUE       ~ "Concordant"),
                      levels = c("Concordant", "Discordantly high apoB",
                                 "Discordantly low apoB")))

message(sprintf("\nDu et al. definition (gap > %d percentile units):", GAP))
print(addmargins(table(ph$du)))
print(round(100*prop.table(table(ph$du)), 1))

message("\nCross-tabulation with the residual definition:")
print(addmargins(table(residual = ph$disc, Du = ph$du)))

# --- the table, built exactly as the residual one ----------------------------
VARS_DU <- c(VARS,
             trl_axis = "TRL axis (TG >=150 or low HDL-C)",
             lpa_high = "Lp(a) >=125 nmol/L",
             subpheno = "Sub-phenotype")
VARS_DU <- VARS_DU[names(VARS_DU) %in% names(ph)]

TABLE_phenotype_du <- build_tab("du", vars = VARS_DU, pairwise = TRUE)

message("\n=== TABLE: baseline characteristics by the Du et al. definition ===")
message("Continuous: median (IQR). Categorical: n (%). Missing ignored.")
message("Last two columns: each discordant group against the concordant group.")
print(TABLE_phenotype_du, right = FALSE, row.names = FALSE)
write.csv(TABLE_phenotype_du, out("TABLE_phenotype_du.csv"), row.names = FALSE)

message("\nWritten: ", out("TABLE_phenotype_du.csv"))
