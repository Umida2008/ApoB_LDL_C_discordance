# =============================================================================
# Everything the EJPC Rapid Communication needs, in the order of the text.
# Run after analysis.R (needs `an`). Sections S1-S6 match the manuscript.
#
# Primary definition here is the percentile gap of Du et al. (>10 units),
# chosen for direct comparability with that paper; the residual definition
# from analysis.R is carried alongside as a consistency check.
# =============================================================================

library(dplyr); library(tidyr)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

GAP      <- 10    # percentile units, Du et al.
LPA_HIGH <- 125   # nmol/L
RC_HIGH  <- 30    # mg/dL, elevated remnant cholesterol
TG_HIGH  <- 150   # mg/dL
MW       <- 512000; RHO <- 3

y1  <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
wil <- function(k, n) { p <- k/n; z <- 1.96; d <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d; m <- (p + z^2/(2*n))/d
  sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, 100*p, 100*max(0,m-h), 100*min(1,m+h)) }
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

L <- an %>%
  mutate(gap = pctile(apob_mgdl) - pctile(ldl),
         du  = factor(case_when(gap >  GAP ~ "Discordantly high apoB",
                                gap < -GAP ~ "Discordantly low apoB",
                                TRUE       ~ "Concordant"),
                      levels = c("Concordant", "Discordantly high apoB",
                                 "Discordantly low apoB")),
         rc       = triglyceride/5,                      # remnant cholesterol
         rc_high  = rc >= RC_HIGH,
         lpa_high = lp_a >= LPA_HIGH,
         tg_high  = triglyceride >= TG_HIGH,
         low_hdl  = (hdl < 40 & !female) | (hdl < 50 & female),
         trl_axis = tg_high | low_hdl,
                  n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4,7) ~ 0, TRUE ~ NA_real_),
         obstr = n_vessel >= 1, mvd = n_vessel >= 2)

# =============================================================================
# S1  Prevalence, and the method used to calculate it
# =============================================================================
message("\n--- S1 prevalence, percentile-gap definition (>", GAP, " units) ---")
print(addmargins(table(L$du)))
for (g in levels(L$du)[-1])
  message(g, ": ", wil(sum(L$du == g, na.rm = TRUE), sum(!is.na(L$du))))
message("By regimen:")
print(round(100*prop.table(table(regimen = L$regimen, L$du), 1), 1))
message(sprintf("Chi-square across regimens: p = %.3g",
                chisq.test(table(L$regimen, L$du))$p.value))

if ("disc" %in% names(L)) {                      # consistency with the residual
  message("\nResidual definition, for the one-sentence comparison:")
  print(round(100*prop.table(table(L$disc)), 1))
  print(addmargins(table(residual = L$disc, Du = L$du)))
}

# =============================================================================
# S2  Clinical phenotype: comorbidities and laboratory markers
# =============================================================================
fmed <- function(x) sprintf("%.1f (%.1f-%.1f)", median(x), quantile(x,.25), quantile(x,.75))
fpct <- function(x) sprintf("%d (%.1f)", sum(x), 100*mean(x))
fmtp <- function(p) if (is.na(p)) "-" else if (p < .001) "<0.001" else sprintf("%.3f", p)

row1 <- function(v, lab) {
  if (!v %in% names(L)) return(NULL)
  ok <- !is.na(L[[v]]) & !is.na(L$du); x <- L[[v]][ok]; g <- L$du[ok]
  if (length(x) < 10) return(NULL)
  bin <- is.logical(x) || all(x %in% c(0,1)); x <- as.numeric(x)
  f <- if (bin) function(z) fpct(z == 1) else fmed
  p <- if (bin) suppressWarnings(chisq.test(table(g, x))$p.value)
       else kruskal.test(x ~ g)$p.value
  bind_rows(c(Variable = lab, n = length(x), Overall = f(x),
              tapply(x, g, f)[levels(L$du)], p = fmtp(p)))
}

VARS <- c(age = "Age, years", female = "Women", bmi = "BMI, kg/m2",
  taillenumfang = "Waist circumference, cm", dm = "Type 2 diabetes",
  htn = "Hypertension", smoke = "Current smoking",
  herzinfarkt = "Previous myocardial infarction",
  ldl = "LDL-C, mg/dL", apob_mgdl = "ApoB, mg/dL",
  triglyceride = "Triglycerides, mg/dL", hdl = "HDL-C, mg/dL",
  rc = "Remnant cholesterol, mg/dL", lp_a = "Lp(a), nmol/L",
  hba1c = "HbA1c, %", crp = "CRP, mg/L", egfr = "eGFR, mL/min/1.73m2",
  on_statin = "Lipid-lowering therapy",
  n_vessel = "Diseased vessels, n", mvd = "Multivessel disease")

TAB <- as.data.frame(bind_rows(lapply(names(VARS), function(v) row1(v, VARS[[v]]))))
message("\n--- S2 clinical and laboratory phenotype by group ---")
print(TAB, right = FALSE, row.names = FALSE)

# =============================================================================
# S3  Laboratory phenotype: particle composition
#     apoB mass -> particles; Lp(a) particles direct; remnant particles from
#     remnant cholesterol; LDL particles by subtraction.
# =============================================================================
B <- L %>% filter(!is.na(apob_mgdl), !is.na(triglyceride), !is.na(lp_a)) %>%
  mutate(apob_p = apob_mgdl * 1e7 / MW)                 # mg/dL -> nmol/L
C_LDL  <- median(B$ldl / B$apob_p, na.rm = TRUE)
B <- B %>% mutate(rem_p = rc / (RHO * C_LDL),
                  lpa_p = lp_a,
                  ldl_p = pmax(apob_p - rem_p - lpa_p, 0),
                  s_ldl = 100*ldl_p/apob_p, s_rem = 100*rem_p/apob_p,
                  s_lpa = 100*lpa_p/apob_p, s_nonldl = s_rem + s_lpa)

message(sprintf("\n--- S3 particle composition (n = %d) ---", nrow(B)))
print(B %>% group_by(du) %>%
  summarise(n = n(), `LDL %` = round(median(s_ldl),1),
            `remnant %` = round(median(s_rem),1),
            `Lp(a) %` = round(median(s_lpa),1),
            `non-LDL %` = round(median(s_nonldl),1), .groups = "drop"))
for (v in c("s_rem","s_lpa","s_nonldl"))
  message(v, ": Kruskal-Wallis p = ",
          signif(kruskal.test(B[[v]] ~ B$du)$p.value, 3))

# =============================================================================
# S4  How many discordant patients have elevated Lp(a) and/or remnants
# =============================================================================
message("\n--- S4 elevated Lp(a) (>=", LPA_HIGH, " nmol/L) and/or remnant cholesterol (>=",
        RC_HIGH, " mg/dL) ---")
print(L %>% filter(!is.na(du)) %>% group_by(du) %>%
  summarise(n = n(),
            `Lp(a) high` = fpct(lpa_high[!is.na(lpa_high)] ),
            `remnants high` = fpct(rc_high[!is.na(rc_high)]),
            `either` = fpct((lpa_high | rc_high)[!is.na(lpa_high) & !is.na(rc_high)]),
            `both` = fpct((lpa_high & rc_high)[!is.na(lpa_high) & !is.na(rc_high)]),
            `neither` = fpct((!lpa_high & !rc_high)[!is.na(lpa_high) & !is.na(rc_high)]),
            .groups = "drop"))
hi <- L %>% filter(du == "Discordantly high apoB", !is.na(lpa_high), !is.na(rc_high))
message(sprintf("Among %d discordantly high patients, chi-square for independence of the two: p = %.3f",
                nrow(hi), chisq.test(table(hi$lpa_high, hi$rc_high))$p.value))

# =============================================================================
# S5 / S6  Disease extent and MACE
#   already produced by 03c_extent_du.R and 04b_mace_du.R - run those.
# =============================================================================
message("\n--- S5/S6: run 03c_extent_du.R and 04b_mace_du.R for disease extent and MACE ---")

# --- the single table for the letter -----------------------------------------
write.csv(TAB, out("LETTER_table.csv"), row.names = FALSE)
message("\nWritten: ", out("LETTER_table.csv"))

saveRDS(L, out("L.rds"))
message("cached: ", out("L.rds"))
