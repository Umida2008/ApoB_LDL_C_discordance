# =============================================================================
# Coronary disease extent and the apoB-LDL-C relationship.
# Run after analysis.R (needs `an`).
#
# DECISION, and why:
#   The primary exposure is the RESIDUAL (excess apoB at a given LDL-C). It is
#   orthogonal to LDL-C by construction, so its meaning does not depend on how
#   far treatment has lowered the achieved LDL-C. That is what lets treated and
#   untreated patients stay in one analysis without back-calculating an
#   untreated LDL-C, which would require a second, different correction factor
#   for apoB and would manufacture discordance rather than measure it.
#   LDL-C and apoB are reported alongside it, but in this cohort a measured
#   LDL-C is partly a marker of how severe the disease was already known to be,
#   so their coefficients are not interpretable as risk and are shown for
#   completeness only.
#   The median 2x2 groups are reported as event rates, without odds ratios:
#   the concordantly-low cell is dominated by intensively treated patients with
#   established disease, so an odds ratio against it measures prescribing.
#
# Outcomes: obstructive CAD (>=1 vessel >50%) and multivessel disease (>=2).
# Codes 4 (wall changes <50%) and 7 (microvascular) count as no obstructive
# disease; 5 and 6 are treated as missing.
# =============================================================================

library(dplyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(an))[1]

# -----------------------------------------------------------------------------
# 1  Sample and outcomes. Exposures standardised on the WHOLE cohort first, so
#    one SD means the same mg/dL in every subgroup.
# -----------------------------------------------------------------------------
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

dx <- an %>%
  mutate(across(c(ldl, apob_mgdl, resid, age), ~ as.numeric(scale(.x)),
                .names = "z_{.col}"),
         sexb  = droplevels(as.factor(.data[[sexv]])),
                  n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0,
                              TRUE ~ NA_real_),
         obstr = n_vessel >= 1,
         mvd   = n_vessel >= 2) %>%
  filter(!is.na(n_vessel))

message(sprintf("One SD = %.1f mg/dL apoB, %.1f mg/dL LDL-C, %.1f mg/dL residual",
                sd(an$apob_mgdl, na.rm = TRUE), sd(an$ldl, na.rm = TRUE),
                sd(an$resid, na.rm = TRUE)))
message(sprintf("Vessel count available: %d. Obstructive CAD %d (%.1f%%), multivessel %d (%.1f%%)",
                nrow(dx), sum(dx$obstr), 100*mean(dx$obstr),
                sum(dx$mvd), 100*mean(dx$mvd)))

# -----------------------------------------------------------------------------
# 2  Odds ratios per SD, both outcomes, three samples
# -----------------------------------------------------------------------------
CONF <- c("z_age", "sexb", "dm", "htn", "smoke")
covs_for <- function(dat)                     # regimen only where it varies
  c(CONF, if (nlevels(droplevels(dat$regimen)) > 1) "regimen")

fit1 <- function(dat, outcome, expr, keep, label, covs, model) {
  f <- as.formula(paste(outcome, "~", expr,
        if (length(covs)) paste("+", paste(covs, collapse = " + ")) else ""))
  m <- try(glm(f, binomial, dat), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  s <- summary(m)$coefficients
  j <- grep(keep, rownames(s))[1]
  if (is.na(j)) return(NULL)
  data.frame(outcome = outcome, exposure = label, model = model,
             or = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,2]),
             hi = exp(s[j,1] + 1.96*s[j,2]), p = s[j,4],
             n = nobs(m), events = sum(m$y), row.names = NULL)
}

EXP <- list(c("z_resid",     "z_resid", "Excess apoB at given LDL-C"),
            c("z_apob_mgdl", "z_apob",  "apoB"),
            c("z_ldl",       "z_ldl",   "LDL-C"))

SAMPN <- c("All patients", "Statin-naive", "On lipid-lowering therapy")
pick_sample <- function(sn, dat) switch(sn,
  "All patients"              = dat,
  "Statin-naive"              = dat %>% filter(!on_statin),
  "On lipid-lowering therapy" = dat %>% filter(on_statin, !on_pcsk9))

TABLE_extent <- bind_rows(lapply(SAMPN, function(sn) {
  dat <- droplevels(pick_sample(sn, dx)); cv <- covs_for(dat)
  bind_rows(lapply(c("obstr", "mvd"), function(o) bind_rows(
    lapply(EXP, function(e) fit1(dat, o, e[1], e[2], e[3], character(0), "Unadjusted")),
    lapply(EXP, function(e) fit1(dat, o, e[1], e[2], e[3], cv,           "Adjusted")),
    # LDL-C and the residual together: the collinearity-free way of asking
    # whether excess apoB adds anything to the achieved LDL-C
    list(fit1(dat, o, "z_ldl + z_resid", "z_resid",
              "Excess apoB (LDL-C in model)", cv, "Residual parameterisation"),
         fit1(dat, o, "z_ldl + z_resid", "z_ldl",
              "LDL-C (residual in model)",   cv, "Residual parameterisation"))
  ))) %>% mutate(sample = sn, .before = 1)
})) %>%
  mutate(outcome = recode(outcome, obstr = "Obstructive CAD (>=1 vessel)",
                          mvd = "Multivessel disease (>=2 vessels)"))

message("\n=== TABLE: odds ratios per SD for coronary disease extent ===")
print(TABLE_extent, digits = 3, row.names = FALSE)
write.csv(TABLE_extent, out("TABLE_disease_extent.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 3  The median 2x2, reported as event rates only (see the note at the top)
# -----------------------------------------------------------------------------
LM <- median(an$ldl, na.rm = TRUE); AM <- median(an$apob_mgdl, na.rm = TRUE)
dx <- dx %>% mutate(grp4 = factor(case_when(
    ldl <  LM & apob_mgdl <  AM ~ "Both low",
    ldl <  LM & apob_mgdl >= AM ~ "Low LDL-C, high apoB",
    ldl >= LM & apob_mgdl <  AM ~ "High LDL-C, low apoB",
    ldl >= LM & apob_mgdl >= AM ~ "Both high"),
  levels = c("Both low", "Low LDL-C, high apoB", "High LDL-C, low apoB",
             "Both high")))

TABLE_extent_groups <- bind_rows(lapply(SAMPN, function(sn) {
  pick_sample(sn, dx) %>% filter(!is.na(grp4)) %>% group_by(Group = grp4) %>%
    summarise(n = n(),
              `on statin, %`      = round(100*mean(on_statin, na.rm = TRUE)),
              `obstructive CAD`   = sprintf("%d (%.1f)", sum(obstr), 100*mean(obstr)),
              `multivessel`       = sprintf("%d (%.1f)", sum(mvd), 100*mean(mvd)),
              .groups = "drop") %>%
    mutate(sample = sn, .before = 1)
}))
message(sprintf("\n=== TABLE: disease extent by the median 2x2 (LDL-C %.0f, apoB %.0f) ===",
                LM, AM))
message("Event rates only. The 'on statin' column shows why an odds ratio against")
message("the both-low cell would measure prescribing rather than particle burden.")
print(as.data.frame(TABLE_extent_groups), right = FALSE, row.names = FALSE)
write.csv(TABLE_extent_groups, out("TABLE_disease_extent_groups.csv"),
          row.names = FALSE)

# -----------------------------------------------------------------------------
# 4  Figure: adjusted estimates, both outcomes, all patients
# -----------------------------------------------------------------------------
pd <- TABLE_extent %>%
  filter(sample == "All patients", model == "Adjusted") %>%
  mutate(lab  = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)),
         exposure = factor(exposure,
                    rev(c("LDL-C", "apoB", "Excess apoB at given LDL-C"))))

FIGURE_extent <- ggplot(pd, aes(or, exposure)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .16,
                linewidth = .7, colour = "#0072B2") +
  geom_point(size = 3.4, colour = "#0072B2") +
  geom_text(aes(label = paste0(lab, "   ", plab)), hjust = 0, size = 4,
            colour = "grey15", nudge_y = .25) +
  facet_wrap(~ outcome, ncol = 1) +
  scale_x_log10(expand = expansion(mult = c(.08, .75))) +
  labs(x = "Adjusted odds ratio per SD", y = NULL,
       subtitle = sprintf("All patients with a vessel count (n = %d). Adjusted for age, sex, diabetes, hypertension, smoking and regimen.",
                          nrow(dx))) +
  theme_bw(14) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       strip.text = element_text(face = "bold", hjust = 0),
                       plot.subtitle = element_text(size = 10, colour = "grey30"))
ggsave(out("FIGURE_disease_extent.png"), FIGURE_extent, width = 11, height = 7, dpi = 300)

message("\n============================================================")
message("  TABLE_disease_extent.csv         ORs per SD, 2 outcomes, 3 samples")
message("  TABLE_disease_extent_groups.csv  event rates by the median 2x2")
message("  FIGURE_disease_extent.png        adjusted estimates, both outcomes")
print(sort(list.files(OUT, pattern = "disease_extent")))
message("============================================================")
