# =============================================================================
# A  Guideline target attainment and reclassification
# B  Can discordance be predicted, i.e. who actually needs an apoB measurement?
# Run after analysis.R (needs `an`).
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2); library(rms)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

# ESC/EAS 2019, very-high-risk secondary prevention
LDL_GOAL  <- 55    # mg/dL
APOB_GOAL <- 65    # mg/dL
NONHDL_GOAL <- 85  # mg/dL

wil <- function(k, n) { p <- k/n; z <- 1.96; d <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d; m <- (p + z^2/(2*n))/d
  sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, 100*p, 100*max(0,m-h), 100*min(1,m+h)) }

# =============================================================================
# A1  Attainment of each target, overall and by regimen
# =============================================================================
tg <- an %>%
  mutate(ldl_ok  = ldl < LDL_GOAL,
         apob_ok = apob_mgdl < APOB_GOAL,
         nonhdl  = cholesterin - hdl,
         nhdl_ok = nonhdl < NONHDL_GOAL,
         both_ok = ldl_ok & apob_ok,
         ldl_only  = ldl_ok & !apob_ok,      # looks treated, apoB says otherwise
         apob_only = !ldl_ok & apob_ok)      # apoB says treated, LDL-C does not

att <- bind_rows(
  tg %>% mutate(g = "Overall"),
  tg %>% filter(!is.na(regimen)) %>% mutate(g = as.character(regimen))) %>%
  group_by(g) %>%
  summarise(n = n(),
            `LDL-C <55`   = wil(sum(ldl_ok, na.rm = TRUE), sum(!is.na(ldl_ok))),
            `apoB <65`    = wil(sum(apob_ok, na.rm = TRUE), sum(!is.na(apob_ok))),
            `non-HDL <85` = wil(sum(nhdl_ok, na.rm = TRUE), sum(!is.na(nhdl_ok))),
            .groups = "drop")
print(att); write.csv(att, out("tabA_target_attainment.csv"), row.names = FALSE)

# =============================================================================
# A2  Reclassification: agreement between the LDL-C and apoB targets
# =============================================================================
message("\nLDL-C goal x apoB goal:")
print(addmargins(table(`LDL-C <55` = tg$ldl_ok, `apoB <65` = tg$apob_ok)))
message(sprintf(
  "At LDL-C goal but apoB above goal: %s\nApoB at goal but LDL-C above goal: %s",
  wil(sum(tg$ldl_only, na.rm = TRUE), sum(!is.na(tg$ldl_only))),
  wil(sum(tg$apob_only, na.rm = TRUE), sum(!is.na(tg$apob_only)))))

# Are the two goals equipotent in this cohort? If the apoB value corresponding
# to LDL-C 55 is far from 65, the asymmetry above is a property of the
# thresholds, not of the particles - and that is the reportable observation.
eq <- as.numeric(predict(lm(apob_mgdl ~ ldl, an),
                         newdata = data.frame(ldl = LDL_GOAL)))
message(sprintf(
  "\nLDL-C %d mg/dL corresponds to apoB %.1f mg/dL here; the guideline pairs it
with %d mg/dL. Equipotent apoB goal would be %.0f.", LDL_GOAL, eq, APOB_GOAL, eq))

tg <- tg %>% mutate(apob_ok_eq = apob_mgdl < eq)
message("Reclassification under an equipotent apoB goal:")
print(addmargins(table(`LDL-C <55` = tg$ldl_ok, `apoB < equipotent` = tg$apob_ok_eq)))

# =============================================================================
# B   Prediction of discordance - who needs an apoB measurement?
#     Nested models, optimism-corrected c-statistic by bootstrap.
# =============================================================================
pdat <- an %>%
  transmute(res_high = as.integer(res_high), age, female = as.integer(female),
            wc = taillenumfang, log_tg, hdl, log_lpa, hba1c) %>%
  na.omit()
message(sprintf("\nPrediction set: n = %d, %d discordant", nrow(pdat),
                sum(pdat$res_high)))

dd <- datadist(pdat); options(datadist = "dd")

mods <- list(
  "1 Demographics"              = res_high ~ age + female + wc,
  "2 + routine lipids (TG, HDL)"= res_high ~ age + female + wc + log_tg + hdl,
  "3 + HbA1c"                   = res_high ~ age + female + wc + log_tg + hdl + hba1c,
  "4 + Lp(a)"                   = res_high ~ age + female + wc + log_tg + hdl +
                                              hba1c + log_lpa)

perf <- bind_rows(lapply(names(mods), function(nm) {
  f <- lrm(mods[[nm]], data = pdat, x = TRUE, y = TRUE)
  v <- validate(f, B = 200)                       # bootstrap optimism
  data.frame(model = nm,
             c_apparent = 0.5 + v["Dxy","index.orig"]/2,
             c_corrected = 0.5 + v["Dxy","index.corrected"]/2,
             R2 = f$stats["R2"], n = nrow(pdat))
}))
print(perf, digits = 3); write.csv(perf, out("tabB_prediction.csv"), row.names = FALSE)

# Does Lp(a) add discrimination beyond routine lipids?
message("\nLikelihood-ratio test, adding Lp(a) to model 3:")
print(anova(glm(mods[["3 + HbA1c"]], binomial, pdat),
            glm(mods[["4 + Lp(a)"]], binomial, pdat), test = "LRT"))

# Operating characteristics of the full model: if you only measured apoB in the
# top X% of predicted risk, how many discordant patients would you find?
f4 <- lrm(mods[["4 + Lp(a)"]], data = pdat, x = TRUE, y = TRUE)
pdat$phat <- predict(f4, type = "fitted")
op <- bind_rows(lapply(c(.10, .20, .30, .50), function(q) {
  cut <- quantile(pdat$phat, 1 - q)
  sel <- pdat$phat >= cut
  data.frame(tested = sprintf("%.0f%%", 100*q),
             sensitivity = round(100*sum(sel & pdat$res_high == 1)/sum(pdat$res_high), 1),
             ppv = round(100*mean(pdat$res_high[sel] == 1), 1))
}))
message("\nIf apoB were measured only in the highest-risk fraction:")
print(op)

# calibration
png(out("figB_calibration.png"), width = 6, height = 6, units = "in", res = 300)
plot(calibrate(f4, B = 200)); dev.off()

# ROC curves
roc_df <- bind_rows(lapply(names(mods), function(nm) {
  p <- predict(lrm(mods[[nm]], data = pdat), type = "fitted")
  th <- sort(unique(p))
  data.frame(model = nm,
             fpr = sapply(th, function(t) mean(p[pdat$res_high==0] >= t)),
             tpr = sapply(th, function(t) mean(p[pdat$res_high==1] >= t)))
}))
figB <- ggplot(roc_df, aes(fpr, tpr, colour = model)) +
  geom_abline(slope = 1, linetype = "22", colour = "grey60") +
  geom_line(linewidth = .9) +
  scale_colour_manual(values = c("#999999","#0072B2","#E69F00","#009E73")) +
  labs(x = "1 - specificity", y = "Sensitivity",
       subtitle = "Prediction of apoB-high discordance") +
  theme_bw(13) + theme(legend.position = "bottom", legend.title = element_blank(),
                       panel.grid.minor = element_blank())
ggsave(out("figB_roc.png"), figB, width = 7, height = 6.5, dpi = 300)

message("\nDone. Written to ", OUT)
