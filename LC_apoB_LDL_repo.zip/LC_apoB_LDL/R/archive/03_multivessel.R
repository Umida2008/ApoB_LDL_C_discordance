# =============================================================================
# Multivessel coronary disease: adjusted odds ratios for LDL-C, apoB and
# apoB-LDL-C discordance. Run after analysis.R (needs `an`).
#
# Multivessel disease = 2- or 3-vessel disease (>50% stenosis) at the index
# angiography. Codes 4 (wall changes <50%) and 7 (microvascular) count as no
# obstructive disease; 5 and 6 are treated as missing.
#
# All exposures are standardised on the WHOLE cohort before any subsetting, so
# one SD means the same number of mg/dL in every model.
# =============================================================================

library(dplyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(an))[1]
message("Sex variable used: ", sexv)

# -----------------------------------------------------------------------------
# 1  Sample and outcome
# -----------------------------------------------------------------------------
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

dx <- an %>%
  mutate(across(c(ldl, apob_mgdl, resid, age), ~ as.numeric(scale(.x)),
                .names = "z_{.col}"),
         sexb     = droplevels(as.factor(.data[[sexv]])),
                  n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0,
                              TRUE ~ NA_real_),
         mvd      = n_vessel >= 2) %>%
  filter(!is.na(mvd))

message(sprintf("One SD = %.1f mg/dL apoB, %.1f mg/dL LDL-C, %.1f mg/dL residual",
                sd(an$apob_mgdl, na.rm = TRUE), sd(an$ldl, na.rm = TRUE),
                sd(an$resid, na.rm = TRUE)))
message(sprintf("Patients with a vessel count: %d; multivessel disease: %d (%.1f%%)",
                nrow(dx), sum(dx$mvd), 100*mean(dx$mvd)))

# -----------------------------------------------------------------------------
# 2  Models
#    Three exposures, each per SD. Confounders: age, sex, diabetes,
#    hypertension, smoking and lipid-lowering regimen. Treatment is a
#    confounder here, not a mediator: nothing runs from a measured apoB at
#    angiography back to the decision to treat before it.
# -----------------------------------------------------------------------------
CONF <- c("z_age", "sexb", "dm", "htn", "smoke", "regimen")

fit1 <- function(expr, keep, label, covs, model, dat) {
  f <- as.formula(paste("mvd ~", expr,
        if (length(covs)) paste("+", paste(covs, collapse = " + ")) else ""))
  m <- try(glm(f, binomial, dat), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  s <- summary(m)$coefficients
  j <- grep(keep, rownames(s))[1]
  if (is.na(j)) return(NULL)
  data.frame(exposure = label, model = model,
             or = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,2]),
             hi = exp(s[j,1] + 1.96*s[j,2]), p = s[j,4],
             n = nobs(m), events = sum(m$y), row.names = NULL)
}

EXP <- list(c("z_ldl",       "z_ldl",  "LDL-C"),
            c("z_apob_mgdl", "z_apob", "apoB"),
            c("z_resid",     "z_resid","Discordance (apoB residual)"))

models <- function(dat, samp) {
  bind_rows(
    lapply(EXP, function(e) fit1(e[1], e[2], e[3], character(0), "Unadjusted", dat)),
    lapply(EXP, function(e) fit1(e[1], e[2], e[3], CONF,         "Adjusted",   dat)),
    # apoB and LDL-C entered together: which of the two carries the association
    list(fit1("z_ldl + z_apob_mgdl", "z_ldl",  "LDL-C (apoB in model)",
              CONF, "Mutually adjusted", dat),
         fit1("z_ldl + z_apob_mgdl", "z_apob", "apoB (LDL-C in model)",
              CONF, "Mutually adjusted", dat),
    # the same question without collinearity: the residual is orthogonal to
    # LDL-C by construction, so these two terms carry the identical information
         fit1("z_ldl + z_resid", "z_ldl",   "LDL-C (residual in model)",
              CONF, "Residual parameterisation", dat),
         fit1("z_ldl + z_resid", "z_resid", "Excess apoB at given LDL-C",
              CONF, "Residual parameterisation", dat))) %>%
    mutate(sample = samp, .before = 1)
}

tr <- dx %>% filter(on_statin, !on_pcsk9) %>% droplevels()
TABLE_multivessel <- bind_rows(
  models(dx,  "All patients"),
  models(tr, "On lipid-lowering therapy"))

message("\n=== TABLE: odds ratios per SD for multivessel coronary disease ===")
print(TABLE_multivessel, digits = 3, row.names = FALSE)
write.csv(TABLE_multivessel, out("TABLE_multivessel.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 2b  Categorical version: the classic 2x2, with concordantly LOW as reference
#
# Patients are split at the cohort medians of LDL-C and apoB. "Both low" is the
# reference, so each odds ratio answers a question a clinician can state: what
# are the odds of multivessel disease in a patient whose apoB is high although
# their LDL-C is low, compared with a patient in whom both are low.
# The cell that carries the paper's argument is "Low LDL-C, high apoB": same
# LDL-C side of the median as the reference, different particle burden.
# -----------------------------------------------------------------------------
LM <- median(an$ldl, na.rm = TRUE); AM <- median(an$apob_mgdl, na.rm = TRUE)
message(sprintf("\nCohort medians: LDL-C %.0f, apoB %.0f mg/dL", LM, AM))

dx <- dx %>% mutate(grp4 = factor(case_when(
    ldl <  LM & apob_mgdl <  AM ~ "Both low (reference)",
    ldl <  LM & apob_mgdl >= AM ~ "Low LDL-C, high apoB",
    ldl >= LM & apob_mgdl <  AM ~ "High LDL-C, low apoB",
    ldl >= LM & apob_mgdl >= AM ~ "Both high"),
  levels = c("Both low (reference)", "Low LDL-C, high apoB",
             "High LDL-C, low apoB", "Both high")))
print(addmargins(table(grp4 = dx$grp4, multivessel = dx$mvd)))

grp_or <- function(dat, samp) {
  m <- glm(reformulate(c("grp4", CONF), "mvd"), binomial, dat)
  s <- summary(m)$coefficients
  j <- grep("^grp4", rownames(s))
  cnt <- dat %>% filter(!is.na(grp4), !is.na(mvd)) %>% group_by(grp4) %>%
           summarise(n = n(), ev = sum(mvd), .groups = "drop")
  ref <- cnt[1, ]
  bind_rows(
    data.frame(sample = samp, exposure = levels(dat$grp4)[1],
               model = "Median 2x2 (both-low reference)",
               or = 1, lo = NA, hi = NA, p = NA, n = ref$n, events = ref$ev),
    data.frame(sample = samp,
               exposure = sub("^grp4", "", rownames(s)[j]),
               model = "Median 2x2 (both-low reference)",
               or = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,2]),
               hi = exp(s[j,1] + 1.96*s[j,2]), p = s[j,4],
               n = cnt$n[-1], events = cnt$ev[-1], row.names = NULL))
}

TABLE_multivessel_groups <- bind_rows(
  grp_or(dx,  "All patients"),
  grp_or(dx %>% filter(on_statin, !on_pcsk9) %>% droplevels(),
         "On lipid-lowering therapy"))
message("\n=== TABLE: multivessel disease by the 2x2 groups, both-low as reference ===")
message("Adjusted for age, sex, diabetes, hypertension, smoking and regimen.")
print(TABLE_multivessel_groups, digits = 3, row.names = FALSE)
write.csv(TABLE_multivessel_groups, out("TABLE_multivessel_groups.csv"),
          row.names = FALSE)

FIGURE_multivessel_groups <- TABLE_multivessel_groups %>%
  filter(sample == "All patients", !is.na(lo)) %>%
  mutate(lab = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)),
         exposure = factor(exposure, rev(levels(dx$grp4)[-1]))) %>%
  ggplot(aes(or, exposure)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .16,
                linewidth = .7, colour = "#0072B2") +
  geom_point(size = 3.4, colour = "#0072B2") +
  geom_text(aes(label = paste0(lab, "   ", plab)), hjust = 0, size = 4.3,
            colour = "grey15", nudge_y = .22) +
  scale_x_log10(expand = expansion(mult = c(.08, .55))) +
  labs(x = "Odds ratio for multivessel coronary disease", y = NULL,
       subtitle = "Reference: both LDL-C and apoB below the cohort median") +
  theme_bw(15) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       plot.subtitle = element_text(size = 11, colour = "grey30"))
ggsave(out("FIGURE_multivessel_groups.png"), FIGURE_multivessel_groups,
       width = 10, height = 4.2, dpi = 300)
message("=== FIGURE written: FIGURE_multivessel_groups.png (the 2x2 groups) ===")

# collinearity check before quoting the mutually adjusted estimates
message(sprintf("\napoB vs LDL-C correlation: r = %.2f",
                cor(dx$ldl, dx$apob_mgdl, use = "complete.obs")))
if (requireNamespace("car", quietly = TRUE)) {
  message("VIF, apoB and LDL-C together:")
  print(round(car::vif(glm(mvd ~ z_ldl + z_apob_mgdl + z_age + sexb + dm + htn +
                             smoke + regimen, binomial, dx)), 2))
  message("VIF, residual parameterisation (should be ~1):")
  print(round(car::vif(glm(mvd ~ z_ldl + z_resid + z_age + sexb + dm + htn +
                             smoke + regimen, binomial, dx)), 2))
}

# -----------------------------------------------------------------------------
# 3  Figure: the three exposures, unadjusted and adjusted, all patients
# -----------------------------------------------------------------------------
pd <- TABLE_multivessel %>%
  filter(sample == "All patients", model %in% c("Unadjusted", "Adjusted")) %>%
  mutate(lab   = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab  = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)),
         exposure = factor(exposure,
                    rev(c("LDL-C", "apoB", "Discordance (apoB residual)"))),
         model = factor(model, c("Unadjusted", "Adjusted")))

FIGURE_multivessel <- ggplot(pd, aes(or, exposure, colour = model)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22", linewidth = .5) +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .18,
                linewidth = .7, position = position_dodge(.55)) +
  geom_point(size = 3.4, position = position_dodge(.55)) +
  geom_text(aes(x = max(pd$hi)*1.08, label = paste0(lab, "   ", plab)),
            hjust = 0, size = 4.4, colour = "grey15",
            position = position_dodge(.55), show.legend = FALSE) +
  scale_colour_manual(values = c(Unadjusted = "grey55", Adjusted = "#0072B2")) +
  scale_x_log10(expand = expansion(mult = c(.06, .95))) +
  labs(x = "Odds ratio per SD for multivessel coronary disease", y = NULL,
       subtitle = sprintf("n = %d, %d with multivessel disease. Adjusted for age, sex, diabetes, hypertension, smoking and lipid-lowering regimen.",
                          nrow(dx), sum(dx$mvd))) +
  theme_bw(15) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.y = element_blank(),
        legend.position = "top", legend.title = element_blank(),
        plot.subtitle = element_text(size = 11, colour = "grey30"),
        axis.text = element_text(size = 14, colour = "grey10"))

ggsave(out("FIGURE_multivessel.png"), FIGURE_multivessel, width = 11, height = 5, dpi = 300)
message("=== FIGURE written: FIGURE_multivessel.png (per SD, continuous) ===")

message("\n============================================================")
message("Four outputs, two of them NEW:")
message("  TABLE_multivessel.csv           per SD: LDL-C, apoB, residual")
message("  FIGURE_multivessel.png          the same, as a forest plot")
message("  TABLE_multivessel_groups.csv    NEW - 2x2, both-low as reference")
message("  FIGURE_multivessel_groups.png   NEW - the same, as a forest plot")
message("Files now in ", OUT, ":")
print(sort(list.files(OUT, pattern = "multivessel")))
message("============================================================")
