# =============================================================================
# Discordance between apoB and LDL-C in LipidCardio.
#   1   prevalence of discordance - residual method only
#   1b  attainment of apoB targets among patients at LDL-C target
#   2   phenotype of the discordant patients
#   3   the two axes of discordance, TRL and Lp(a)
# Run after analysis.R (needs `an`).
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

LPA_HIGH <- 125  # nmol/L, 2026 ACC/AHA
TG_HIGH  <- 150  # mg/dL
y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1

wil <- function(k, n) { p <- k/n; z <- 1.96; d <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/d; m <- (p + z^2/(2*n))/d
  c(pct = 100*p, lo = 100*max(0, m-h), hi = 100*min(1, m+h)) }

# =============================================================================
# 1  Prevalence of discordance - RESIDUAL METHOD
#
# disc / res_high / res_low come from analysis.R: the residual of apoB on a
# spline in LDL-C, split at +/-1 SD. Orthogonal to LDL-C by construction, so
# the categories carry no information about the achieved LDL-C level. This is
# the definition used in Cole et al., J Clin Lipidol 2026, and it is the only
# definition used here; the guideline cut-points appear below as targets, not
# as a second definition of discordance.
# =============================================================================
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

ph <- an %>%
  mutate(         nonhdl   = cholesterin - hdl,
         n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0, TRUE ~ NA_real_),
         mvd      = n_vessel >= 2,
         group    = disc)

prev1 <- function(flag, lab) {
  d <- bind_rows(
    ph %>% mutate(g = "Overall"),
    ph %>% filter(!is.na(regimen)) %>% mutate(g = as.character(regimen))) %>%
    group_by(g) %>%
    summarise(n = sum(!is.na(.data[[flag]])),
              k = sum(.data[[flag]], na.rm = TRUE), .groups = "drop")
  ci <- t(mapply(wil, d$k, d$n))
  d$pct <- ci[, 1]; d$lo <- ci[, 2]; d$hi <- ci[, 3]
  d$direction <- lab
  d
}

prev <- bind_rows(prev1("res_high", "apoB higher than predicted"),
                  prev1("res_low",  "apoB lower than predicted")) %>%
  mutate(g = factor(g, c("Overall", levels(an$regimen))),
         txt = sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, pct, lo, hi))

TABLE_prevalence <- prev %>% select(direction, g, txt) %>%
  pivot_wider(names_from = g, values_from = txt) %>% as.data.frame()
message("\n=== TABLE: prevalence of discordance (residual method), n/N, % (95% CI) ===")
print(TABLE_prevalence, right = FALSE, row.names = FALSE)
write.csv(TABLE_prevalence, out("TABLE_prevalence.csv"), row.names = FALSE)

for (f in c("res_high", "res_low"))
  message(sprintf("%s across regimens: p = %.3g", f,
    chisq.test(table(ph$regimen, ph[[f]]))$p.value))

FIGURE1 <- ggplot(prev, aes(g, pct, fill = direction)) +
  geom_col(position = position_dodge(.75), width = .66) +
  geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(.75),
                width = .15, colour = "grey30", linewidth = .5) +
  geom_text(aes(y = hi + .6, label = sprintf("%.1f", pct)),
            position = position_dodge(.75), size = 4.3, colour = "grey20") +
  scale_fill_manual(values = c("apoB higher than predicted" = "#D55E00",
                               "apoB lower than predicted"  = "#0072B2")) +
  scale_y_continuous(expand = expansion(mult = c(0, .14))) +
  labs(x = NULL, y = "Prevalence of discordance (%)") +
  theme_bw(14) + theme(legend.position = "top", legend.title = element_blank(),
                       panel.grid.minor = element_blank(),
                       panel.grid.major.x = element_blank(),
                       axis.text.x = element_text(angle = 12, hjust = 1))
ggsave(out("FIGURE1_prevalence.png"), FIGURE1, width = 8, height = 5.5, dpi = 300)
message("=== FIGURE 1 written: FIGURE1_prevalence.png ===")

# =============================================================================
# 1b  apoB at target among patients who have reached the LDL-C target
#
# Cole et al. (J Clin Lipidol 2026) report this at three LDL-C targets against
# two kinds of apoB target: the one the guideline pairs with it, and the apoB
# value sitting at the same percentile of the UNTREATED distribution. The
# second matters because a pairing that is not equipotent manufactures
# apparent discordance in whichever direction the mismatch runs. Both are
# reported here, for the ESC/EAS and the ACC/AHA pairings.
# =============================================================================
LDL_T    <- c(100,  70,  55)
APOB_ESC <- c(100,  80,  65)    # ESC/EAS 2019: moderate / high / very high risk
APOB_AHA <- c( 90,  70,  55)    # ACC/AHA 2026 pairings, as used by Cole et al.

untx <- an %>% filter(regimen == levels(an$regimen)[1])   # untreated reference
message(sprintf("\nUntreated reference for percentile equivalents: n = %d", nrow(untx)))

above <- function(d, t) sprintf("%d (%.1f)", sum(d$apob_mgdl >= t, na.rm = TRUE),
                                100*mean(d$apob_mgdl >= t, na.rm = TRUE))

TABLE_targets <- bind_rows(lapply(seq_along(LDL_T), function(i) {
  L <- LDL_T[i]
  d <- ph %>% filter(ldl < L)
  q <- mean(untx$ldl < L, na.rm = TRUE)                   # percentile of the LDL-C target
  eq <- as.numeric(quantile(untx$apob_mgdl, q, na.rm = TRUE))
  data.frame(
    `LDL-C target`            = L,
    `at LDL-C target, n`      = nrow(d),
    `LDL-C percentile`        = sprintf("%.1f", 100*q),
    `ESC apoB target`         = APOB_ESC[i],
    `above ESC target`        = above(d, APOB_ESC[i]),
    `ACC/AHA apoB target`     = APOB_AHA[i],
    `above ACC/AHA target`    = above(d, APOB_AHA[i]),
    `percentile-equiv. apoB`  = sprintf("%.0f", eq),
    `above percentile equiv.` = above(d, eq),
    `residual-discordant, n (%)` = sprintf("%d (%.1f)", sum(d$res_high, na.rm = TRUE),
                                           100*mean(d$res_high, na.rm = TRUE)),
    check.names = FALSE)
}))
message("\n=== TABLE: apoB above target among patients at each LDL-C target ===")
print(TABLE_targets, right = FALSE, row.names = FALSE)
write.csv(TABLE_targets, out("TABLE_targets.csv"), row.names = FALSE)

message("\nRead the last two columns together: the percentile-equivalent apoB
target shows whether the guideline pairing is equipotent in this cohort, and
the residual column shows how many of the same patients are discordant on the
definition used throughout the rest of the paper.")

# =============================================================================
# 2  Phenotype tables
#
# Patients are grouped by the residual categories throughout: Concordant,
# apoB high, apoB low.
# =============================================================================
message("\nGrouping for the descriptive tables:")
print(table(ph$group))

# --- the two axes, defined once and used by every table below ----------------
# Triglycerides, HDL-C and HbA1c are not three mechanisms but three markers of
# one: triglyceride-rich lipoprotein (TRL) excess under insulin resistance.
# They are therefore treated as a single axis. Lp(a) is genetically determined
# and unrelated to it, hence the two-way split.
ph <- ph %>%
  mutate(
    tg_high  = triglyceride >= TG_HIGH,
    low_hdl  = (hdl < 40 & !female) | (hdl < 50 & female),
    trl_axis = tg_high | low_hdl,
    lpa_high = lp_a >= LPA_HIGH,
    subpheno = factor(case_when(
       trl_axis &  lpa_high ~ "Both axes",
       trl_axis & !lpa_high ~ "TRL only",
      !trl_axis &  lpa_high ~ "Lp(a) only",
      !trl_axis & !lpa_high ~ "Neither"),
      levels = c("Neither","TRL only","Lp(a) only","Both axes")))

# =============================================================================
# 2a  TABLE 1: phenotype by group, built by hand so the columns are exactly
#     what the paper needs. Missing values are ignored (no "Unknown" rows);
#     the n column says how many contributed.
#
#     Tests: overall across the three groups (Kruskal-Wallis / chi-square),
#     then each discordant group against the concordant group (Wilcoxon /
#     Fisher). The pairwise columns are the ones that answer "is the
#     discordant group different from everyone else".
# =============================================================================

# --- find the variables, since the codebook names are German and irregular ---
SEEK <- list(
  pad        = "pavk|pad_|^pad$|periph",
  stroke     = "schlaganfall|apoplex|stroke|insult",
  tia        = "^tia|tia_",
  hf         = "herzinsuff|^hi_|hfref|hfpef|kardiomyop",
  af         = "vorhofflim|^vhf|afib|flimmer",
  ckd        = "niereninsuff|dialyse|^ckd",
  pwv        = "pwv|pulswell|pulse_?wave|cavi|augmentation",
  abi        = "^abi|knoechel|knöchel|ankle",
  alcohol    = "alkohol|alcohol",
  diet       = "ernaehr|ernähr|diet|obst|gemuese|gemüse|fisch|fleisch|vegetar",
  activity   = "sport|bewegung|koerperl|körperl|activity",
  fli        = "^fli$|fatty_?liver",
  fib4       = "^fib4$|fib_?4",
  steatosis  = "steatos|nafld|masld",
  uric       = "harnsaeure|harnsäure|urat|uric",
  homair     = "homa",
  insulin    = "^insulin",
  waisthip   = "^whr$|waist_?hip|taille_?huef")

cands <- lapply(SEEK, function(p) grep(p, names(ph), value = TRUE, ignore.case = TRUE))
message("\n--- variable search in the dataset ---")
for (k in names(cands))
  message(sprintf("%-10s %s", k,
    if (length(cands[[k]])) paste(cands[[k]], collapse = ", ") else "NOT FOUND"))
message("--- check these before trusting Table 1; tell me any wrong match ---\n")
g1 <- function(k) if (length(cands[[k]])) cands[[k]][1] else NA_character_

# --- the variable list, in the order the table should read -------------------
VARS <- c(
  # demographics and anthropometry
  age = "Age, years", sexf = "Female", bmi = "Body mass index, kg/m2",
  taillenumfang = "Waist circumference, cm",
  setNames("Waist-to-hip ratio", g1("waisthip")),
  # clinical
  sbp = "Systolic blood pressure, mmHg", dbp = "Diastolic blood pressure, mmHg",
  htn = "Hypertension", dm = "Type 2 diabetes", smoke = "Current smoking",
  setNames("Alcohol", g1("alcohol")),
  setNames("Physical activity", g1("activity")),
  setNames("Diet", g1("diet")),
  # vascular burden beyond the coronaries
  mi = "Previous myocardial infarction",
  setNames("Peripheral artery disease", g1("pad")),
  setNames("Previous stroke", g1("stroke")),
  setNames("Previous TIA", g1("tia")),
  setNames("Atrial fibrillation", g1("af")),
  setNames("Heart failure", g1("hf")),
  setNames("Ankle-brachial index", g1("abi")),
  setNames("Pulse wave velocity", g1("pwv")),
  # lipids
  cholesterin = "Total cholesterol, mg/dL", ldl = "LDL-C, mg/dL",
  hdl = "HDL-C, mg/dL", nonhdl = "Non-HDL-C, mg/dL",
  triglyceride = "Triglycerides, mg/dL", remnant = "Remnant cholesterol, mg/dL",
  apob_mgdl = "Apolipoprotein B, mg/dL", apoa1 = "Apolipoprotein A1, mg/dL",
  lp_a = "Lp(a), nmol/L",
  # cardiometabolic and hepatic
  hba1c = "HbA1c, %", glucose = "Glucose, mg/dL",
  setNames("Insulin", g1("insulin")), setNames("HOMA-IR", g1("homair")),
  setNames("Uric acid", g1("uric")),
  gpt = "ALT, U/L", ggt = "GGT, U/L",
  setNames("Fatty liver index", g1("fli")),
  setNames("FIB-4", g1("fib4")),
  crp = "C-reactive protein, mg/L", egfr = "eGFR, mL/min/1.73m2",
  # treatment and coronary anatomy
  regimen = "Lipid-lowering regimen", on_eze = "Ezetimibe",
  n_vessel = "Diseased vessels, n", mvd = "Multivessel disease")
VARS <- VARS[!is.na(names(VARS)) & names(VARS) != "NA"]

# sex may be stored under any of these names; take the first that exists
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(ph))
if (length(sexv)) {
  names(VARS)[names(VARS) == "sexf"] <- sexv[1]
} else message("WARNING: no sex variable found - Table 1 will have no sex row.")

missing_vars <- setdiff(names(VARS), names(ph))
if (length(missing_vars))
  message("Not in the dataset, so left out of the tables: ",
          paste(missing_vars, collapse = ", "))
VARS <- VARS[names(VARS) %in% names(ph)]
message("Variables entering Table 1: ", length(VARS))

# --- yes/no recoding for the binary items we built ourselves -----------------
BIN <- intersect(names(VARS), c("htn","dm","smoke","mi","mvd","on_eze","sexf",
                                unlist(cands[c("pad","stroke","tia","af","hf")])))
ph <- ph %>% mutate(across(all_of(BIN), ~ {
  if (is.logical(.x)) .x else y1(.x) }))

# --- the row builders --------------------------------------------------------
LV_ALL <- NULL
fmed <- function(x) sprintf("%.1f (%.1f-%.1f)", median(x), quantile(x, .25),
                            quantile(x, .75))
fpct <- function(x) sprintf("%d (%.1f)", sum(x), 100*mean(x))
# named fmtp, not pf: pf() is the F distribution in stats and must not be masked
fmtp <- function(p) if (is.na(p)) "-" else if (p < .001) "<0.001" else sprintf("%.3f", p)

# One table builder, used twice: grouped by regimen for the baseline table and
# by discordance category for the phenotype table. Missing values are dropped
# row by row; n is the number of patients who contributed.
build_tab <- function(gcol, vars, pairwise = TRUE) {
  G  <- droplevels(as.factor(ph[[gcol]]))
  LV <- levels(G); REF <- LV[1]
  vars <- vars[names(vars) %in% names(ph)]

  one <- function(v, lab) {
    xa <- ph[[v]][!is.na(ph[[v]])]                 # Overall: the whole cohort
    ok <- !is.na(ph[[v]]) & !is.na(G)              # group columns: known group only
    x  <- ph[[v]][ok]; g <- factor(as.character(G[ok]), LV)
    if (length(x) < 10) return(NULL)
    pad <- if (pairwise) c(pw1 = "", pw2 = "") else NULL

    if (is.factor(x) || is.character(x)) {                  # one row per level
      x <- droplevels(as.factor(x))
      p <- suppressWarnings(chisq.test(table(g, x))$p.value)
      head <- c(Variable = lab, n = length(xa), Overall = "",
                setNames(rep("", length(LV)), LV), p = fmtp(p), pad)
      body <- lapply(levels(x), function(l)
        c(Variable = paste0("   ", l), n = length(xa),
          Overall = fpct(droplevels(as.factor(xa)) == l),
          tapply(x == l, g, fpct)[LV], p = "", pad))
      return(bind_rows(c(list(head), body)))
    }

    bin <- is.logical(x) || all(x %in% c(0, 1))
    x <- as.numeric(x)
    f <- if (bin) function(z) fpct(z == 1) else fmed
    pall <- if (bin) suppressWarnings(chisq.test(table(g, x))$p.value)
            else kruskal.test(x ~ g)$p.value
    r <- c(Variable = lab, n = length(xa), Overall = f(as.numeric(xa)),
           tapply(x, g, f)[LV], p = fmtp(pall))
    if (pairwise) {
      pw <- function(l) {
        k <- g %in% c(REF, l); if (sum(g == l) < 3) return(NA)
        if (bin) fisher.test(table(g[k], x[k]))$p.value
        else suppressWarnings(wilcox.test(x[k] ~ droplevels(g[k]))$p.value) }
      r <- c(r, pw1 = fmtp(pw(LV[2])), pw2 = fmtp(pw(LV[3])))
    }
    bind_rows(r)
  }

  nrow_hdr <- c(Variable = "Patients, n", n = nrow(ph), Overall = as.character(nrow(ph)),
                setNames(as.character(as.vector(table(G)[LV])), LV), p = "",
                if (pairwise) c(pw1 = "", pw2 = "") else NULL)
  if (sum(is.na(G)))
    message(sprintf("Note: %d patients have no %s and appear only in the Overall column.",
                    sum(is.na(G)), gcol))
  tb <- as.data.frame(bind_rows(c(list(nrow_hdr),
          lapply(names(vars), function(v) one(v, vars[[v]])))))
  names(tb)[names(tb) == "p"] <- "p overall"
  if (pairwise && length(LV) >= 3)
    names(tb)[match(c("pw1","pw2"), names(tb))] <-
      c(paste0("p: ", LV[2], " vs ", REF), paste0("p: ", LV[3], " vs ", REF))
  tb
}

# --- TABLE 1: baseline characteristics of the whole cohort, no grouping ------
describe1 <- function(vars) {
  vars <- vars[names(vars) %in% names(ph)]
  rows <- lapply(names(vars), function(v) {
    x <- ph[[v]]; x <- x[!is.na(x)]
    if (length(x) < 10) return(NULL)
    if (is.factor(x) || is.character(x)) {                  # one row per level
      x <- droplevels(as.factor(x))
      return(bind_rows(c(
        list(c(Variable = vars[[v]], n = length(x), Overall = "")),
        lapply(levels(x), function(l)
          c(Variable = paste0("   ", l), n = length(x), Overall = fpct(x == l))))))
    }
    bin <- is.logical(x) || all(x %in% c(0, 1))
    x <- as.numeric(x)
    bind_rows(c(Variable = vars[[v]], n = length(x),
                Overall = if (bin) fpct(x == 1) else fmed(x)))
  })
  as.data.frame(bind_rows(c(
    list(c(Variable = "Patients, n", n = nrow(ph), Overall = as.character(nrow(ph)))),
    rows)))
}

TABLE1_baseline <- describe1(c(VARS, disc = "Discordance category"))
message("\n=== TABLE 1: baseline characteristics of the cohort ===")
message("Continuous: median (IQR). Categorical: n (%). Missing ignored; n = contributors.")
print(TABLE1_baseline, right = FALSE, row.names = FALSE)
write.csv(TABLE1_baseline, out("TABLE1_baseline.csv"), row.names = FALSE)

# --- TABLE 2: the same variables by discordance category ---------------------
TABLE2_phenotype <- build_tab("group", vars = VARS, pairwise = TRUE)
message("\n=== TABLE 2: phenotype by discordance category ===")
message("Last two columns: each discordant group against the concordant group.")
print(TABLE2_phenotype, right = FALSE, row.names = FALSE)
write.csv(TABLE2_phenotype, out("TABLE2_phenotype.csv"), row.names = FALSE)
# =============================================================================
# 2b  Table 2: the TRL and Lp(a) axes by group
# =============================================================================
pctf <- function(x) sprintf("%d (%.1f)", sum(x), 100*mean(x))
medf <- function(x) sprintf("%.0f (%.0f-%.0f)", median(x), quantile(x, .25),
                            quantile(x, .75))

row2 <- function(v, f) {                        # one row: every group, plus p
  d <- ph %>% filter(!is.na(.data[[v]]))
  s <- d %>% group_by(group) %>%
    summarise(txt = f(.data[[v]]), .groups = "drop")
  p <- if (is.logical(d[[v]]))
         suppressWarnings(chisq.test(table(d$group, d[[v]]))$p.value)
       else kruskal.test(d[[v]] ~ d$group)$p.value
  c(setNames(s$txt, as.character(s$group)), n = nrow(d),
    p = if (p < 0.001) "<0.001" else sprintf("%.3f", p))
}

ROWS <- list(
  c("triglyceride", "Triglycerides, mg/dL",           "med"),
  c("hdl",          "HDL-C, mg/dL",                    "med"),
  c("remnant",      "Remnant cholesterol, mg/dL",      "med"),
  c("hba1c",        "HbA1c, %",                        "med"),
  c("lp_a",         "Lp(a), nmol/L",                   "med"),
  c("tg_high",      "Triglycerides >=150 mg/dL",       "pct"),
  c("low_hdl",      "Low HDL-C (<40 men, <50 women)",  "pct"),
  c("trl_axis",     "TRL axis (either)",               "pct"),
  c("lpa_high",     "Lp(a) >=125 nmol/L",              "pct"),
  c("dm",           "Type 2 diabetes",                 "pct"))
ROWS <- Filter(function(r) r[1] %in% names(ph), ROWS)

TABLE3a <- as.data.frame(bind_rows(lapply(ROWS, function(r)
  c(Feature = r[2], row2(r[1], if (r[3] == "med") medf else pctf)))))

sp <- table(ph$group, ph$subpheno)
TABLE3b <- as.data.frame.matrix(round(100*prop.table(sp, 1), 1))
TABLE3b <- cbind(Group = rownames(TABLE3b), n = as.vector(rowSums(sp)), TABLE3b)
rownames(TABLE3b) <- NULL

message("\n=== TABLE 3a: lipid axes by group, median (IQR) or n (%) ===")
print(TABLE3a, right = FALSE)
message("\n=== TABLE 3b: mutually exclusive sub-phenotypes, row % ===")
print(TABLE3b, right = FALSE)
message(sprintf("Chi-square across groups: p = %.3g", chisq.test(sp)$p.value))
write.csv(TABLE3a, out("TABLE3a_axes.csv"), row.names = FALSE)
write.csv(TABLE3b, out("TABLE3b_subphenotypes.csv"), row.names = FALSE)

# =============================================================================
# 3  Within the apoB-high group: are the two axes independent?
# =============================================================================
hi <- ph %>% filter(res_high)
message(sprintf(
  "\nAmong %d patients with apoB high for their LDL-C (residual definition): TRL axis %.0f%%, Lp(a) %.0f%%, both %.0f%%, neither %.0f%%. Overlap (both / either) = %.0f%%.",
  nrow(hi), 100*mean(hi$trl_axis, na.rm = TRUE),
  100*mean(hi$lpa_high, na.rm = TRUE),
  100*mean(hi$subpheno == "Both axes", na.rm = TRUE),
  100*mean(hi$subpheno == "Neither", na.rm = TRUE),
  100*mean(hi$subpheno == "Both axes", na.rm = TRUE) /
    mean(hi$trl_axis | hi$lpa_high, na.rm = TRUE)))
print(chisq.test(table(hi$trl_axis, hi$lpa_high)))

# --- Table 3: the two sub-phenotypes side by side ----------------------------
TABLE4 <- hi %>% filter(subpheno != "Neither") %>% droplevels() %>%
  group_by(subpheno) %>%
  summarise(n = n(),
            Age = medf(age[!is.na(age)]),
            `LDL-C` = medf(ldl[!is.na(ldl)]),
            apoB = medf(apob_mgdl[!is.na(apob_mgdl)]),
            Triglycerides = medf(triglyceride[!is.na(triglyceride)]),
            `HDL-C` = medf(hdl[!is.na(hdl)]),
            `Lp(a)` = medf(lp_a[!is.na(lp_a)]),
            HbA1c = sprintf("%.1f", median(hba1c, na.rm = TRUE)),
            `Diabetes, %` = round(100*mean(dm, na.rm = TRUE)),
            .groups = "drop")
message("\n=== TABLE 4: the two sub-phenotypes of apoB-high discordance ===")
print(as.data.frame(TABLE4), right = FALSE)
write.csv(TABLE4, out("TABLE4_subphenotypes_apobhigh.csv"),
          row.names = FALSE)

# --- Figure 2: sub-phenotypes, DISCORDANT groups only ------------------------
FIGURE2 <- ph %>% filter(!is.na(subpheno), res_high | res_low) %>%
  droplevels() %>%
  count(group, subpheno) %>% group_by(group) %>% mutate(pct = 100*n/sum(n)) %>%
  ungroup() %>%
  ggplot(aes(group, pct, fill = subpheno)) +
  geom_col(width = .58, colour = "white", linewidth = .6) +
  geom_text(aes(label = ifelse(pct >= 5, sprintf("%.0f%%", pct), "")),
            position = position_stack(vjust = .5), size = 4.4, colour = "grey15") +
  scale_fill_manual(values = c("Neither" = "grey78", "TRL only" = "#E69F00",
                               "Lp(a) only" = "#009E73", "Both axes" = "#CC79A7")) +
  scale_y_continuous(expand = expansion(mult = c(0, .02))) +
  scale_x_discrete(labels = function(x) gsub(", ", ",\n", x)) +
  labs(x = NULL, y = "Discordant patients (%)") +
  theme_bw(14) + theme(legend.position = "top", legend.title = element_blank(),
                       panel.grid.minor = element_blank(),
                       panel.grid.major.x = element_blank())
ggsave(out("FIGURE2_subphenotypes.png"), FIGURE2, width = 7, height = 5.5, dpi = 300)

message("\n============================================================")
message("Objects in your session:")
message("  TABLE_prevalence                 prevalence, residual method")
message("  TABLE_targets                    apoB above target at each LDL-C target")
message("  TABLE1                           phenotype by discordance category")
message("  TABLE3a / TABLE3b                TRL and Lp(a) axes")
message("  TABLE3                           the two sub-phenotypes")
message("  FIGURE1 / FIGURE2                the two figures")
message("Files written to ", OUT, ":")
print(sort(list.files(OUT, pattern = "^(TABLE|FIGURE)")))
message("============================================================")
