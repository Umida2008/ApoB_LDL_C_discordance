# =============================================================================
# SENSITIVITY ANALYSIS: coronary disease extent using the discordance
# definition of Du et al. (Eur J Prev Cardiol 2026), for direct comparability
# with that paper.
#
# Their definition: each participant's baseline percentile of LDL-C and of apoB
# is computed within the cohort; a difference of more than 10 percentile units
# defines discordance, in the direction of whichever marker is higher.
#
# The residual definition remains primary throughout the paper. This script
# exists so that the same question can be asked in their terms, and both
# answers are reported whatever they show.
# =============================================================================

library(dplyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

GAP <- 10                                   # percentile units, per Du et al.
y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
tf <- function(x) if (is.logical(x)) x & !is.na(x) else y1(x)
has <- function(v) v %in% names(an)
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(an))[1]
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

pr <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))

dx <- an %>%
  mutate(p_ldl  = pr(ldl), p_apob = pr(apob_mgdl),
         gap    = p_apob - p_ldl,                       # positive = apoB higher
         du = factor(case_when(gap >  GAP ~ "Discordantly high apoB",
                               gap < -GAP ~ "Discordantly low apoB",
                               TRUE       ~ "Concordant"),
                     levels = c("Concordant", "Discordantly high apoB",
                                "Discordantly low apoB")),
         z_gap = as.numeric(scale(gap)),
         z_age = as.numeric(scale(age)),
         sexb  = droplevels(as.factor(.data[[sexv]])),
                  statin = tf(on_statin),
         eze    = if (has("on_eze")) tf(on_eze) else
                  if (has("eze_add")) tf(eze_add) else FALSE,
         pcsk   = if (has("on_pcsk9")) tf(on_pcsk9) else FALSE,
         n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0,
                              TRUE ~ NA_real_),
         obstr = n_vessel >= 1, mvd = n_vessel >= 2) %>%
  filter(!is.na(n_vessel))

# --- arterial territories (exact codebook names) -------------------------------
# erkr_kardiovask is a checkbox list: ___7 = PAVK, ___10 = Erkrankung der
# hirnversorgenden Gefaesse (carotid). erkr_apoplex is a checkbox list:
# ___1-___3 = stroke (1x, 2x, 3x), ___4 = TIA.
# Coronary = obstructive disease at the index angiogram. Polyvascular disease =
# at least two territories. Because obstructive coronary disease is present in
# most of this cohort, the extracoronary variable is reported beside it.
cb <- function(v) if (v %in% names(dx)) y1(dx[[v]]) else {
  message("NOT in the data: ", v); rep(FALSE, nrow(dx)) }

dx <- dx %>% mutate(
  pavk        = cb("erkr_kardiovask___7"),
  carotid     = cb("erkr_kardiovask___10"),
  stroke_any  = cb("erkr_apoplex___1") | cb("erkr_apoplex___2") |
                cb("erkr_apoplex___3"),
  tia         = cb("erkr_apoplex___4"),
  terr_cor    = obstr,
  terr_periph = pavk,
  terr_cereb  = stroke_any | tia | carotid,
  n_terr      = terr_cor + terr_periph + terr_cereb,
  polyvasc    = n_terr >= 2,
  extracor    = terr_periph | terr_cereb)

message(sprintf("\nPAVK %d, carotid %d, stroke %d, TIA %d",
                sum(dx$pavk), sum(dx$carotid), sum(dx$stroke_any), sum(dx$tia)))
message(sprintf("Territories: coronary %d, peripheral %d, cerebrovascular %d",
                sum(dx$terr_cor), sum(dx$terr_periph), sum(dx$terr_cereb)))
print(table(`territories affected` = dx$n_terr))
message(sprintf("Polyvascular (>=2 territories): %d (%.1f%%); extracoronary: %d (%.1f%%)",
                sum(dx$polyvasc), 100*mean(dx$polyvasc),
                sum(dx$extracor), 100*mean(dx$extracor)))

# -----------------------------------------------------------------------------
SAMPN <- c("All patients", "Untreated", "On lipid-lowering therapy")
pick <- function(sn, dat) switch(sn,
  "All patients" = dat,
  "Untreated"    = dat %>% filter(!statin, !eze, !pcsk),
  "On lipid-lowering therapy" = dat %>% filter(statin, !pcsk))

CONF <- c("z_age", "sexb", "dm", "htn", "smoke")

# Treatment is the dominant confounder in the whole cohort, so it enters the
# model wherever it varies; in the single-treatment strata it is dropped
# because it has only one level there.
covs_for <- function(dat) c(CONF,
  if (exists("regimen", dat) && nlevels(droplevels(as.factor(dat$regimen))) > 1)
    "regimen"
  else if (length(unique(dat$statin)) > 1) "statin")


fit1 <- function(dat, outcome, expr, keep, label, model) {
  cv <- covs_for(dat)
  f <- as.formula(paste(outcome, "~", expr, "+", paste(cv, collapse = " + ")))
  m <- try(glm(f, binomial, dat), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  s <- summary(m)$coefficients
  j <- grep(keep, rownames(s))[1]
  if (is.na(j)) return(NULL)
  data.frame(outcome = outcome, exposure = label, model = model,
             covariates = paste(cv, collapse = ", "),
             or = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,2]),
             hi = exp(s[j,1] + 1.96*s[j,2]), p = s[j,4],
             n = nobs(m), events = sum(m$y), row.names = NULL)
}

TABLE_du <- bind_rows(lapply(SAMPN, function(sn) {
  dat <- droplevels(pick(sn, dx))
  bind_rows(lapply(c("obstr", "mvd", "polyvasc"), function(o) bind_rows(
    fit1(dat, o, "du", "duDiscordantly high", "Discordantly high apoB vs concordant",
         "Du categories"),
    fit1(dat, o, "du", "duDiscordantly low",  "Discordantly low apoB vs concordant",
         "Du categories"),
    fit1(dat, o, "z_gap", "z_gap", "Percentile gap, per SD", "Continuous gap")
  ))) %>% mutate(sample = sn, .before = 1)
})) %>%
  mutate(outcome = recode(outcome, obstr = "Obstructive CAD",
                          mvd = "Multivessel disease",
                          polyvasc = "Polyvascular disease"),
         lab  = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)))

message("\n=== TABLE: disease extent, Du et al. discordance definition ===")
print(TABLE_du, digits = 3, row.names = FALSE)
write.csv(TABLE_du, out("TABLE_extent_du.csv"), row.names = FALSE)

# agreement between the two definitions, for the methods section
if ("disc" %in% names(an)) {
  message("\nAgreement between the residual definition and Du's:")
  print(addmargins(table(residual = dx$disc, Du = dx$du)))
  message(sprintf("Concordance of the two classifications: %.1f%%",
                  100*mean(as.character(dx$disc) == c("Concordant",
                    "apoB high", "apoB low")[as.integer(dx$du)], na.rm = TRUE)))
}

FIGURE_du <- TABLE_du %>% filter(sample == "All patients") %>%
  mutate(exposure = factor(exposure, rev(unique(exposure)))) %>%
  ggplot(aes(or, exposure)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .18,
                linewidth = .7, colour = "#0072B2") +
  geom_point(size = 3.2, colour = "#0072B2") +
  geom_text(aes(label = paste0(lab, "   ", plab)), hjust = 0, size = 3.8,
            colour = "grey15", nudge_y = .25) +
  facet_wrap(~ outcome, ncol = 1) +
  scale_x_log10(expand = expansion(mult = c(.08, .7))) +
  labs(x = "Adjusted odds ratio", y = NULL) +
  theme_bw(13) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       strip.text = element_text(face = "bold", hjust = 0))
ggsave(out("FIGURE_extent_du.png"), FIGURE_du, width = 11, height = 6, dpi = 300)
message("\nWritten: TABLE_extent_du.csv and FIGURE_extent_du.png")
