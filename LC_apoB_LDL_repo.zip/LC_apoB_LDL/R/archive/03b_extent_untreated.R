# =============================================================================
# Coronary disease extent in patients on NO lipid-lowering therapy at all:
# no statin, no ezetimibe, no PCSK9 inhibitor. Run after analysis.R.
#
# This is the only sample in which LDL-C and apoB mean what they appear to
# mean, because nothing has lowered them and treatment cannot encode how
# severe the disease was already known to be.
# =============================================================================

library(dplyr); library(ggplot2)

# Each script can be run on its own: analysis.R caches the cohort as an.rds,
# and this block loads it when the session does not already hold it.
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an")) {
  .f <- out("an.rds")
  if (file.exists(.f)) { an <- readRDS(.f); message("loaded `an` from ", .f) }
  else stop("Run analysis.R once first; it builds `an` and saves ", .f)
}


if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)

message("### 03b_extent_untreated.R  -  version 2026-09-24c (one row per estimate,",
        " exposure named once, no subtitle, PNG) ###")

# Delete any previous version of this figure first, so that a failure part way
# through cannot leave a stale file behind that looks like a fresh result.
for (f in c("FIGURE_extent_untreated.png", "FIGURE_extent_untreated.pdf"))
  if (file.exists(out(f))) { file.remove(out(f)); message("removed old ", f) }

y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
tf <- function(x) if (is.logical(x)) x & !is.na(x) else y1(x)   # to TRUE/FALSE
has <- function(v) v %in% names(an)
sexv <- intersect(c("sexf", "female", "sex", "geschlecht"), names(an))[1]
kk <- suppressWarnings(as.numeric(as.character(an$khk_status_akt)))

# --- sample -------------------------------------------------------------------
u <- an %>%
  mutate(across(c(ldl, apob_mgdl, resid, age), ~ as.numeric(scale(.x)),
                .names = "z_{.col}"),                    # SD of the WHOLE cohort
         sexb = droplevels(as.factor(.data[[sexv]])),
                  statin = tf(on_statin),
         eze    = if (has("on_eze")) tf(on_eze) else
                  if (has("eze_add")) tf(eze_add) else FALSE,
         pcsk   = if (has("on_pcsk9")) tf(on_pcsk9) else FALSE,
         n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0,
                              TRUE ~ NA_real_),
         obstr = n_vessel >= 1, mvd = n_vessel >= 2) %>%
  filter(!is.na(n_vessel), !statin, !eze, !pcsk) %>%
  droplevels()

message(sprintf("Untreated (no statin, no ezetimibe, no PCSK9i) with a vessel count: n = %d",
                nrow(u)))
message(sprintf("Obstructive CAD %d (%.1f%%); multivessel disease %d (%.1f%%)",
                sum(u$obstr), 100*mean(u$obstr), sum(u$mvd), 100*mean(u$mvd)))

# --- models -------------------------------------------------------------------
CONF <- c("z_age", "sexb", "dm", "htn", "smoke")
EXP  <- list(c("z_resid",     "z_resid", "Excess apoB at given LDL-C"),
             c("z_apob_mgdl", "z_apob",  "apoB"),
             c("z_ldl",       "z_ldl",   "LDL-C"))

fit1 <- function(outcome, expr, keep, label, covs, model) {
  f <- as.formula(paste(outcome, "~", expr,
        if (length(covs)) paste("+", paste(covs, collapse = " + ")) else ""))
  s <- summary(glm(f, binomial, u))$coefficients
  j <- grep(keep, rownames(s))[1]
  data.frame(outcome = outcome, exposure = label, model = model,
             or = exp(s[j,1]), lo = exp(s[j,1] - 1.96*s[j,2]),
             hi = exp(s[j,1] + 1.96*s[j,2]), p = s[j,4], row.names = NULL)
}

TABLE_untreated <- bind_rows(lapply(c("obstr", "mvd"), function(o) bind_rows(
  lapply(EXP, function(e) fit1(o, e[1], e[2], e[3], character(0), "Unadjusted")),
  lapply(EXP, function(e) fit1(o, e[1], e[2], e[3], CONF,         "Adjusted"))))) %>%
  mutate(outcome = factor(recode(outcome,
           obstr = sprintf("Obstructive CAD (%d/%d)", sum(u$obstr), nrow(u)),
           mvd   = sprintf("Multivessel disease (%d/%d)", sum(u$mvd), nrow(u))),
         levels = c(sprintf("Obstructive CAD (%d/%d)", sum(u$obstr), nrow(u)),
                    sprintf("Multivessel disease (%d/%d)", sum(u$mvd), nrow(u)))),
         exposure = factor(exposure,
           rev(c("LDL-C", "apoB", "Excess apoB at given LDL-C"))),
         model = factor(model, c("Unadjusted", "Adjusted")),
         lab  = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)))

print(TABLE_untreated, digits = 3, row.names = FALSE)
write.csv(TABLE_untreated, out("TABLE_extent_untreated.csv"), row.names = FALSE)

# --- apoB and LDL-C in the same model -----------------------------------------
# Two ways of asking which of the two carries the association. Entering them
# together is the direct way but they correlate strongly, so the standard
# errors inflate. The residual parameterisation asks the identical question
# without that cost, since the residual is orthogonal to LDL-C by construction:
# the LDL-C term is then the effect at average apoB and the residual term is
# the effect of apoB beyond LDL-C.
MUT <- bind_rows(lapply(c("obstr", "mvd"), function(o) bind_rows(
  fit1(o, "z_apob_mgdl + z_ldl", "z_apob",  "apoB, adjusted for LDL-C",
       CONF, "Mutually adjusted"),
  fit1(o, "z_apob_mgdl + z_ldl", "z_ldl",   "LDL-C, adjusted for apoB",
       CONF, "Mutually adjusted"),
  fit1(o, "z_ldl + z_resid",     "z_resid", "Excess apoB at given LDL-C",
       CONF, "Residual parameterisation"),
  fit1(o, "z_ldl + z_resid",     "z_ldl",   "LDL-C, residual in model",
       CONF, "Residual parameterisation")))) %>%
  mutate(outcome = recode(outcome,
           obstr = "Obstructive CAD", mvd = "Multivessel disease"),
         lab = sprintf("%.2f (%.2f-%.2f)", or, lo, hi),
         plab = ifelse(p < 0.001, "p < 0.001", sprintf("p = %.3f", p)))

message("\n=== apoB and LDL-C entered together, untreated patients ===")
print(MUT, digits = 3, row.names = FALSE)
write.csv(MUT, out("TABLE_extent_untreated_mutual.csv"), row.names = FALSE)

message(sprintf("apoB vs LDL-C correlation in this sample: r = %.2f",
                cor(u$ldl, u$apob_mgdl, use = "complete.obs")))
if (requireNamespace("car", quietly = TRUE)) {
  message("VIF, apoB and LDL-C together:")
  print(round(car::vif(glm(obstr ~ z_apob_mgdl + z_ldl + z_age + sexb + dm +
                             htn + smoke, binomial, u)), 2))
  message("VIF, residual parameterisation (should be ~1):")
  print(round(car::vif(glm(obstr ~ z_ldl + z_resid + z_age + sexb + dm +
                             htn + smoke, binomial, u)), 2))
}

# --- figure -------------------------------------------------------------------
# Each estimate gets its own row (exposure x model) rather than two dodged
# points sharing one row, so the printed numbers cannot collide.
lev <- as.vector(t(outer(levels(TABLE_untreated$exposure),
                         c("Adjusted", "Unadjusted"),
                         function(e, m) paste0(e, "  -  ", m))))
pf <- TABLE_untreated %>%
  mutate(row = factor(paste0(exposure, "  -  ", model), levels = lev))

xmax <- max(pf$hi)

# The exposure name is printed once per pair; the two models are told apart by
# colour, not by repeating the word in the axis label.
ylabs <- setNames(ifelse(endsWith(lev, "  -  Adjusted"),
                         sub("  -  Adjusted$", "", lev), ""), lev)

FIGURE_untreated <- ggplot(pf, aes(or, row, colour = model)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22", linewidth = .5) +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y",
                width = .22, linewidth = .7) +
  geom_point(size = 3.2) +
  geom_text(aes(x = xmax * 1.12, label = paste0(lab, "   ", plab)),
            hjust = 0, size = 3.8, colour = "grey15", show.legend = FALSE) +
  facet_wrap(~ outcome, ncol = 1, scales = "free_y") +
  scale_y_discrete(labels = ylabs) +
  scale_colour_manual(values = c(Unadjusted = "grey60", Adjusted = "#0072B2")) +
  scale_x_log10(limits = c(min(pf$lo) * 0.92, xmax * 2.6),
                breaks = c(0.5, 0.75, 1, 1.5, 2, 3),
                expand = expansion(mult = c(0.02, 0))) +
  labs(x = "Odds ratio per SD", y = NULL) +
  theme_bw(13) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.y = element_blank(),
        legend.position = "top", legend.title = element_blank(),
        strip.text = element_text(face = "bold", hjust = 0),
        axis.text.y = element_text(size = 12, colour = "grey10"),
        plot.margin = margin(6, 10, 6, 6))

ggsave(out("FIGURE_extent_untreated.png"), FIGURE_untreated,
       width = 12, height = 7, dpi = 300)
message("\nWritten: ", out("FIGURE_extent_untreated.png"), " at ",
        format(file.info(out("FIGURE_extent_untreated.png"))$mtime, "%H:%M:%S"))
message("If that timestamp is not the current time, you ran an older copy of this file.")
