# =============================================================================
# MACE - WHOLE COHORT. Primary definition: percentile gap (Du et al.).
# Uses the existing `mace` and `mace_yrs` (3-year follow-up module: death, MI,
# stroke with event dates), as in 04_mace.R. Cox regression; unadjusted and
# adjusted models on the same patients. Run after analysis.R.
# =============================================================================

library(dplyr); library(survival); library(ggplot2); library(patchwork)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num    <- function(x) suppressWarnings(as.numeric(as.character(x)))
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
if (!all(c("gap_z", "du") %in% names(an)))
  an <- an %>% mutate(
    gap = pctile(apob_mgdl) - pctile(ldl), gap_z = gap / sd(gap, na.rm = TRUE),
    du  = factor(case_when(gap > 10 ~ "Discordantly high apoB",
                           gap < -10 ~ "Discordantly low apoB", TRUE ~ "Concordant"),
                 levels = c("Concordant", "Discordantly high apoB",
                            "Discordantly low apoB")))
if (!"llt" %in% names(an))
  an <- an %>% mutate(llt = factor(case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
      on_statin & high ~ "High-intensity statin",
      on_statin        ~ "Moderate-intensity statin",
      TRUE             ~ "No lipid-lowering therapy"),
    levels = c("No lipid-lowering therapy", "Moderate-intensity statin",
               "High-intensity statin", "Other lipid-lowering therapy")))

sv <- an %>% mutate(time = num(mace_yrs), event = num(mace)) %>%
  filter(!is.na(time), !is.na(event), time > 0)
message(sprintf("MACE: %d patients, %d events, median follow-up %.1f years",
                nrow(sv), sum(sv$event), median(sv$time)))
print(sv %>% group_by(du) %>% summarise(n = n(), events = sum(event),
        `rate /100 PY` = round(100*sum(event)/sum(time), 2), .groups = "drop"))

# --- models --------------------------------------------------------------------
COV <- "I(age/10) + female + dm + htn + smoke + llt"
EXP <- list(c("du", "^du"), c("gap_z", "^gap_z"))
cc  <- sv[complete.cases(sv[c("age", "female", "dm", "htn", "smoke", "llt")]), ]

fit1 <- function(e, adj) {
  f <- paste("Surv(time, event) ~", e[1], if (adj) paste("+", COV) else "")
  m <- coxph(as.formula(f), data = cc)
  s <- summary(m)$coefficients; j <- grepl(e[2], rownames(s))
  data.frame(model = if (adj) "Adjusted" else "Unadjusted", term = rownames(s)[j],
             hr = exp(s[j, 1]), lo = exp(s[j, 1] - 1.96*s[j, 3]),
             hi = exp(s[j, 1] + 1.96*s[j, 3]), p = s[j, 5],
             n = m$n, events = m$nevent)
}

fits <- bind_rows(lapply(EXP, function(e) bind_rows(fit1(e, FALSE), fit1(e, TRUE)))) %>%
  mutate(exposure = recode(sub("^du", "", term), gap_z = "Percentile gap, per SD"),
         model    = factor(model, c("Unadjusted", "Adjusted")),
         lab  = sprintf("%.2f (%.2f-%.2f)", hr, lo, hi),
         plab = ifelse(p < .001, "p < 0.001", sprintf("p = %.3f", p)))
rownames(fits) <- NULL

message("\n=== MACE, whole cohort. Hazard ratio vs concordant. ===")
message("Adjusted: age, sex, diabetes, hypertension, smoking, lipid-lowering therapy.")
print(fits %>% select(exposure, model, lab, plab, n, events), row.names = FALSE)
write.csv(fits, out("TABLE_mace_all.csv"), row.names = FALSE)

# --- figure: same layout as the disease-extent figure --------------------------
# One tick and one label per exposure; the two models sit just above and below
# it, told apart by colour, so the printed numbers never collide.
ex  <- unique(fits$exposure)
pos <- setNames(rev(seq_along(ex)), ex)                  # first exposure at top
pf  <- fits %>% mutate(y = pos[exposure] + ifelse(model == "Unadjusted", .18, -.18))
xhi <- max(pf$hi)

FIG <- ggplot(pf, aes(hr, y, colour = model)) +
  geom_vline(xintercept = 1, linetype = "22", colour = "grey55") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .12,
                linewidth = .6) +
  geom_point(size = 2.6) +
  geom_text(aes(label = paste0(lab, "   ", plab)), x = log10(xhi * 1.12),
            hjust = 0, size = 3.3, colour = "grey20", show.legend = FALSE) +
  scale_y_continuous(breaks = pos, labels = names(pos),
                     expand = expansion(add = .45)) +
  scale_colour_manual(values = c(Unadjusted = "grey60", Adjusted = "#0072B2")) +
  scale_x_log10(limits = c(min(pf$lo) * .9, xhi * 2.6)) +
  labs(x = "Hazard ratio for MACE (vs concordant)", y = NULL) +
  theme_bw(12) + theme(panel.grid.minor = element_blank(),
                       panel.grid.major.y = element_blank(),
                       legend.position = "top", legend.title = element_blank(),
                       strip.text = element_text(face = "bold", hjust = 0))
ggsave(out("FIGURE_mace_all.png"), FIG, width = 10, height = 4, dpi = 300)

# --- sensitivity: + multivessel disease (is the association beyond extent?) ----
m_mvd <- coxph(as.formula(paste("Surv(time, event) ~ du +", COV, "+ mvd")),
               data = cc[!is.na(cc$mvd), ])
message("\nSensitivity, adjusted + multivessel disease:")
print(round(summary(m_mvd)$conf.int[grep("^du", names(coef(m_mvd))), -2, drop = FALSE], 2))

# --- cumulative incidence curves (1 - Kaplan-Meier) by discordance group -------
PALK <- c("Concordant" = "grey45", "Discordantly high apoB" = "#D55E00",
          "Discordantly low apoB" = "#0072B2")
km <- survfit(Surv(time, event) ~ du, data = sv)
lr <- survdiff(Surv(time, event) ~ du, data = sv)
p_lr <- pchisq(lr$chisq, length(lr$n) - 1, lower.tail = FALSE)
grp <- sub("du=", "", names(km$strata))

kd <- bind_rows(
  data.frame(time = 0, cum = 0, du = grp),
  data.frame(time = km$time, cum = 100 * (1 - km$surv),
             du = rep(grp, km$strata))) %>% mutate(du = factor(du, names(PALK)))
tt <- 0:floor(max(sv$time))
sk <- summary(km, times = tt, extend = TRUE)
rt <- data.frame(time = sk$time, n = sk$n.risk,
                 du = factor(sub("du=", "", sk$strata), rev(names(PALK))))

P1 <- ggplot(kd, aes(time, cum, colour = du)) +
  geom_step(linewidth = .9) +
  annotate("text", x = 0, y = Inf, hjust = 0, vjust = 1.5, size = 3.8,
           label = ifelse(p_lr < .001, "Log-rank p < 0.001",
                          sprintf("Log-rank p = %.3f", p_lr))) +
  scale_colour_manual(values = PALK) +
  scale_x_continuous(breaks = tt, limits = range(tt)) +
  labs(x = NULL, y = "Cumulative incidence of MACE (%)") +
  theme_bw(12) + theme(panel.grid.minor = element_blank(),
                       legend.position = "top", legend.title = element_blank())
P2 <- ggplot(rt, aes(time, du, label = n, colour = du)) +
  geom_text(size = 3.6, show.legend = FALSE) +
  scale_colour_manual(values = PALK) +
  scale_x_continuous(breaks = tt, limits = range(tt)) +
  labs(x = "Years since index angiography", y = NULL, title = "Number at risk") +
  theme_minimal(11) + theme(panel.grid = element_blank(),
                            plot.title = element_text(size = 11))
ggsave(out("FIGURE_mace_km.png"), P1 / P2 + plot_layout(heights = c(4, 1.1)),
       width = 8, height = 6.5, dpi = 300)
message("Written: TABLE_mace_all.csv, FIGURE_mace_all.png, FIGURE_mace_km.png")
