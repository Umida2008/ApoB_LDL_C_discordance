# =============================================================================
# Central figure for the EJPC Rapid Communication (one figure, five panels).
#   A  apoB vs LDL-C in percentile space: +/-10 band = the Du definition,
#      LDL-C targets shaded/marked, prevalence written into the plot,
#      mg/dL on the top/right axes
#   B  apoB across LDL-C strata (Sniderman style): same LDL-C, wide apoB range;
#      % above apoB 65 and 80 mg/dL per stratum
#   C  clinical profile: % with each characteristic per group (dot plot)
#   D  obstructive CAD and multivessel disease (forest, unadjusted/adjusted)
#   E  MACE: cumulative incidence (left) + hazard ratios (right), one long panel
# Run after analysis.R. Needs dplyr, ggplot2, survival, patchwork.
# =============================================================================

library(dplyr); library(ggplot2); library(survival); library(patchwork)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))
stopifnot(c("du", "gap_z", "llt", "obstr", "mvd", "mace", "mace_yrs") %in% names(an))

num    <- function(x) suppressWarnings(as.numeric(as.character(x)))
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))

GRP  <- c("Concordant", "Discordantly high apoB", "Discordantly low apoB")
PAL  <- setNames(c("grey55", "#D55E00", "#0072B2"), GRP)
PALM <- c(Unadjusted = "grey60", Adjusted = "#0072B2")
th <- theme_bw(10) + theme(panel.grid.minor = element_blank(),
                           plot.tag = element_text(face = "bold", size = 13))
np <- function(sel, l) { x <- an$du[sel] == l; sprintf("%d/%d (%.1f%%)", sum(x), length(x), 100*mean(x)) }

# --- A  percentile scatter with prevalence ----------------------------------------
dA <- an %>% mutate(p_ldl = pctile(ldl), p_apob = pctile(apob_mgdl))
q  <- c(`55` = 100*mean(an$ldl < 55), `70` = 100*mean(an$ldl < 70))
# mg/dL on the secondary axes: identity transform, ticks placed at the
# percentile of each mg/dL value (a quantile transform is not strictly monotonic)
mgax <- function(v, at, name)
  sec_axis(~ ., name = name, labels = at,
           breaks = sapply(at, function(a) 100*mean(v < a, na.rm = TRUE)))
everyone <- rep(TRUE, nrow(an))

A <- ggplot(dA, aes(p_ldl, p_apob, colour = du)) +
  annotate("rect", xmin = 0, xmax = q["70"], ymin = 0, ymax = 100, fill = "grey93") +
  geom_abline(slope = 1, intercept = c(-10, 10), linetype = "22", colour = "grey35") +
  geom_point(size = .9, alpha = .7) +
  geom_vline(xintercept = q, colour = "grey35", linewidth = .3) +
  annotate("text", x = q, y = 1, label = c("LDL-C 55", "LDL-C 70"), angle = 90,
           hjust = 0, vjust = -.5, size = 2.6, colour = "grey25") +
  annotate("label", x = 30, y = 97, hjust = 0, vjust = 1, size = 2.9, colour = PAL[2],
           label.size = 0, fill = alpha("white", .85),
           label = paste0("Discordantly high: ", np(everyone, GRP[2]),
                          "\nat LDL-C < 70: ", np(an$ldl < 70, GRP[2]),
                          "\nat LDL-C < 55: ", np(an$ldl < 55, GRP[2]))) +
  annotate("label", x = 99, y = 3, hjust = 1, vjust = 0, size = 2.9, colour = PAL[3],
           label.size = 0, fill = alpha("white", .85),
           label = paste0("Discordantly low: ", np(everyone, GRP[3]))) +
  scale_colour_manual(values = PAL, name = NULL) +
  scale_x_continuous("LDL-C percentile", limits = c(0, 100), expand = c(0, 0),
    sec.axis = mgax(an$ldl, c(50, 70, 100, 150, 200), "LDL-C (mg/dL)")) +
  scale_y_continuous("ApoB percentile", limits = c(0, 100), expand = c(0, 0),
    sec.axis = mgax(an$apob_mgdl, c(50, 65, 80, 100, 130), "ApoB (mg/dL)")) +
  guides(colour = guide_legend(override.aes = list(size = 2.5, alpha = 1))) +
  th + theme(legend.position = "top") + labs(tag = "A")

# --- B  apoB across LDL-C strata (Sniderman style) --------------------------------
LS <- c("< 55", "55–69", "70–99", "100–129", "≥ 130")
dB <- an %>% mutate(ls = cut(ldl, c(-Inf, 55, 70, 100, 130, Inf), LS, right = FALSE))
lB <- dB %>% group_by(ls) %>%
  summarise(n = n(), a65 = 100*mean(apob_mgdl >= 65), a80 = 100*mean(apob_mgdl >= 80),
            .groups = "drop") %>%
  mutate(lab = sprintf("≥ 65: %.0f%%\n≥ 80: %.0f%%", a65, a80),
         xl  = sprintf("%s\n(n = %d)", ls, n))

B <- ggplot(dB, aes(ls, apob_mgdl)) +
  geom_hline(yintercept = c(65, 80), linetype = "22", colour = "grey40") +
  geom_jitter(aes(colour = du), width = .25, height = 0, size = .8, alpha = .6) +
  geom_boxplot(outlier.shape = NA, fill = NA, width = .55, colour = "grey20", linewidth = .4) +
  geom_text(data = lB, aes(ls, Inf, label = lab), vjust = 1.2, size = 2.6,
            colour = "grey20", lineheight = .9) +
  scale_colour_manual(values = PAL) +
  scale_x_discrete(labels = setNames(lB$xl, lB$ls)) +
  scale_y_continuous(expand = expansion(mult = c(.02, .22))) +
  labs(x = "LDL-C (mg/dL)", y = "ApoB (mg/dL)", tag = "B") +
  th + theme(legend.position = "none", panel.grid.major.x = element_blank())

# --- C  clinical profile dot plot ---------------------------------------------------
whtr <- num(an$taillenumfang) / num(an$groesse)
hsi  <- 8*num(an$gpt)/num(an$got) + num(an$bmi) + 2*an$female + 2*an$dm
CH <- list("Female sex" = an$female, "Type 2 diabetes" = an$dm,
           "Hypertension" = an$htn, "Current smoking" = an$smoke,
           "Central obesity (WHtR ≥ 0.5)" = whtr >= .5,
           "Suspected MASLD (HSI > 36)" = hsi > 36, "eGFR < 60" = an$egfr < 60,
           "Previous MI" = an$mi, "Lp(a) ≥ 125 nmol/L" = an$lp_a >= 125,
           "Triglycerides ≥ 150 mg/dL" = an$triglyceride >= 150)
dC <- bind_rows(lapply(names(CH), function(k) {
  x <- as.logical(CH[[k]]); ok <- !is.na(x)
  p <- suppressWarnings(chisq.test(table(an$du[ok], x[ok]))$p.value)
  data.frame(char = sprintf("%s (p %s)", k, ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))),
             du = GRP, pct = as.numeric(100*tapply(x[ok], an$du[ok], mean))[1:3])
}))
ord <- dC %>% group_by(char) %>%
  summarise(d = pct[du == GRP[2]] - pct[du == GRP[1]]) %>% arrange(d)
dC$char <- factor(dC$char, ord$char)

C <- ggplot(dC, aes(pct, char)) +
  geom_line(aes(group = char), colour = "grey80", linewidth = 1.2) +
  geom_point(aes(colour = du), size = 2.4) +
  scale_colour_manual(values = PAL) +
  scale_x_continuous(limits = c(0, 100), expand = expansion(add = 2)) +
  labs(x = "Patients with the characteristic (%)", y = NULL, tag = "C") +
  th + theme(legend.position = "none")

# --- models for D and E ---------------------------------------------------------------
dd  <- an %>% mutate(time = num(mace_yrs), event = num(mace))
COV <- "+ I(age/10) + female + dm + htn + smoke + llt"
est <- function(o, e, adj, cox = FALSE) {
  v   <- c(if (cox) c("time", "event") else o, e, "age", "female", "dm", "htn", "smoke", "llt")
  dat <- dd[complete.cases(dd[v]), ]; if (cox) dat <- dat[dat$time > 0, ]
  f   <- as.formula(paste(if (cox) "Surv(time, event)" else o, "~", e, if (adj) COV else ""))
  m   <- if (cox) coxph(f, dat) else glm(f, binomial, dat)
  s   <- summary(m)$coefficients; j <- grep(paste0("^", e), rownames(s))
  se  <- s[j, if (cox) 3 else 2]
  data.frame(outcome = o, model = if (adj) "Adjusted" else "Unadjusted",
             term = sub("^du", "", sub("^gap_z$", "Percentile gap, per SD", rownames(s)[j])),
             est = exp(s[j, 1]), lo = exp(s[j, 1] - 1.96*se), hi = exp(s[j, 1] + 1.96*se),
             p = s[j, ncol(s)], n = nrow(dat))
}
fits <- function(o, cox = FALSE) bind_rows(lapply(c("du", "gap_z"), function(e)
  bind_rows(est(o, e, FALSE, cox), est(o, e, TRUE, cox))))

forest <- function(d, xlab) {
  ex <- unique(d$term); pos <- setNames(rev(seq_along(ex)), ex)
  d$y <- pos[d$term] + ifelse(d$model == "Unadjusted", .17, -.17)
  ggplot(d, aes(est, y, colour = factor(model, names(PALM)))) +
    geom_vline(xintercept = 1, linetype = "22", colour = "grey55") +
    geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .12, linewidth = .5) +
    geom_point(size = 1.8) +
    scale_y_continuous(breaks = pos, labels = names(pos), expand = expansion(add = .4)) +
    scale_x_log10() + scale_colour_manual(values = PALM, name = NULL) +
    labs(x = xlab, y = NULL) + th + theme(panel.grid.major.y = element_blank())
}

fD <- bind_rows(fits("obstr"), fits("mvd")) %>%
  mutate(outcome = factor(recode(outcome, obstr = "Obstructive CAD", mvd = "Multivessel disease"),
                          c("Obstructive CAD", "Multivessel disease")))
fE <- fits("mace", cox = TRUE)
write.csv(bind_rows(mutate(fD, outcome = as.character(outcome)), fE),
          out("TABLE_figure_rc_models.csv"), row.names = FALSE)

# --- D  disease extent ----------------------------------------------------------------
D <- forest(fD, "Odds ratio (vs concordant)") + facet_wrap(~ outcome, ncol = 1) +
  theme(legend.position = "top", strip.text = element_text(face = "bold", hjust = 0)) +
  labs(tag = "D")

# --- E  MACE: KM + forest side by side --------------------------------------------------
sv <- dd %>% filter(!is.na(time), !is.na(event), time > 0)
km <- survfit(Surv(time, event) ~ du, data = sv)
lr <- survdiff(Surv(time, event) ~ du, data = sv)
p_lr <- pchisq(lr$chisq, length(lr$n) - 1, lower.tail = FALSE)
g  <- sub("du=", "", names(km$strata))
kd <- bind_rows(data.frame(time = 0, cum = 0, du = g),
                data.frame(time = km$time, cum = 100*(1 - km$surv), du = rep(g, km$strata)))

E1 <- ggplot(kd, aes(time, cum, colour = du)) + geom_step(linewidth = .8) +
  annotate("text", x = 0, y = Inf, hjust = 0, vjust = 1.5, size = 2.9,
           label = sprintf("%d events; log-rank p %s", sum(sv$event),
                           ifelse(p_lr < .001, "< 0.001", sprintf("= %.3f", p_lr)))) +
  scale_colour_manual(values = PAL) +
  scale_x_continuous(breaks = 0:3, limits = c(0, 3)) +
  labs(x = "Years since index angiography", y = "Cumulative MACE (%)", tag = "E") +
  th + theme(legend.position = "none")
E2 <- forest(fE, "Hazard ratio for MACE (vs concordant)") + theme(legend.position = "top")

# --- assemble ---------------------------------------------------------------------------
FIG <- (A | B) / (C | D) / ((E1 | E2) + plot_layout(widths = c(1.3, 1))) +
  plot_layout(heights = c(1.15, 1, .75))
ggsave(out("FIGURE_rc.png"), FIG, width = 13, height = 15, dpi = 300)
message("Written: FIGURE_rc.png and TABLE_figure_rc_models.csv")
