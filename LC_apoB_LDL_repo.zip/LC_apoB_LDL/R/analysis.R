# =============================================================================
# apoB - LDL-C discordance in LipidCardio
# Complete analysis in one file. Needs only your data frame `d`.
#
#   source("analysis.R")
#
# Discordance (primary) = percentile gap, Du et al.: apoB percentile minus
# LDL-C percentile, > +10 high, < -10 low (du / du_high / du_low).
# Residual of apoB on LDL-C (disc / res_high / res_low) = sensitivity only.
# Regimens are No LLT / moderate- /
# high-intensity statin; ezetimibe add-on is carried as a separate supplementary
# comparison, because the statin+ezetimibe group mixes both intensities and
# cannot separate the effect of ezetimibe from that of statin dose.
# Units (codebook): ldl/hdl/cholesterin/triglyceride mg/dL, lp_a nmol/L,
# apob g/L, taillenumfang cm.
# =============================================================================

library(dplyr); library(tidyr); library(ggplot2); library(rms)

DATA <- "/home/umida/Downloads/LipidCardioFU_DATA_2026-09-12_0858.csv"
OUT  <- "/home/umida/Dokumente/LC_apoB_LDL"
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
out <- function(f) file.path(OUT, f)

TG_MAX <- 400
LDL_BREAKS <- c(-Inf, 55, 70, 100, Inf)
LDL_LABELS <- c("<55", "55-69", "70-99", ">=100")
DISC_Z <- 1          # |standardised residual| above this = discordant
MW     <- 512000     # g/mol, apoB-100
RHO    <- 3          # cholesterol per remnant particle, multiple of LDL's

PAL3  <- c("Derived LDL-P" = "#56B4E9", "Remnant" = "#E69F00", "Lp(a)" = "#009E73")
PALD  <- c("Concordant" = "grey65", "Discordantly high apoB" = "#D55E00",
           "Discordantly low apoB" = "#0072B2")
PAL2  <- c("Discordantly high apoB" = "#D55E00",
           "Discordantly low apoB"  = "#0072B2")
PAL4  <- c("#0072B2", "#E69F00", "#009E73", "#CC79A7")

th <- theme_minimal(13) +
  theme(panel.grid.minor = element_blank(),
        axis.text  = element_text(size = 12, colour = "grey20"),
        axis.title = element_text(size = 13),
        strip.text = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12),
        legend.position = "top", legend.title = element_blank())

# The raw export is ALWAYS read fresh. A `d` left in the session from an earlier
# run already has derived columns (e.g. `mi` = previous MI) that overwrite raw
# fields such as the 3-year follow-up `mi` (day of MI), which silently removed
# MIs from MACE.
if (!file.exists(DATA)) stop("Data file not found: ", DATA)
d <- read.csv(DATA, stringsAsFactors = FALSE, na.strings = c("", "NA", "NaN"),
              check.names = TRUE)
message(sprintf("Loaded %d rows and %d columns from %s", nrow(d), ncol(d), DATA))
stopifnot(is.data.frame(d))

# Longitudinal REDCap export (baseline and follow-up on separate rows): collapse
# to one row per patient, keeping the first non-missing value of every field,
# so the follow-up fields sit on the same row as the baseline data.
if (anyDuplicated(d$record_id)) {
  message(sprintf("%d rows for %d patients - collapsing to one row per patient",
                  nrow(d), length(unique(d$record_id))))
  d <- d %>% group_by(record_id) %>%
    summarise(across(everything(), ~ .x[!is.na(.x)][1]), .groups = "drop") %>%
    as.data.frame()
}

# Lab values typed in REDCap text fields can carry a decimal comma, blanks or a
# "<"/">" sign; as.numeric() turns those into NA and silently drops patients.
num <- function(x) suppressWarnings(as.numeric(gsub(",", ".", gsub("[<> ]", "", as.character(x)))))

# any apoB / LDL-C entry that is still not a number is printed here
for (v in c("apob", "ldl")) {
  bad <- !is.na(d[[v]]) & trimws(d[[v]]) != "" & is.na(num(d[[v]]))
  if (any(bad)) { message("Non-numeric ", v, " entries:"); print(d[bad, c("record_id", v)]) }
}

# Age is not in the export; the codebook has geburtsdatum (date of birth) and
# einschluss (inclusion date), both date_dmy. Age at inclusion is derived here
# unless a column called age is already present.
pdate <- function(x) as.Date(as.character(x),
           tryFormats = c("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%Y/%m/%d"))
if (!"age" %in% names(d)) {
  if (all(c("geburtsdatum", "einschluss") %in% names(d))) {
    d$age <- as.numeric(pdate(d$einschluss) - pdate(d$geburtsdatum)) / 365.25
    message(sprintf("age derived from geburtsdatum and einschluss: median %.0f years, %d missing",
                    median(d$age, na.rm = TRUE), sum(is.na(d$age))))
  } else stop("No `age` column, and geburtsdatum / einschluss are not both present.")
}

# =============================================================================
# MACE from the 3-year follow-up module (codebook "Lipidcardio Follow Up
# (3yrs)"): event 1 = ja / 0 = nein (missing = no follow-up); death, mi,
# stroke, hf = day of event.
#   mace      = death, MI or stroke (PRIMARY, 3-point MACE); mace_yrs = first of
#               these days / 365.25, event-free censored at 3 years
#   mace4     = the study's `event` field, i.e. + heart-failure hospitalisation
#               (sensitivity only), with mace4_yrs
# Done here, BEFORE section 1b reuses the name `mi` for previous MI.
# =============================================================================
day_of <- function(x) {                 # "day of event": a date or a day count
  x  <- as.character(x)
  dt <- tryCatch(pdate(x), error = function(e) rep(as.Date(NA), length(x)))
  ifelse(!is.na(dt), as.numeric(dt - pdate(d$einschluss)), num(x))
}
first <- function(m) { f <- suppressWarnings(apply(m, 1, min, na.rm = TRUE))
                       f[!is.finite(f)] <- NA; f }
if ("event" %in% names(d)) {
  days <- sapply(c("death", "mi", "stroke", "hf"), function(v)
            if (v %in% names(d)) day_of(d[[v]]) else rep(NA_real_, nrow(d)))
  ev   <- num(d$event)
  f4   <- first(days); f3 <- first(days[, 1:3, drop = FALSE])
  d$mace      <- ifelse(is.na(ev), NA, as.numeric(!is.na(f3)))
  d$mace_yrs  <- ifelse(is.na(ev), NA, ifelse(is.na(f3), 3*365.25, f3)/365.25)
  d$mace4     <- ev
  d$mace4_yrs <- ifelse(is.na(ev), NA, ifelse(ev == 1, f4, 3*365.25)/365.25)
  names(d)[names(d) == "mi"] <- "fu_mi_day"          # free the name for previous MI
  message(sprintf("Follow-up in %d patients; event = 1 in %d (death %d, MI %d, stroke %d, HF %d)",
                  sum(!is.na(ev)), sum(ev == 1, na.rm = TRUE),
                  sum(!is.na(days[, 1]) & ev %in% 1), sum(!is.na(days[, 2]) & ev %in% 1),
                  sum(!is.na(days[, 3]) & ev %in% 1), sum(!is.na(days[, 4]) & ev %in% 1)))
  message(sprintf("3-point MACE (death/MI/stroke): %d of %d", sum(d$mace, na.rm = TRUE), sum(!is.na(ev))))
  message(sprintf("Check: %d patients with event = 1 but no event day at all (cannot be classified)",
                  sum(ev == 1 & is.na(f4), na.rm = TRUE)))
} else message("No 3-year follow-up module (`event`) in the data - no MACE variables.")
mq  <- function(x) sprintf("%.0f (%.0f-%.0f)", median(x, na.rm = TRUE),
                           quantile(x, .25, na.rm = TRUE),
                           quantile(x, .75, na.rm = TRUE))

# =============================================================================
# 1  Derived variables and regimen
# =============================================================================
# codebook: geschlecht 1 = maennlich, 2 = weiblich. The column is found
# whatever its case (raw or label export); coded or text values both work.
sx <- grep("^(geschlecht|sex|gender|male|female)$", names(d), value = TRUE,
           ignore.case = TRUE)[1]
if (is.na(sx)) {
  print(grep("geschl|sex|gender", names(d), value = TRUE, ignore.case = TRUE))
  stop("No sex column found - candidates printed above; tell me which one.")
}
s <- tolower(trimws(as.character(d[[sx]])))
s[s == "true"] <- "1"; s[s == "false"] <- "0"
d$female <- switch(tolower(sx),
  male   = ifelse(s == "0", TRUE, ifelse(s == "1", FALSE, NA)),
  female = ifelse(s == "1", TRUE, ifelse(s == "0", FALSE, NA)),
  ifelse(s %in% c("2", "weiblich", "female", "w", "f"), TRUE,
  ifelse(s %in% c("1", "männlich", "maennlich", "male", "m"), FALSE, NA)))
message("Sex taken from column: ", sx)

d <- d %>%
  mutate(across(any_of(c("ldl","hdl","cholesterin","triglyceride","hba1c","lp_a",
                         "apob","crp","gpt","bmi","age","taillenumfang",
                         "kreatinin")), num),
         apob_mgdl = apob * 100)
message(sprintf("Sex: %d women, %d men, %d missing",
                sum(d$female, na.rm = TRUE), sum(!d$female, na.rm = TRUE),
                sum(is.na(d$female))))

sl <- tibble::tribble(
  ~code, ~sub,             ~dose,
  1L,"simva",10,   2L,"simva",20,   3L,"simva",30,   4L,"simva",40,
  5L,"simva",60,   6L,"simva",80,   7L,"simva",100,  8L,"atorva",30,
  9L,"atorva",10, 10L,"atorva",20, 11L,"atorva",40, 15L,"atorva",60,
  16L,"atorva",80,17L,"rosuva",5,  18L,"rosuva",10, 19L,"rosuva",20,
  20L,"fluva",20, 21L,"fluva",40,  22L,"prava",10,  23L,"prava",20,
  24L,"prava",40, 25L,"fluva",80,  26L,"rosuva",40)

i <- match(num(d$statine), sl$code)
d$sub  <- sl$sub[i]; d$dose <- sl$dose[i]

# ACC/AHA 2018: high intensity = atorva >=40 or rosuva >=20.
# Ezetimibe users are classified by their STATIN intensity, so the intensity
# groups are internally comparable; ezetimibe add-on is a separate variable.
d <- d %>%
  mutate(
    on_statin = !is.na(sub),
    on_eze    = !is.na(ezetimib) & num(ezetimib) == 1,
    on_pcsk9  = !is.na(pcsk9) & num(pcsk9) %in% 1:2,
    high      = (sub == "atorva" & dose >= 40) | (sub == "rosuva" & dose >= 20),
    regimen = factor(case_when(
      on_pcsk9            ~ NA_character_,             # n = 1
      on_statin & high    ~ "High-intensity statin",
      on_statin           ~ "Moderate-intensity statin",
      on_eze              ~ NA_character_,             # ezetimibe monotherapy
      TRUE                ~ "No LLT"),
      levels = c("No LLT","Moderate-intensity statin","High-intensity statin")),
    statin_use = factor(case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ NA_character_,
      on_statin                        ~ "Statin",
      TRUE                             ~ "No statin"),
      levels = c("No statin","Statin")),
    eze_add = factor(case_when(
      !on_statin | on_pcsk9 ~ NA_character_,
      on_eze                ~ "Statin + ezetimibe",
      TRUE                  ~ "Statin alone"),
      levels = c("Statin alone","Statin + ezetimibe")))

# =============================================================================
# 1b  Cardiovascular risk profile, coded from the codebook
#
# Codebook traps that are handled here once, so no downstream script repeats
# them: diabtyp2 / hypertonie / rauchen_akt are 1 = ja, 2 = nein, but
# herzinfarkt is 1 = NEIN and 2-5 = yes. erkr_kardiovask and erkr_apoplex are
# REDCap checkbox lists exported as ___n columns.
# =============================================================================
yes1 <- function(v) {
  if (!v %in% names(d)) { message("not in data: ", v); return(rep(FALSE, nrow(d))) }
  x <- num(d[[v]]); !is.na(x) & x == 1
}

kk <- num(d$khk_status_akt)

d <- d %>% mutate(
  # classical risk factors
  dm        = yes1("diabtyp2"),
  htn       = yes1("hypertonie"),
  smoke     = yes1("rauchen_akt"),
  ex_smoke  = yes1("rauchen_frueher"),

  # established disease.  herzinfarkt: 1 = nein, 2-5 = yes
  mi        = if ("herzinfarkt" %in% names(d)) num(herzinfarkt) %in% 2:5 else NA,
  known_cad = yes1("vorbekannte_khk"),
  bypass    = yes1("bypass_op"),
  n_prior_angio = if ("anzahl_koros" %in% names(d))
                    ifelse(num(anzahl_koros) == 9, NA, num(anzahl_koros)) else NA,

  # arterial territories
  pavk       = yes1("erkr_kardiovask___7"),
  carotid    = yes1("erkr_kardiovask___10"),
  stroke_any = yes1("erkr_apoplex___1") | yes1("erkr_apoplex___2") |
               yes1("erkr_apoplex___3"),
  tia        = yes1("erkr_apoplex___4"),

  # coronary anatomy at the index angiogram
  n_vessel = case_when(kk %in% 0:3 ~ kk, kk %in% c(4, 7) ~ 0, TRUE ~ NA_real_),
  obstr    = n_vessel >= 1,
  mvd      = n_vessel >= 2,


  # risk-factor burden; SMuRF-less uses the three non-lipid factors, because
  # hypercholesterolaemia cannot be a covariate in a study about lipids
  rf_count = dm + htn + smoke,
  smurfless = rf_count == 0)

# eGFR, CKD-EPI 2021 (race-free). Serum creatinine is assumed mg/dL; if the
# values look like umol/L (median > 20) they are converted.
if ("kreatinin" %in% names(d) && "age" %in% names(d)) {
  scr <- num(d$kreatinin)
  if (median(scr, na.rm = TRUE) > 20) {
    scr <- scr / 88.4; message("creatinine looks like umol/L - converted to mg/dL")
  }
  k <- ifelse(d$female, 0.7, 0.9); a <- ifelse(d$female, -0.241, -0.302)
  d$egfr <- 142 * pmin(scr/k, 1)^a * pmax(scr/k, 1)^(-1.200) *
            0.9938^num(d$age) * ifelse(d$female, 1.012, 1)
  d$ckd  <- d$egfr < 60
  message(sprintf("eGFR: median %.0f mL/min/1.73m2; eGFR < 60 in %d patients",
                  median(d$egfr, na.rm = TRUE), sum(d$ckd, na.rm = TRUE)))
} else message("eGFR not computed (needs kreatinin and age)")

message("\n--- cardiovascular risk profile ---")
print(colSums(d[c("dm","htn","smoke","mi","known_cad","bypass",
                  "pavk","carotid","stroke_any","tia","smurfless")], na.rm = TRUE))
print(table(`risk factors` = d$rf_count, useNA = "ifany"))

# =============================================================================
# 2  Analysis sets
# =============================================================================
print(colSums(!is.na(d[c("apob","ldl","cholesterin","hdl","triglyceride","lp_a")])))

an <- d %>%
  filter(!is.na(apob), !is.na(ldl)) %>%
  mutate(ldl_stratum = cut(ldl, LDL_BREAKS, LDL_LABELS, right = FALSE),
         cpp = ldl / apob_mgdl,
         log_tg = log(triglyceride), log_lpa = log1p(lp_a),
         sexf = factor(ifelse(female, "female", "male")))

message("Set A n = ", nrow(an))
print(table(an$regimen, an$ldl_stratum, useNA = "ifany"))
print(table(an$regimen, an$eze_add, useNA = "ifany"))

# =============================================================================
# 3  Discordance
# =============================================================================
f_lin <- lm(apob_mgdl ~ ldl, an, na.action = na.exclude)
f_sp  <- lm(apob_mgdl ~ splines::ns(ldl, 4), an, na.action = na.exclude)
print(anova(f_lin, f_sp))
print(round(c(intercept = coef(f_lin)[1], confint(f_lin)[1, ]), 1))

ct <- cor.test(an$ldl, an$apob_mgdl)                      # for Figure 1
message(sprintf("Pearson r = %.3f (95%% CI %.3f-%.3f), p = %.3g",
                ct$estimate, ct$conf.int[1], ct$conf.int[2], ct$p.value))

an <- an %>%
  mutate(resid = as.numeric(residuals(f_sp)),
         z = resid / sd(resid, na.rm = TRUE),
         disc = factor(case_when(z >  DISC_Z ~ "apoB high",
                                 z < -DISC_Z ~ "apoB low",
                                 TRUE        ~ "Concordant"),
                       levels = c("Concordant","apoB high","apoB low")),
         res_high = disc == "apoB high", res_low = disc == "apoB low")
print(table(an$disc))

# =============================================================================
# PRIMARY discordance definition: percentile gap (Du et al.). Everything below
# (prevalence, figures, determinants) uses du / du_high / du_low. The residual
# (disc / res_high / res_low above) is kept only as the sensitivity analysis.
# Also defined here:
# and a treatment variable with no missing level, so that no patient is lost
# from an adjusted model because of an unusual regimen.
# =============================================================================
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
an <- an %>% mutate(
  gap   = pctile(apob_mgdl) - pctile(ldl),
  gap_z = gap / sd(gap, na.rm = TRUE),
  du    = factor(case_when(gap >  10 ~ "Discordantly high apoB",
                           gap < -10 ~ "Discordantly low apoB",
                           TRUE      ~ "Concordant"),
                 levels = c("Concordant", "Discordantly high apoB",
                            "Discordantly low apoB")),
  llt   = factor(case_when(
            on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
            on_statin & high                 ~ "High-intensity statin",
            on_statin                        ~ "Moderate-intensity statin",
            TRUE                             ~ "No lipid-lowering therapy"),
          levels = c("No lipid-lowering therapy", "Moderate-intensity statin",
                     "High-intensity statin", "Other lipid-lowering therapy")))
an <- an %>% mutate(du_high = du == "Discordantly high apoB",
                    du_low  = du == "Discordantly low apoB")
print(table(an$du)); print(table(an$llt, useNA = "ifany"))
print(table(residual = an$disc, percentile_gap = an$du))   # sensitivity cross-tab


# Set B: particle budget. With remnant cholesterol as TG/5 this needs only
# triglycerides and Lp(a) on top of apoB and LDL-C - total cholesterol and
# HDL-C are no longer required, which keeps ~60 more patients than the
# TC - LDL-C - HDL-C version did.
bud <- an %>%
  filter(!is.na(triglyceride), !is.na(lp_a), triglyceride <= TG_MAX)
message("Set B n = ", nrow(bud))

# ---- stratifier helper: Overall always first --------------------------------
STRAT <- c("Overall", "By LDL-C (mg/dL)", "By regimen", "Statin vs no statin")

split3 <- function(data) {
  k <- list("Overall"             = factor(rep("Overall", nrow(data))),
            "By LDL-C (mg/dL)"    = data$ldl_stratum,
            "By regimen"          = data$regimen,
            "Statin vs no statin" = data$statin_use)
  out <- list()
  for (p in STRAT) {
    g <- k[[p]]; ok <- !is.na(g)
    for (nm in levels(droplevels(g[ok])))
      out[[length(out)+1]] <- list(panel = p, group = nm, df = data[ok & g == nm, ])
  }
  out
}
over3 <- function(data, f)
  bind_rows(lapply(split3(data), function(s)
    cbind(panel = s$panel, group = s$group, f(s$df)))) %>%
  mutate(panel = factor(panel, STRAT), group = factor(group, unique(group)))

# keep Overall + one stratifier, Overall first
pick <- function(tab, which)
  tab %>% filter(panel %in% c("Overall", which)) %>%
  mutate(group = factor(as.character(group),
                        c("Overall", setdiff(as.character(unique(group)), "Overall"))))

# =============================================================================
# TABLE 1  LDL-C strata and the corresponding apoB values
# =============================================================================
tab_ldl_apob <- over3(an, function(x) data.frame(
  n           = nrow(x),
  `LDL-C`     = mq(x$ldl),
  `apoB`      = mq(x$apob_mgdl),
  `LDL-C/apoB`= sprintf("%.2f (%.2f-%.2f)", median(x$cpp, na.rm = TRUE),
                        quantile(x$cpp, .25, na.rm = TRUE),
                        quantile(x$cpp, .75, na.rm = TRUE)),
  check.names = FALSE))
print(tab_ldl_apob)
write.csv(tab_ldl_apob, out("tab1_ldl_apob.csv"), row.names = FALSE)

# =============================================================================
# FIGURE 1A  apoB against LDL-C, coloured by discordance
# =============================================================================
lab <- sprintf("r = %.2f (95%% CI %.2f-%.2f), p %s\nn = %d",
               ct$estimate, ct$conf.int[1], ct$conf.int[2],
               ifelse(ct$p.value < 2.2e-16, "< 2.2e-16",
                      sprintf("= %.3g", ct$p.value)), nrow(an))

fig1a <- ggplot(an, aes(ldl, apob_mgdl)) +
  geom_point(aes(colour = du), size = 1.9, alpha = .6) +
  geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
              colour = "grey20", fill = "grey60", alpha = .25, linewidth = 1) +
  annotate("text", x = -Inf, y = Inf, hjust = -0.08, vjust = 1.3,
           label = lab, size = 4.4, colour = "grey15", lineheight = 1.1) +
  scale_colour_manual(values = PALD) +
  labs(x = "LDL-C (mg/dL)", y = "apoB (mg/dL)") +
  guides(colour = guide_legend(override.aes = list(size = 3.4, alpha = 1))) + th
ggsave(out("fig1a_apob_ldl.png"), fig1a, width = 7.5, height = 5.5, dpi = 300)

# =============================================================================
# FIGURE 1B  spline by regimen (three groups; ezetimibe handled separately)
# =============================================================================
ar <- an %>% filter(!is.na(regimen)) %>% droplevels()
dd <- datadist(ar[c("ldl","apob_mgdl","regimen")]); options(datadist = "dd")
f1 <- ols(apob_mgdl ~ rcs(ldl, 4) * regimen, ar)
print(anova(f1))
grid <- seq(quantile(ar$ldl, .01), quantile(ar$ldl, .99), length = 200)
p1 <- as.data.frame(Predict(f1, ldl = grid, regimen = levels(ar$regimen)))

fig1b <- ggplot(p1, aes(ldl, yhat, colour = regimen, fill = regimen)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = .15, colour = NA) +
  geom_line(linewidth = 1.1) +
  scale_colour_manual(values = PAL4) + scale_fill_manual(values = PAL4) +
  labs(x = "LDL-C (mg/dL)", y = "apoB (mg/dL)") + th
ggsave(out("fig1b_spline_by_regimen.png"), fig1b, width = 7.5, height = 5.5, dpi = 300)

# supplementary: ezetimibe add-on within statin users
sup <- an %>% filter(!is.na(eze_add)) %>% droplevels()
print(sup %>% group_by(eze_add) %>%
        summarise(n = n(), apoB = mq(apob_mgdl), `LDL-C` = mq(ldl),
                  `apoB high %` = round(100*mean(du_high), 1), .groups = "drop"))

# =============================================================================
# FIGURE 2  Particle budget   (A = by LDL-C, B = by regimen)
# =============================================================================
bud <- bud %>% mutate(apob_p = apob_mgdl * 1e7 / MW,
                      lpa_p  = lp_a,
                      rc     = triglyceride / 5)      # never negative
C_LDL <- median(bud$ldl / bud$apob_p, na.rm = TRUE)
bud <- bud %>%
  mutate(rem_p = rc / (RHO * C_LDL),
         ldl_p = pmax(apob_p - lpa_p - rem_p, 0),
         tot   = lpa_p + rem_p + ldl_p,
         s_lpa = 100*lpa_p/tot, s_rem = 100*rem_p/tot, s_ldl = 100*ldl_p/tot,
         s_nonldl = s_lpa + s_rem)
message(sprintf("C_LDL %.4f mg/dL per nmol/L; derived LDL-P floored in %d of %d",
                C_LDL, sum(bud$apob_p - bud$lpa_p - bud$rem_p < 0, na.rm = TRUE),
                nrow(bud)))

comp <- over3(bud, function(x) data.frame(
  n = nrow(x),
  `Non-LDL`       = mean(x$s_nonldl, na.rm = TRUE),
  `Lp(a)`         = mean(x$s_lpa, na.rm = TRUE),
  Remnant         = mean(x$s_rem, na.rm = TRUE),
  `Derived LDL-P` = mean(x$s_ldl, na.rm = TRUE),
  check.names = FALSE))
print(comp); write.csv(comp, out("tab_particle_budget.csv"), row.names = FALSE)

for (v in c("s_nonldl","s_lpa","s_rem"))
  message(sprintf("%-9s by LDL-C p = %.3g | by regimen p = %.3g", v,
    kruskal.test(bud[[v]] ~ bud$ldl_stratum)$p.value,
    kruskal.test(bud[[v]][!is.na(bud$regimen)] ~
                   droplevels(bud$regimen[!is.na(bud$regimen)]))$p.value))

# sensitivity: the other remnant definition, on those who have TC and HDL-C
alt <- bud %>%
  mutate(rc_alt = cholesterin - ldl - hdl) %>%
  filter(!is.na(rc_alt), rc_alt >= 0) %>%
  mutate(rp = rc_alt/(RHO*C_LDL), lp = pmax(apob_p - lpa_p - rp, 0),
         s_nonldl2 = 100*(lpa_p + rp)/(lpa_p + rp + lp))
message(sprintf("\nSensitivity TC-LDL-C-HDL-C (n = %d of %d):", nrow(alt), nrow(bud)))
print(bind_rows(
  bud %>% filter(!is.na(regimen)) %>% group_by(regimen) %>%
    summarise(`TG/5 (primary)` = mean(s_nonldl), .groups = "drop"),
  alt %>% filter(!is.na(regimen)) %>% group_by(regimen) %>%
    summarise(`TC-LDL-HDL` = mean(s_nonldl2), .groups = "drop")) %>%
  group_by(regimen) %>% summarise(across(everything(), ~ mean(.x, na.rm = TRUE))),
  digits = 3)

budget_fig <- function(which, file, w = 7.5) {
  p <- pick(comp, which) %>%
    select(-`Non-LDL`, -n) %>%
    pivot_longer(c("Derived LDL-P","Remnant","Lp(a)"),
                 names_to = "compartment", values_to = "pct") %>%
    mutate(compartment = factor(compartment, names(PAL3))) %>%
    ggplot(aes(group, pct, fill = compartment)) +
    geom_col(width = .68, colour = "white", linewidth = .7) +
    geom_text(aes(label = ifelse(pct >= 4, sprintf("%.0f%%", pct), "")),
              position = position_stack(vjust = .5), size = 4, colour = "grey15") +
    scale_fill_manual(values = PAL3) +
    scale_y_continuous(expand = expansion(mult = c(0, .02))) +
    labs(x = NULL, y = "Share of the apoB pool (%)") + th +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))
  ggsave(out(file), p, width = w, height = 5.5, dpi = 300); p
}
fig2a <- budget_fig("By LDL-C (mg/dL)", "fig2a_budget_by_ldl.png")
fig2b <- budget_fig("By regimen",       "fig2b_budget_by_regimen.png")

# =============================================================================
# FIGURE 3  Discordance prevalence   (A = by LDL-C, B = by regimen)
# =============================================================================
wil <- function(k, n) {
  p <- k/n; z <- 1.96; dn <- 1 + z^2/n
  h <- z*sqrt(p*(1-p)/n + z^2/(4*n^2))/dn; m <- (p + z^2/(2*n))/dn
  c(100*max(0, m-h), 100*min(1, m+h))
}

prev <- over3(an, function(x) data.frame(
  n = nrow(x), high = sum(x$du_high), low = sum(x$du_low))) %>%
  pivot_longer(c(high, low), names_to = "direction", values_to = "k") %>%
  rowwise() %>%
  mutate(pct = 100*k/n, lo = wil(k, n)[1], hi = wil(k, n)[2],
         direction = recode(direction, high = "Discordantly high apoB",
                            low = "Discordantly low apoB")) %>%
  ungroup() %>%
  mutate(txt = sprintf("%d/%d, %.1f%% (%.1f-%.1f)", k, n, pct, lo, hi))

print(prev %>% select(panel, group, direction, txt), n = 60)
write.csv(prev, out("tab_prevalence.csv"), row.names = FALSE)

# p-values per stratifier and direction
pv <- function(by, flag) chisq.test(table(an[[by]], an[[flag]]))$p.value
ptab <- expand.grid(by = c("ldl_stratum","regimen","statin_use"),
                    flag = c("du_high","du_low"), stringsAsFactors = FALSE) %>%
  rowwise() %>% mutate(p = pv(by, flag)) %>% ungroup()
print(ptab)

message(sprintf("\nStatin vs no statin, apoB-high: p = %.4g | apoB-low: p = %.4g",
                pv("statin_use","du_high"), pv("statin_use","du_low")))

prev_fig <- function(which, file, pby, w = 7.5) {
  ann <- data.frame(
    direction = c("Discordantly high apoB","Discordantly low apoB"),
    lab = sprintf("p = %.3g", c(pv(pby,"du_high"), pv(pby,"du_low"))))
  p <- pick(prev, which) %>%
    ggplot(aes(group, pct, fill = direction)) +
    geom_col(position = position_dodge(.8), width = .72) +
    geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(.8),
                  width = .18, colour = "grey30", linewidth = .5) +
    geom_text(aes(y = hi + 1.2, label = sprintf("%.1f", pct)),
              position = position_dodge(.8), size = 3.8, colour = "grey20") +
    annotate("text", x = Inf, y = Inf, hjust = 1.05, vjust = 1.4, size = 4.2,
             colour = "grey15",
             label = paste(ann$direction, ann$lab, sep = ": ", collapse = "\n")) +
    scale_fill_manual(values = PAL2) +
    scale_y_continuous(expand = expansion(mult = c(0, .18))) +
    labs(x = NULL, y = "Discordance prevalence (%)") + th +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))
  ggsave(out(file), p, width = w, height = 5.5, dpi = 300); p
}
fig3a <- prev_fig("By LDL-C (mg/dL)", "fig3a_prevalence_by_ldl.png", "ldl_stratum")
fig3b <- prev_fig("By regimen",       "fig3b_prevalence_by_regimen.png", "regimen")

# -----------------------------------------------------------------------------
# 3b  Statin vs no statin, crude and adjusted
#
# The crude prevalence comparison is confounded: statins are prescribed to
# older patients, to diabetics and to those with more comorbidity, and all of
# those independently affect the chance of carrying excess apoB. Adjusted for
# age, sex, diabetes, hypertension, smoking and BMI.
#
# Lipids are NOT adjusted for. Triglycerides, HDL-C and Lp(a) lie between
# statin use and discordance, so conditioning on them would remove the very
# effect being estimated.
# -----------------------------------------------------------------------------
y1 <- function(x) !is.na(x) & suppressWarnings(as.numeric(as.character(x))) == 1
zz <- function(x) as.numeric(scale(x))

# dm, htn, smoke are already defined in section 1b

adj_or <- function(exposure, outcome, label) {
  dd <- an %>%
    transmute(y = .data[[outcome]], x = .data[[exposure]],
              age = zz(age), sexf, dm, htn, smoke, bmi = zz(bmi),
              log_tg = zz(log_tg), hdl = zz(hdl), log_lpa = zz(log_lpa),
              hba1c = zz(hba1c), ldl_s = ldl_stratum) %>%
    filter(!is.na(x), !is.na(y))
  dd$x <- droplevels(as.factor(dd$x))
  crude <- glm(y ~ x, binomial, dd)
  adj   <- glm(y ~ x + age + sexf + dm + htn + smoke + bmi, binomial, dd)
  # + achieved LDL-C. Untreated patients sit overwhelmingly in the highest
  # LDL-C stratum, where apoB-high discordance is most common (13.5% vs 7.8%),
  # so part of any statin association may simply be where the groups sit on the
  # LDL-C range. This is the model that tests that.
  adjL  <- glm(y ~ x + age + sexf + dm + htn + smoke + bmi + ldl_s,
               binomial, dd)
  # + the lipid profile: whether anything remains once the lipids statins act
  # on are held constant
  adj2  <- glm(y ~ x + age + sexf + dm + htn + smoke + bmi +
                 log_tg + hdl + log_lpa + hba1c, binomial, dd)
  grab <- function(m, what) {
    s <- summary(m)$coefficients
    j <- grep("^x", rownames(s))
    data.frame(model = what, term = sub("^x", "", rownames(s)[j]),
               or = exp(s[j,1]), lo = exp(s[j,1]-1.96*s[j,2]),
               hi = exp(s[j,1]+1.96*s[j,2]), p = s[j,4], n = nobs(m),
               row.names = NULL)
  }
  bind_rows(grab(crude, "1 Crude"),
            grab(adj,   "2 Adjusted for confounders"),
            grab(adjL,  "3 + achieved LDL-C stratum"),
            grab(adj2,  "4 + lipid profile")) %>%
    mutate(comparison = label, outcome = outcome, .before = 1)
}

stat_adj <- bind_rows(
  adj_or("statin_use", "du_high", "Statin vs no statin"),
  adj_or("statin_use", "du_low",  "Statin vs no statin"),
  adj_or("regimen",    "du_high", "By statin intensity"),
  adj_or("regimen",    "du_low",  "By statin intensity"),
  adj_or("eze_add",    "du_high", "Ezetimibe add-on (statin users)"),
  adj_or("eze_add",    "du_low",  "Ezetimibe add-on (statin users)"))

print(stat_adj, digits = 3)
write.csv(stat_adj, out("tab_statin_vs_nostatin.csv"), row.names = FALSE)

# =============================================================================
# FIGURE 4  Determinants of apoB-high discordance
#
#   Overall  -> multivariable, adjusted for regimen. This is Figure 4.
#   Strata   -> univariable only. With 7 covariates a stratum would need ~70
#               apoB-high events for a multivariable model; the largest stratum
#               has far fewer, so a stratified multivariable model would be
#               fitted on 10-30 events and is not interpretable.
#
# BMI is deliberately NOT in the same model as waist circumference: the two
# correlate at about r = 0.85, and together they split the estimate and inflate
# both standard errors. Swap ADIPO below to check the other one.
# =============================================================================
ADIPO <- "taillenumfang"          # or "bmi"

FACT <- c(age = "Age", female = "Female sex", taillenumfang = "WC",
          log_tg = "Triglycerides (log)", hdl = "HDL-C",
          log_lpa = "Lp(a) (log)", hba1c = "HbA1c")
if (ADIPO == "bmi") { names(FACT)[3] <- "bmi"; FACT[3] <- "BMI" }

CONT <- setdiff(names(FACT), "female")

# Standardise ONCE on the whole cohort, before splitting, so that a "per SD"
# estimate means the same thing in every stratum.
anz <- an
anz[CONT] <- lapply(anz[CONT], function(x) as.numeric(scale(x)))

tidy_or <- function(m, keep) {
  s <- summary(m)$coefficients
  rn <- rownames(s)
  idx <- vapply(keep, function(v) {
    j <- which(rn == v); if (!length(j)) j <- grep(paste0("^", v), rn)[1]
    if (length(j)) j[1] else NA_integer_ }, integer(1))
  ok <- !is.na(idx)
  data.frame(factor = unname(FACT[keep[ok]]),
             or = exp(s[idx[ok], 1]),
             lo = exp(s[idx[ok], 1] - 1.96*s[idx[ok], 2]),
             hi = exp(s[idx[ok], 1] + 1.96*s[idx[ok], 2]),
             p  = s[idx[ok], 4], n = nobs(m), row.names = NULL)
}

or_multi <- function(df, adjust = TRUE) {
  vars <- names(FACT); if (adjust) vars <- c(vars, "regimen")
  dd <- df[, c("du_high", vars)]
  dd <- dd[complete.cases(dd), , drop = FALSE]
  if (!nrow(dd)) return(NULL)
  dd$regimen <- droplevels(dd$regimen)
  k  <- length(vars) + if (adjust) nlevels(dd$regimen) - 2 else 0
  ev <- sum(dd$du_high)
  m  <- try(glm(reformulate(vars, "du_high"), binomial, dd), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  # Events per variable is reported, not enforced, so you can see what the
  # model rests on: >=10 comfortable, 5-10 acceptable, <5 exploratory.
  message(sprintf("Multivariable: n = %d, %d apoB-high events, %d df, %.1f events/variable",
                  nrow(dd), ev, k, ev/k))
  if (ev/k < 5) message("  WARNING: <5 events per variable - treat as exploratory.")
  list(fit = m, tab = tidy_or(m, names(FACT)))
}

or_uni <- function(x, df) {
  v <- df[[x]]
  if (sum(!is.na(v)) < 20 || sum(df$du_high, na.rm = TRUE) < 5) return(NULL)
  m <- try(glm(reformulate(x, "du_high"), binomial, df), silent = TRUE)
  if (inherits(m, "try-error")) return(NULL)
  tidy_or(m, x)
}

# --- multivariable, overall ---------------------------------------------------
mv <- or_multi(anz, adjust = TRUE)
if (is.null(mv)) stop("Multivariable model could not be fitted.")
print(summary(mv$fit))
f_ov <- mv$tab
print(f_ov, digits = 3)
write.csv(f_ov, out("tab4_multivariable_overall.csv"), row.names = FALSE)

# --- univariable, every stratum ----------------------------------------------
fact_uni <- bind_rows(lapply(split3(anz), function(s) {
  r <- bind_rows(lapply(names(FACT), or_uni, df = s$df))
  if (is.null(r) || !nrow(r)) return(NULL)
  cbind(panel = s$panel, group = s$group, r)
}))
print(tibble::as_tibble(fact_uni), n = 100)
write.csv(fact_uni, out("tab_factors_univariable_all_strata.csv"), row.names = FALSE)

# --- Figure 4 -----------------------------------------------------------------
f_ov <- f_ov %>%
  mutate(lab = sprintf("%.2f (%.2f-%.2f)  p %s", or, lo, hi,
                       ifelse(p < 0.001, "< 0.001", sprintf("= %.3f", p))),
         factor = factor(factor, rev(unname(FACT))))

fig4 <- ggplot(f_ov, aes(or, factor)) +
  geom_vline(xintercept = 1, colour = "grey60", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .18,
                colour = "grey35", linewidth = .6) +
  geom_point(size = 3.2, colour = "#0072B2") +
  geom_text(aes(x = max(hi) * 1.15, label = lab), hjust = 0, size = 5,
            colour = "grey15") +
  scale_x_log10(expand = expansion(mult = c(.05, .8))) +
  labs(x = paste0("Adjusted odds ratio for apoB-high discordance\n",
                  "(continuous variables per SD; sex: women vs men; n = ",
                  unique(f_ov$n), ")"), y = NULL) +
  theme_bw(16) +
  theme(panel.grid.minor = element_blank(),
        axis.title.x = element_text(size = 15),
        axis.text = element_text(size = 15, colour = "grey15"))
ggsave(out("fig4_determinants.png"), fig4, width = 10, height = 5.5, dpi = 300)

message(sprintf("\nMultivariable model fitted on %d of %d (%d events).",
                unique(f_ov$n), nrow(an), sum(anz$du_high[complete.cases(
                  anz[, c("du_high", names(FACT), "regimen")])])))
print(colSums(!is.na(an[c(names(FACT), "regimen")])))

message("\nDone. Figures and tables in ", OUT)

# =============================================================================
# 6  Does the driver of excess apoB shift with treatment?
#
# Prediction: statins lower triglyceride-rich lipoproteins but not Lp(a), so
# among untreated patients excess apoB should track triglycerides, and among
# intensively treated patients it should track Lp(a). Nobody has tested this:
# the three published discordance analyses all excluded treated patients.
# =============================================================================
shift <- bind_rows(lapply(levels(an$regimen), function(g) {
  d0 <- anz[!is.na(anz$regimen) & anz$regimen == g, ]
  if (sum(d0$du_high, na.rm = TRUE) < 10) return(NULL)
  m <- glm(du_high ~ age + female + taillenumfang + log_tg + hdl + log_lpa +
             hba1c, binomial, d0)
  s <- summary(m)$coefficients
  j <- c("log_tg", "log_lpa")
  data.frame(regimen = g, term = c("Triglycerides (log)", "Lp(a) (log)"),
             or = exp(s[j,1]), lo = exp(s[j,1]-1.96*s[j,2]),
             hi = exp(s[j,1]+1.96*s[j,2]), p = s[j,4],
             n = nobs(m), events = sum(m$y), row.names = NULL)
}))
print(shift, digits = 3)
write.csv(shift, out("tab_driver_shift.csv"), row.names = FALSE)

# ratio of the two coefficients per regimen: >1 means Lp(a) dominates
shift %>% group_by(regimen) %>%
  summarise(lpa_vs_tg = log(or[term == "Lp(a) (log)"]) /
                        log(or[term == "Triglycerides (log)"])) %>% print()

# formal interaction test (expect this to be underpowered - report the
# stratified estimates and the test together, not one without the other)
m0 <- glm(du_high ~ log_tg + log_lpa + regimen + age + female +
            taillenumfang + hdl + hba1c, binomial, anz)
m1 <- update(m0, . ~ . + log_tg:regimen + log_lpa:regimen)
print(anova(m0, m1, test = "LRT"))

fig6 <- shift %>%
  mutate(lab = sprintf("%.2f (%.2f-%.2f)", or, lo, hi)) %>%
  ggplot(aes(or, regimen, colour = term)) +
  geom_vline(xintercept = 1, colour = "grey55", linetype = "22") +
  geom_errorbar(aes(xmin = lo, xmax = hi), orientation = "y", width = .18,
                position = position_dodge(.5), linewidth = .7) +
  geom_point(size = 3.2, position = position_dodge(.5)) +
  scale_colour_manual(values = c("Triglycerides (log)" = "#E69F00",
                                 "Lp(a) (log)" = "#009E73")) +
  scale_x_log10() +
  labs(x = "Odds ratio per SD for apoB-high discordance", y = NULL) + th
ggsave(out("fig6_driver_shift.png"), fig6, width = 9, height = 4.5, dpi = 300)


# cache the cohort so the downstream scripts can run in a fresh session
saveRDS(an, out("an.rds"))
message("cached: ", out("an.rds"))
