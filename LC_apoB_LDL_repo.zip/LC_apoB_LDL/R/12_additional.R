# =============================================================================
# Three additions that support the main message. Run after analysis.R.
#   1 robustness: MACE with the residual definition (sensitivity)
#   2 clinical core: MACE in patients AT LDL-C target (< 70) and on statins
#   3 would non-HDL-C have found them? apoB vs non-HDL-C
# =============================================================================
library(dplyr); library(survival)
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("an"))  an  <- readRDS(file.path(OUT, "an.rds"))
num <- function(x) suppressWarnings(as.numeric(as.character(x)))
fp  <- function(p) ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))
pct <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
H   <- "Discordantly high apoB"
COV <- "+ I(age/10) + female + dm + htn + smoke + llt"
hr  <- function(f, data, term) { m <- coxph(as.formula(f), data)
  s <- summary(m); j <- grep(term, rownames(s$coefficients))
  sprintf("%-26s HR %.2f (%.2f-%.2f), p %s  [n = %d, events = %d]",
          rownames(s$coefficients)[j], s$conf.int[j, 1], s$conf.int[j, 3], s$conf.int[j, 4],
          fp(s$coefficients[j, 5]), m$n, m$nevent) }

cc <- an %>% mutate(time = num(mace_yrs), event = num(mace), high = as.numeric(du == H)) %>%
  filter(!is.na(time), !is.na(event), time > 0) %>%
  filter(complete.cases(across(c(age, female, dm, htn, smoke, llt))))

# --- 1  residual definition ------------------------------------------------------
cat("=== 1. MACE, residual definition (adjusted) ===\n")
cat(hr(paste("Surv(time, event) ~ disc", COV), cc, "^disc"), sep = "\n")

# --- 2  at LDL-C target and on statins -------------------------------------------
# few events per subgroup -> adjusted for age, sex and diabetes only
cat("\n=== 2. Discordantly high vs all others, within subgroups ===\n")
C3 <- "+ I(age/10) + female + dm"
for (s in list(list("LDL-C < 70 mg/dL", cc$ldl < 70),
               list("LDL-C < 55 mg/dL", cc$ldl < 55),
               list("On a statin",      cc$on_statin %in% TRUE))) {
  x <- cc[s[[2]], ]
  cat(sprintf("%-17s events: high %d/%d, others %d/%d\n", s[[1]],
              sum(x$event[x$high == 1]), sum(x$high), sum(x$event[x$high == 0]), sum(x$high == 0)))
  cat("  ", hr(paste("Surv(time, event) ~ high", C3), x, "^high"), "\n")
}

# --- 3  apoB vs non-HDL-C ----------------------------------------------------------
cat("\n=== 3. Non-HDL-C ===\n")
d <- an %>% mutate(nonhdl = num(cholesterin) - num(hdl)) %>% filter(!is.na(nonhdl))
d <- d %>% mutate(gap_nh = pct(apob_mgdl) - pct(nonhdl),
                  high_nh = gap_nh > 10,                     # apoB discordantly high vs non-HDL-C
                  nh_high_ldl = pct(nonhdl) - pct(ldl) > 10) # non-HDL-C itself above LDL-C
h <- d %>% filter(du == H)
cat(sprintf("Patients with non-HDL-C: %d; of them discordantly high apoB (vs LDL-C): %d\n",
            nrow(d), nrow(h)))
cat(sprintf("Of these, non-HDL-C was also discordantly high vs LDL-C in %.0f%% (i.e. non-HDL-C would have flagged them)\n",
            100*mean(h$nh_high_ldl)))
cat(sprintf("ApoB discordantly high vs non-HDL-C in the whole sample: %d/%d (%.1f%%)\n",
            sum(d$high_nh), nrow(d), 100*mean(d$high_nh)))
cat(sprintf("Correlation apoB with LDL-C r = %.2f, with non-HDL-C r = %.2f\n",
            cor(d$apob_mgdl, d$ldl), cor(d$apob_mgdl, d$nonhdl)))
