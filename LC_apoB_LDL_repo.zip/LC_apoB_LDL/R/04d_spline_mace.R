# =============================================================================
# MACE: spline of the percentile gap (Cox, rcs 4 knots), whole cohort,
# complete case. Adjusted for age, sex, diabetes, hypertension, smoking, LLT.
# Reference gap = 0 (apoB and LDL-C at the same percentile). Dashed: +/-10.
# Uses the existing mace / mace_yrs. Run after analysis.R.
# =============================================================================

library(dplyr); library(ggplot2); library(rms)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num    <- function(x) suppressWarnings(as.numeric(as.character(x)))
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
if (!"gap" %in% names(an)) an$gap <- pctile(an$apob_mgdl) - pctile(an$ldl)
if (!"llt" %in% names(an))
  an <- an %>% mutate(llt = factor(case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
      on_statin & high ~ "High-intensity statin",
      on_statin        ~ "Moderate-intensity statin",
      TRUE             ~ "No lipid-lowering therapy")))

dx <- an %>%
  transmute(gap, age, female = as.integer(female), dm = as.integer(dm),
            htn = as.integer(htn), smoke = as.integer(smoke), llt = droplevels(llt),
            time = num(mace_yrs), event = num(mace)) %>%
  filter(!is.na(time), !is.na(event), time > 0) %>%
  na.omit()

dd <- datadist(dx); dd$limits["Adjust to", "gap"] <- 0; options(datadist = "dd")
rng  <- quantile(dx$gap, c(.01, .99))
grid <- seq(rng[1], rng[2], length.out = 200)

fit <- cph(Surv(time, event) ~ rcs(gap, 4) + age + female + dm + htn + smoke + llt,
           data = dx)
a   <- anova(fit)
p_all <- a["gap", "P"]; p_nl <- a[grep("Nonlinear", rownames(a))[1], "P"]
pr  <- as.data.frame(Predict(fit, gap = grid, ref.zero = TRUE, fun = exp))

fp <- function(p) ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))
cat(sprintf("n = %d, events = %d, p overall %s, p non-linear %s\n",
            nrow(dx), sum(dx$event), fp(p_all), fp(p_nl)))
write.csv(data.frame(n = nrow(dx), events = sum(dx$event), p_all, p_nl),
          out("TABLE_spline_mace.csv"), row.names = FALSE)

FIG <- ggplot(pr, aes(gap, yhat)) +
  geom_hline(yintercept = 1, colour = "grey55") +
  geom_vline(xintercept = c(-10, 10), linetype = "22", colour = "grey55") +
  geom_ribbon(aes(ymin = lower, ymax = upper), fill = "#0072B2", alpha = .15) +
  geom_line(colour = "#0072B2", linewidth = .9) +
  geom_rug(data = filter(dx, between(gap, rng[1], rng[2])), aes(x = gap),
           inherit.aes = FALSE, alpha = .15, length = unit(.02, "npc")) +
  annotate("text", x = -Inf, y = Inf, hjust = -.05, vjust = 1.3, size = 3.5,
           colour = "grey25",
           label = sprintf("n = %d, events = %d\np overall %s\np non-linear %s",
                           nrow(dx), sum(dx$event), fp(p_all), fp(p_nl))) +
  scale_y_log10() +
  labs(x = "Percentile gap (apoB percentile minus LDL-C percentile)",
       y = "Adjusted hazard ratio for MACE (ref. gap = 0)") +
  theme_bw(12) + theme(panel.grid.minor = element_blank())
ggsave(out("FIGURE_spline_mace.png"), FIG, width = 6.5, height = 4.5, dpi = 300)
