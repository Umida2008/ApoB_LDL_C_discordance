# =============================================================================
# p-values for the Results text. Run right after 10_text_numbers.R (same
# session: uses d, dz, m2, m2u, m3, MV, h, nei, con).
#   continuous: Wilcoxon (2 groups) / Kruskal-Wallis (4 groups)
#   binary:     chi-square (Fisher if any expected count < 5)
#   models:     Wald p from the fitted models
# =============================================================================
stopifnot(exists("d"), exists("m3"))
fp <- function(p) ifelse(p < .001, "< 0.001", sprintf("= %.3f", p))
pbin <- function(x, g) { t <- table(g, x)
  if (any(suppressWarnings(chisq.test(t))$expected < 5)) fisher.test(t)$p.value
  else chisq.test(t)$p.value }
pmod <- function(m, j) summary(m)$coefficients[j, 4]

CONT <- c(age = "age", TG = "tg", HDL = "hdl", HbA1c = "hba1c", `Lp(a)` = "lpa",
          `LDL-C/apoB` = "ratio", BMI = "bmi")
BIN  <- c(women = "female", statin = "on_statin")

cat("\n=== Profile: p across all 3 groups, and each discordant group vs concordant ===\n")
for (k in names(CONT)) { v <- CONT[[k]]
  row <- sprintf("%-11s all 3 groups p %s", k, fp(kruskal.test(d[[v]] ~ d$grp3)$p.value))
  for (g in G3[-1]) { s <- d$grp3 %in% c(G3[1], g)
    row <- paste0(row, sprintf(" | %s p %s", g,
                  fp(wilcox.test(d[[v]][s] ~ droplevels(d$grp3[s]))$p.value))) }
  cat(row, "\n") }
for (k in names(BIN)) { v <- BIN[[k]]
  row <- sprintf("%-11s all 3 groups p %s", k, fp(pbin(d[[v]], d$grp3)))
  for (g in G3[-1]) { s <- d$grp3 %in% c(G3[1], g)
    row <- paste0(row, sprintf(" | %s p %s", g, fp(pbin(d[[v]][s], droplevels(d$grp3[s]))))) }
  cat(row, "\n") }

cat("\n=== Multivessel disease ===\n")
cat(sprintf("%% MVD across 3 groups: p %s\n", fp(pbin(d$mvd, d$grp3))))
for (g in G3[-1]) cat(sprintf("Adjusted OR %s vs concordant: p %s\n", g,
                              fp(pmod(m2, paste0("grp3", g)))))
cat(sprintf("Percentile gap per SD: p %s\n", fp(pmod(m2g, "gap_z"))))
cat(sprintf("No LLT, apoB per SD: p %s\n", fp(pmod(m2u, "apob_z"))))

cat("\n=== Determinants of discordantly high apoB ===\n")
for (v in c(VARS, "female")) {
  m <- glm(reformulate(v, "du_high"), binomial, dz)
  cat(sprintf("Univariable   %-14s p %s\n", v, fp(pmod(m, grep(v, names(coef(m)))[1]))))
}
for (v in MV) cat(sprintf("Multivariable %-14s p %s\n", v, fp(pmod(m3, grep(v, names(coef(m3)))[1]))))

cat("\n=== 'Neither' discordantly high vs concordant ===\n")
for (v in c("ratio", "bmi", "hba1c"))
  cat(sprintf("%-6s p %s\n", v, fp(wilcox.test(nei[[v]], con[[v]])$p.value)))
