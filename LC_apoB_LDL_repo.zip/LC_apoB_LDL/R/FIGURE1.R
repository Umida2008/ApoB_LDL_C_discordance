# =============================================================================
# FIGURE 1 (full paper)
#   A  apoB vs LDL-C in percentile space: +/-10 band = discordance definition
#      (Du), LDL-C targets marked, prevalence written into the plot
#   B  within each LDL-C stratum: % whose apoB falls in a LOWER, the MATCHING
#      or a HIGHER guideline-paired apoB category.
#      Pairs: LDL-C <55 / apoB <65, 55-69 / 65-79, 70-99 / 80-99,
#      100-129 / 100-119, >=130 / >=120 mg/dL.
# Run after analysis.R. Needs dplyr, ggplot2, patchwork.
# =============================================================================

library(dplyr); library(ggplot2); library(patchwork)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
GRP <- c("Concordant", "Discordantly high apoB", "Discordantly low apoB")
PAL <- setNames(c("grey60", "#D55E00", "#0072B2"), GRP)
th  <- theme_bw(15) + theme(panel.grid.minor = element_blank(),
                            text = element_text(colour = "black"),
                            axis.text = element_text(colour = "black"),
                            plot.tag = element_text(face = "bold", size = 18))
np  <- function(sel, l) { x <- an$du[sel] == l
                          sprintf("%d/%d (%.1f%%)", sum(x), length(x), 100*mean(x)) }

# --- A  percentile scatter -------------------------------------------------------
dA <- an %>% mutate(p_ldl = pctile(ldl), p_apob = pctile(apob_mgdl))
q  <- c(`55` = 100*mean(an$ldl < 55), `70` = 100*mean(an$ldl < 70))
mgax <- function(v, at, name)                   # mg/dL ticks at their percentile
  sec_axis(~ ., name = name, labels = at,
           breaks = sapply(at, function(a) 100*mean(v < a, na.rm = TRUE)))
everyone <- rep(TRUE, nrow(an))

A <- ggplot(dA, aes(p_ldl, p_apob, colour = du)) +
  annotate("rect", xmin = 0, xmax = q["70"], ymin = 0, ymax = 100, fill = "grey93") +
  geom_abline(slope = 1, intercept = c(-10, 10), linetype = "22", colour = "grey30") +
  geom_point(size = 1.3, alpha = .7) +
  geom_vline(xintercept = q, colour = "grey30", linewidth = .4) +
  annotate("text", x = q, y = 1, label = c("LDL-C 55", "LDL-C 70"), angle = 90,
           hjust = 0, vjust = -.5, size = 4, colour = "black") +
  annotate("label", x = 30, y = 97, hjust = 0, vjust = 1, size = 4.2, colour = "black",
           label.size = 0, fill = alpha("white", .85),
           label = paste0("Discordantly high: ", np(everyone, GRP[2]),
                          "\nat LDL-C < 70: ", np(an$ldl < 70, GRP[2]),
                          "\nat LDL-C < 55: ", np(an$ldl < 55, GRP[2]))) +
  annotate("label", x = 99, y = 3, hjust = 1, vjust = 0, size = 4.2, colour = "black",
           label.size = 0, fill = alpha("white", .85),
           label = paste0("Discordantly low: ", np(everyone, GRP[3]))) +
  scale_colour_manual(values = PAL, name = NULL) +
  scale_x_continuous("LDL-C percentile", limits = c(0, 100), expand = c(0, 0),
    sec.axis = mgax(an$ldl, c(50, 70, 100, 150, 200), "LDL-C (mg/dL)")) +
  scale_y_continuous("ApoB percentile", limits = c(0, 100), expand = c(0, 0),
    sec.axis = mgax(an$apob_mgdl, c(50, 65, 80, 100, 130), "ApoB (mg/dL)")) +
  guides(colour = guide_legend(override.aes = list(size = 3.5, alpha = 1), ncol = 1)) +
  th + theme(legend.position = "top") + labs(tag = "A")

# --- B  apoB category relative to the LDL-C stratum --------------------------------
LCAT <- c("< 55", "55–69", "70–99", "100–129", "≥ 130")
REL  <- c("ApoB category higher", "Matching", "ApoB category lower")
PALB <- setNames(c("#D55E00", "grey75", "#0072B2"), REL)

dB <- an %>% mutate(
  lc  = cut(ldl,       c(-Inf, 55, 70, 100, 130, Inf), LCAT, right = FALSE),
  bc  = cut(apob_mgdl, c(-Inf, 65, 80, 100, 120, Inf), right = FALSE),
  rel = factor(case_when(as.integer(bc) > as.integer(lc) ~ REL[1],
                         as.integer(bc) < as.integer(lc) ~ REL[3],
                         TRUE ~ REL[2]), REL))       # stacking: lower at the bottom
seg <- dB %>% count(lc, rel, .drop = FALSE) %>% group_by(lc) %>%
  mutate(pct = 100*n/sum(n), N = sum(n)) %>% ungroup()
xl  <- seg %>% distinct(lc, N) %>% mutate(l = paste0(lc, "\n(n = ", N, ")"))

B <- ggplot(seg, aes(lc, pct, fill = rel)) +
  geom_col(width = .7, colour = "white", linewidth = .6) +
  geom_text(aes(label = ifelse(pct >= 4, sprintf("%.0f%%", pct), "")),
            position = position_stack(vjust = .5), size = 4.6, colour = "black") +
  scale_fill_manual(values = PALB, name = NULL) +
  scale_x_discrete(labels = setNames(xl$l, xl$lc)) +
  scale_y_continuous(limits = c(0, 100.5), breaks = seq(0, 100, 25), expand = c(0, 0)) +
  labs(x = "LDL-C (mg/dL)", y = "Patients within LDL-C stratum (%)", tag = "B") +
  guides(fill = guide_legend(ncol = 1)) +
  th + theme(legend.position = "top", panel.grid.major.x = element_blank())

FIG1 <- (A | B) + plot_layout(widths = c(1.1, 1))
ggsave(out("FIGURE1.png"), FIG1, width = 15, height = 7.5, dpi = 300)
write.csv(select(seg, lc, rel, n, pct), out("TABLE_fig1b.csv"), row.names = FALSE)
message("Written: FIGURE1.png and TABLE_fig1b.csv")
