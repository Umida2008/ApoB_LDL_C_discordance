# =============================================================================
# Numbers for the Results text (percentile gap, Du, as primary definition).
# Three groups: concordant (reference), discordantly high, discordantly low.
# Each block prints the numbers for one paragraph. Run after analysis.R.
# =============================================================================
library(dplyr)
if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("an"))  an  <- readRDS(file.path(OUT, "an.rds"))
an$du_high <- an$du == "Discordantly high apoB"

num    <- function(x) suppressWarnings(as.numeric(as.character(x)))
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
z      <- function(x) as.numeric(scale(x))
mq     <- function(x) sprintf("%.1f (%.1f-%.1f)", median(x, na.rm = TRUE),
                              quantile(x, .25, na.rm = TRUE), quantile(x, .75, na.rm = TRUE))
orci   <- function(m, j) { s <- summary(m)$coefficients
  sprintf("%.2f (%.2f-%.2f)", exp(s[j, 1]), exp(s[j, 1] - 1.96*s[j, 2]), exp(s[j, 1] + 1.96*s[j, 2])) }

G3 <- c("Concordant", "ApoB-high", "ApoB-low")
d <- an %>% mutate(
  grp3 = factor(case_when(du == "Discordantly high apoB" ~ G3[2],
                          du == "Discordantly low apoB"  ~ G3[3],
                          TRUE                           ~ G3[1]), G3),
  tg = num(triglyceride), log_tg = log(tg), hdl = num(hdl), lpa = num(lp_a),
  log_lpa = log1p(lpa), hba1c = num(hba1c), bmi = num(bmi),
  low_hdl = (hdl < 40 & !female) | (hdl < 50 & female),
  trl = tg >= 150 | low_hdl, lpa_hi = lpa >= 125, ratio = ldl / apob_mgdl)
print(table(d$grp3))

# --- 1  profile by group (paragraph 1) ------------------------------------------
cat("\n=== 1. Profile by group: median (IQR) or % ===\n")
print(as.data.frame(d %>% group_by(grp3) %>% summarise(
  n = n(), age = mq(age), `women %` = round(100*mean(female), 1),
  TG = mq(tg), HDL = mq(hdl), HbA1c = mq(hba1c), `Lp(a)` = mq(lpa),
  `statin %` = round(100*mean(on_statin), 1), `LDL-C/apoB` = mq(ratio))))

# --- 2  multivessel disease by group (paragraph 3) --------------------------------
cat("\n=== 2. Multivessel disease ===\n")
print(d %>% filter(!is.na(mvd)) %>% group_by(grp3) %>%
        summarise(n = n(), mvd_pct = round(100*mean(mvd), 1)))
m2 <- glm(mvd ~ grp3 + I(age/10) + female + dm + htn + smoke + llt, binomial, d)
for (g in G3[-1]) cat(sprintf("Adjusted OR vs concordant, %s: %s\n", g,
                              orci(m2, paste0("grp3", g))))
m2g <- glm(mvd ~ gap_z + I(age/10) + female + dm + htn + smoke + llt, binomial, d)
cat(sprintf("Percentile gap per SD, adjusted OR %s\n", orci(m2g, "gap_z")))
u  <- d %>% filter(llt == "No lipid-lowering therapy") %>% mutate(apob_z = z(apob_mgdl))
m2u <- glm(mvd ~ apob_z + I(age/10) + female + dm + htn + smoke, binomial, u)
cat(sprintf("No LLT (n = %d): apoB per SD, adjusted OR %s\n", nobs(m2u), orci(m2u, "apob_z")))

# --- 3  lipid determinants of discordantly high apoB (paragraph 4, Fig. 3) --------
cat("\n=== 3. Determinants of discordantly high apoB vs all others, OR per SD ===\n")
VARS <- c("age", "bmi", "taillenumfang", "log_tg", "hdl", "log_lpa", "hba1c")
dz <- d %>% mutate(taillenumfang = num(taillenumfang), female = as.numeric(female),
                   across(all_of(VARS), z))
for (v in c(VARS, "female")) {
  m <- glm(reformulate(v, "du_high"), binomial, dz)
  cat(sprintf("Univariable %-14s %s (n = %d)\n", v, orci(m, grep(v, names(coef(m)))[1]), nobs(m)))
}
MV <- c("age", "female", "bmi", "log_tg", "hdl", "log_lpa", "hba1c")   # waist omitted: collinear with BMI
m3 <- glm(reformulate(MV, "du_high"), binomial, dz)
for (v in MV) cat(sprintf("Multivariable %-12s %s\n", v, orci(m3, grep(v, names(coef(m3)))[1])))
cat(sprintf("Multivariable n = %d, events = %d\n", nobs(m3), sum(m3$y)))

# --- 4  variance of the continuous gap explained (paragraph 5) --------------------
cat("\n=== 4. Continuous percentile gap: R2 and share of explained variance ===\n")
fl <- reformulate(MV, "gap")
lm4 <- lm(fl, dz)
cat(sprintf("R2 = %.1f%% (n = %d)\n", 100*summary(lm4)$r.squared, nobs(lm4)))
if (requireNamespace("relaimpo", quietly = TRUE)) {
  ri <- relaimpo::calc.relimp(lm4, type = "lmg", rela = TRUE)
  print(round(100*sort(ri@lmg, decreasing = TRUE), 1))
} else cat("install.packages('relaimpo') for the share of explained variance\n")

# Lp(a) particles removed from the apoB pool (apoB mg/dL -> nmol/L: x 1e7/512000)
d4 <- dz %>% mutate(apob_nmol = apob_mgdl*1e7/512000, share = 100*lpa/apob_nmol,
                    gap_nolpa = pctile(apob_nmol - lpa) - pctile(ldl))
cat(sprintf("Median Lp(a) share of apoB particles: %s %%\n", mq(d4$share)))
for (y in c("gap", "gap_nolpa")) {
  s <- summary(lm(reformulate(MV, y), d4))$coefficients["log_lpa", ]
  cat(sprintf("%-9s: beta for Lp(a) per SD = %.2f (%.2f to %.2f), p = %.3g\n", y,
              s[1], s[1] - 1.96*s[2], s[1] + 1.96*s[2], s[4]))
}

# --- 5  TRL and Lp(a) criteria among discordantly high (paragraph 6) --------------
cat("\n=== 5. Discordantly high apoB with complete TG, HDL-C and Lp(a) ===\n")
h <- d %>% filter(du_high, !is.na(trl), !is.na(lpa_hi))
cat(sprintf("n = %d; TRL %.0f%%, Lp(a) >= 125 %.0f%%, both %.0f%%, neither %.0f%%\n", nrow(h),
            100*mean(h$trl), 100*mean(h$lpa_hi), 100*mean(h$trl & h$lpa_hi),
            100*mean(!h$trl & !h$lpa_hi)))
nei <- h %>% filter(!trl, !lpa_hi)
con <- d %>% filter(du == "Concordant")
cat(sprintf("Neither (n = %d) vs concordant: LDL-C/apoB %s vs %s; BMI %s vs %s; HbA1c %s vs %s\n",
            nrow(nei), mq(nei$ratio), mq(con$ratio), mq(nei$bmi), mq(con$bmi),
            mq(nei$hba1c), mq(con$hba1c)))
