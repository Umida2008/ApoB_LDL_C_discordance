# =============================================================================
# Shape of the association between the percentile gap and outcome.
# Restricted cubic spline (4 knots) for the gap, adjusted for age, sex,
# diabetes, hypertension, smoking and lipid-lowering therapy. Reference: gap 0,
# i.e. apoB and LDL-C at the same percentile. Dashed lines mark the +/-10-unit
# thresholds of Du et al. Whole cohort, complete case. Run after analysis.R.
# =============================================================================

library(dplyr); library(ggplot2); library(rms)

if (!exists("OUT")) OUT <- "/home/umida/Dokumente/LC_apoB_LDL"
if (!exists("out")) out <- function(f) file.path(OUT, f)
if (!exists("an"))  an  <- readRDS(out("an.rds"))

num    <- function(x) suppressWarnings(as.numeric(as.character(x)))
pctile <- function(x) 100*(rank(x, na.last = "keep") - 0.5)/sum(!is.na(x))
if (!"gap" %in% names(an)) an$gap <- pctile(an$apob_mgdl) - pctile(an$ldl)
if (!"llt" %in% names(an))
  an <- an %>% mutate(llt = factor(case_when(
      on_pcsk9 | (on_eze & !on_statin) ~ "Other lipid-lowering therapy",
      on_statin & high ~ "High-intensity statin",
      on_statin        ~ "Moderate-intensity statin",
      TRUE             ~ "No lipid-lowering therapy")))

dx <- an %>%
  transmute(gap, age, female = as.integer(female), dm = as.integer(dm),
            htn = as.integer(htn), smoke = as.integer(smoke), llt = droplevels(llt),
            obstr = as.integer(obstr), mvd = as.integer(mvd),
            time = if ("mace_yrs" %in% names(an)) num(mace_yrs) else NA,
            event = if ("mace" %in% names(an)) num(mace) else NA)

dd <- datadist(dx); dd$limits["Adjust to", "gap"] <- 0; options(datadist = "dd")
rng <- quantile(dx$gap, c(.01, .99), na.rm = TRUE)
grid <- seq(rng[1], rng[2], length.out = 200)
COV <- "+ age + female + dm + htn + smoke + llt"

curve1 <- function(fit, label) {
  a  <- anova(fit)
  pr <- as.data.frame(Predict(fit, gap = grid, ref.zero = TRUE, fun = exp))
  data.frame(gap = pr$gap, est = pr$yhat, lo = pr$lower, hi = pr$upper,
             outcome = label, n = fit$stats["Obs"],
             p_all = a["gap", "P"], p_nl = a[grep("Nonlinear", rownames(a))[1], "P"])
}

cur <- bind_rows(
  curve1(lrm(as.formula(paste("obstr ~ rcs(gap, 4)", COV)), data = dx),
         "Obstructive CAD (odds ratio)"),
  curve1(lrm(as.formula(paste("mvd ~ rcs(gap, 4)", COV)), data = dx),
         "Multivessel disease (odds ratio)"),
  if (any(!is.na(dx$event)))
    curve1(cph(as.formula(paste("Surv(time, event) ~ rcs(gap, 4)", COV)),
               data = dx %>% filter(time > 0)),
           "MACE (hazard ratio)"))

ptab <- cur %>% distinct(outcome, n, p_all, p_nl)
print(ptab, row.names = FALSE)
write.csv(ptab, out("TABLE_spline_gap.csv"), row.names = FALSE)

lab <- ptab %>% mutate(txt = sprintf("p overall %s\np non-linear %s",
         ifelse(p_all < .001, "< 0.001", sprintf("= %.3f", p_all)),
         ifelse(p_nl  < .001, "< 0.001", sprintf("= %.3f", p_nl))))

FIG <- ggplot(cur, aes(gap, est)) +
  geom_hline(yintercept = 1, colour = "grey55") +
  geom_vline(xintercept = c(-10, 10), linetype = "22", colour = "grey55") +
  geom_ribbon(aes(ymin = lo, ymax = hi), fill = "#0072B2", alpha = .15) +
  geom_line(colour = "#0072B2", linewidth = .9) +
  geom_rug(data = dx %>% filter(between(gap, rng[1], rng[2])),
           aes(x = gap), inherit.aes = FALSE, alpha = .15, length = unit(.02, "npc")) +
  geom_text(data = lab, aes(x = -Inf, y = Inf, label = txt), hjust = -.05,
            vjust = 1.3, size = 3.2, colour = "grey25", inherit.aes = FALSE) +
  facet_wrap(~ outcome, nrow = 1) +
  scale_y_log10() +
  labs(x = "Percentile gap (apoB percentile minus LDL-C percentile)",
       y = "Adjusted ratio vs gap = 0") +
  theme_bw(12) + theme(panel.grid.minor = element_blank(),
                       strip.text = element_text(face = "bold", hjust = 0))
ggsave(out("FIGURE_spline_gap.png"), FIG, width = 12, height = 4.5, dpi = 300)
message("Written: TABLE_spline_gap.csv and FIGURE_spline_gap.png")
