import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Wedge, Polygon
plt.rcParams.update({"font.family":"DejaVu Sans","text.color":"black","axes.edgecolor":"black",
                     "xtick.color":"black","ytick.color":"black","axes.labelcolor":"black"})
GR,HI,LO,INK="#8c8c8c","#D55E00","#0072B2","#111111"
PANEL="#fbfbfb"; EDGE="#cfcfcf"; CHOL="#F3D27A"
OUT="/mnt/user-data/outputs/"

W,H=20,10.6
fig=plt.figure(figsize=(W,H),dpi=300)
bg=fig.add_axes([0,0,1,1]); bg.axis("off"); bg.set_xlim(0,W); bg.set_ylim(0,H)

def card(x,y,w,h,fc=PANEL,ec=EDGE,lw=1.4,r=.18):
    bg.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f"round,pad=0,rounding_size={r}",fc=fc,ec=ec,lw=lw))
def head(x,y,num,txt):
    bg.add_patch(Circle((x+.32,y),.24,fc=INK,ec="none"))
    bg.text(x+.32,y,num,ha="center",va="center",color="white",fontsize=15,weight="bold")
    bg.text(x+.68,y,txt,ha="left",va="center",fontsize=16.5,weight="bold")
def chevron(x,y):
    bg.add_patch(Polygon([[x,y+.32],[x+.22,y],[x,y-.32]],closed=False,fill=False,ec="#9a9a9a",lw=3,joinstyle="miter"))

# ---------- header ----------
bg.add_patch(FancyBboxPatch((0,9.55),W,1.05,boxstyle="square,pad=0",fc=INK,ec="none"))
bg.text(.45,10.18,"Discordantly high apolipoprotein B: hidden atherogenic risk at LDL-C target",
        color="white",fontsize=24,weight="bold",va="center")
bg.text(.45,9.76,"LipidCardio  ·  926 patients undergoing elective coronary angiography  ·  paired apoB and directly measured LDL-C  ·  3-year follow-up",
        color="#e6e6e6",fontsize=14,va="center")

# panel geometry
Y0,PH=2.05,7.15; xs=[.35,5.3,10.25,15.2]; PW=4.45
for x in xs: card(x,Y0,PW,PH)
for x in xs[1:]: chevron(x-.36,Y0+PH/2)

# ---------- 1  defining discordance ----------
head(xs[0]+.1,Y0+PH-.42,"1","Defining discordance")
ax=fig.add_axes([(xs[0]+.75)/W,(Y0+1.55)/H,3.35/W,4.45/H])
rng=np.random.default_rng(11); n=926
z1=rng.normal(size=n); z2=.84*z1+np.sqrt(1-.84**2)*rng.normal(size=n)
pct=lambda v:100*(np.argsort(np.argsort(v))+.5)/n
pl,pa=pct(z1),pct(z2); g=pa-pl
ax.fill_between([0,100],[10,110],[100,100],color=HI,alpha=.07,lw=0)
ax.fill_between([0,100],[0,0],[-10,90],color=LO,alpha=.07,lw=0)
ax.scatter(pl,pa,s=5,lw=0,alpha=.8,c=np.where(g>10,HI,np.where(g<-10,LO,"#b3b3b3")))
for o in (10,-10): ax.plot([0,100],[o,100+o],ls="--",c="#555",lw=1)
ax.set(xlim=(0,100),ylim=(0,100),xticks=[0,50,100],yticks=[0,50,100])
ax.set_xlabel("LDL-C percentile",fontsize=13); ax.set_ylabel("ApoB percentile",fontsize=13)
ax.tick_params(labelsize=11)
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.text(3,97,"18%\ndiscordantly\nhigh apoB",color=HI,fontsize=13,weight="bold",va="top")
ax.text(97,3,"18%\ndiscordantly\nlow apoB",color=LO,fontsize=13,weight="bold",ha="right",va="bottom")
ax.text(62,55,"64%\nconcordant",color="#555",fontsize=12,weight="bold",ha="center",rotation=0,
        bbox=dict(fc="white",ec="none",alpha=.75,pad=1))
bg.text(xs[0]+PW/2,Y0+.82,"Percentile gap = apoB − LDL-C percentile",ha="center",fontsize=13,weight="bold")
bg.text(xs[0]+PW/2,Y0+.38,"> +10: high   ·   < −10: low",ha="center",fontsize=13)

# ---------- 2  hidden at target ----------
x0=xs[1]; head(x0+.1,Y0+PH-.42,"2","Hidden at LDL-C target")
bg.text(x0+PW/2,Y0+PH-1.35,"1 in 4",ha="center",fontsize=46,weight="bold",color=HI)
bg.text(x0+PW/2,Y0+PH-2.05,"patients at LDL-C target still have\ndiscordantly high apoB",ha="center",va="center",fontsize=13.5)
rows=[("All patients",17.9,15.6,20.5),("High-intensity statin",18.0,14.0,22.9),
      ("LDL-C < 70 mg/dL",27.2,21.9,33.2),("LDL-C < 55 mg/dL",24.5,17.0,33.9)]
ax=fig.add_axes([(x0+.3)/W,(Y0+.55)/H,(PW-.6)/W,3.25/H])
for i,(lab,p,lo,hi) in enumerate(rows):
    y=len(rows)-1-i; col=HI if "LDL-C" in lab else "#c9c9c9"
    ax.barh(y,p,height=.58,color=col)
    ax.text(-1,y+.47,lab,fontsize=12.5,va="center",ha="left")
    ax.text(p+1.2,y,f"{p:.0f}%",fontsize=14,weight="bold",va="center",color=HI if "LDL-C" in lab else INK)
ax.set_xlim(-1,36); ax.set_ylim(-.45,len(rows)-.1); ax.axis("off")

# ---------- 3  phenotype ----------
x0=xs[2]; head(x0+.1,Y0+PH-.42,"3","Same LDL-C, more particles")
def ldl(cx,cy,r,lab=None):
    bg.add_patch(Circle((cx,cy),r,fc=CHOL,ec="#b68d1c",lw=1.2))
    bg.add_patch(Circle((cx,cy),r*.62,fc="#F7E3A8",ec="none"))
    bg.add_patch(Wedge((cx,cy),r*1.12,200,340,width=r*.16,fc=HI,ec="none"))
cy=Y0+PH-1.75
ldl(x0+1.15,cy,.62)
for dx,dy in ((-.36,.3),(.36,.3),(0,-.3)): ldl(x0+3.3+dx,cy+dy,.3)
bg.text(x0+1.15,cy-1.05,"Concordant\nLDL-C/apoB 1.1",ha="center",va="center",fontsize=12)
bg.text(x0+3.3,cy-1.05,"Discordantly high\nLDL-C/apoB 0.9",ha="center",va="center",fontsize=12,color=HI,weight="bold")
bg.add_patch(Wedge((x0+.6,Y0+3.62),.12,180,360,width=.05,fc=HI,ec="none"))
bg.text(x0+.8,Y0+3.62,"= apoB (one per particle)",fontsize=11,va="center")
chips=[("Lp(a) ↑  OR 1.61/SD",HI),("CRP > 5 mg/L  OR 2.33",HI),("Type 2 diabetes  OR 1.86",HI),
       ("HDL-C ↓  OR 0.77/SD",LO),("Female sex  OR 0.44",LO)]
for i,(t,c) in enumerate(chips):
    yy=Y0+3.1-i*.42
    bg.add_patch(FancyBboxPatch((x0+.35,yy-.17),PW-.7,.34,boxstyle="round,pad=0,rounding_size=.12",fc="white",ec=c,lw=1.3))
    bg.text(x0+PW/2,yy,t,ha="center",va="center",fontsize=12.5)
# explained bar
yb=Y0+.6; bx=x0+.35; bw=PW-.7
bg.add_patch(FancyBboxPatch((bx,yb-.13),bw,.26,boxstyle="round,pad=0,rounding_size=.1",fc="#e6e6e6",ec="none"))
bg.add_patch(FancyBboxPatch((bx,yb-.13),bw*.139,.26,boxstyle="round,pad=0,rounding_size=.1",fc=INK,ec="none"))
bg.text(x0+PW/2,yb+.38,"Clinical + lipid factors explain only 14%",ha="center",fontsize=12.5,weight="bold")

# ---------- 4  outcome ----------
x0=xs[3]; head(x0+.1,Y0+PH-.42,"4","3-year MACE")
bg.text(x0+PW/2,Y0+PH-.98,"death, MI or stroke  ·  n = 800, 183 events",ha="center",fontsize=11.5)
ax=fig.add_axes([(x0+.55)/W,(Y0+2.6)/H,(PW-.85)/W,3.2/H])
d=[("Concordant",21.1,17.5,24.5,GR),("Discordantly\nhigh apoB",38.3,29.3,46.2,HI),("Discordantly\nlow apoB",16.0,9.9,21.7,LO)]
for i,(lab,p,lo,hi,c) in enumerate(d):
    ax.bar(i,p,.62,color=c); ax.plot([i,i],[lo,hi],c=INK,lw=1.6)
    ax.text(i,hi+1.5,f"{p:.0f}%",ha="center",fontsize=16,weight="bold",color=c if c!=GR else INK)
ax.set_xticks(range(3)); ax.set_xticklabels([x[0] for x in d],fontsize=11.5)
ax.set_ylim(0,55); ax.set_yticks([0,20,40]); ax.tick_params(labelsize=11)
ax.set_ylabel("Cumulative incidence (%)",fontsize=12)
for s in ("top","right"): ax.spines[s].set_visible(False)
card(x0+.35,Y0+.35,PW-.7,1.45,fc="#fdf0e8",ec=HI,lw=1.6,r=.12)
bg.text(x0+PW/2,Y0+1.43,"Adjusted HR 1.68 (1.19–2.37)",ha="center",fontsize=16,weight="bold",color=HI)
bg.text(x0+PW/2,Y0+1.03,"discordantly high vs concordant",ha="center",fontsize=12)
bg.text(x0+PW/2,Y0+.62,"per SD of gap: HR 1.25 (1.09–1.42)",ha="center",fontsize=12)

# ---------- take-home ----------
card(.35,.3,W-.7,1.45,fc=INK,ec="none",r=.16)
bx,by=1.25,1.02
bg.add_patch(Wedge((bx,by),.5,90-.30*360,90,width=.17,fc=HI,ec="none"))
bg.add_patch(Wedge((bx,by),.5,90,360-.30*360+90-360+360,width=.17,fc="#555",ec="none"))
bg.text(bx,by,"30%",ha="center",va="center",fontsize=13,weight="bold",color="white")
bg.text(2.0,by+.22,"Non-HDL-C identified only 30%",color="white",fontsize=14,weight="bold",va="center")
bg.text(2.0,by-.22,"of patients with discordantly high apoB",color="#dddddd",fontsize=13,va="center")
bg.plot([7.55,7.55],[.55,1.5],c="#666",lw=1.2)
bg.text(7.9,by+.2,"LDL-C at target does not mean apoB at target.",color="white",fontsize=19,weight="bold",va="center")
bg.text(7.9,by-.28,"Measure apoB to uncover residual particle-driven risk, especially in treated patients.",
        color="#f2c6a8",fontsize=15,va="center")

fig.savefig(OUT+"graphical_abstract_v2.png",dpi=300)
fig.savefig(OUT+"graphical_abstract_v2.pdf")
print("ok")
