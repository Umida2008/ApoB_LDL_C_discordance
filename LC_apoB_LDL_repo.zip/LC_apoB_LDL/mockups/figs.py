import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
plt.rcParams.update({"font.size":13,"axes.edgecolor":"black","text.color":"black","axes.labelcolor":"black",
                     "xtick.color":"black","ytick.color":"black","font.family":"DejaVu Sans"})
OUT="/mnt/user-data/outputs/mock_results/"
GR,HI,LO="#9a9a9a","#D55E00","#0072B2"
def wm(ax,txt="ILLUSTRATIVE DATA"):
    ax.text(.99,.99,txt,transform=ax.transAxes,ha="right",va="top",fontsize=9,color="#b00020",weight="bold",
            bbox=dict(fc="white",ec="#b00020",lw=.8,alpha=.9))
def tag(ax,s): ax.text(-.13,1.04,s,transform=ax.transAxes,fontsize=20,weight="bold")
def clean(ax):
    for s in ("top","right"): ax.spines[s].set_visible(False)

# ---------------- Figure 1 ----------------
rng=np.random.default_rng(7); n=926
z1=rng.normal(size=n); z2=.82*z1+np.sqrt(1-.82**2)*rng.normal(size=n)
pct=lambda x:100*(np.argsort(np.argsort(x))+.5)/len(x)
pl,pa=pct(z1),pct(z2); gap=pa-pl
col=np.where(gap>10,HI,np.where(gap<-10,LO,GR))
fig,axs=plt.subplots(1,2,figsize=(16,7.2),dpi=200,gridspec_kw={"width_ratios":[1.05,1]})
ax=axs[0]; q55,q70=100*98/926,100*239/926
ax.axvspan(0,q70,color="#ececec",zorder=0)
xx=np.linspace(0,100,2); ax.plot(xx,xx+10,"--",c="#444",lw=1); ax.plot(xx,xx-10,"--",c="#444",lw=1)
ax.scatter(pl,pa,s=9,c=col,alpha=.75,lw=0,zorder=2)
for q,l in ((q55,"LDL-C 55"),(q70,"LDL-C 70")):
    ax.axvline(q,c="#444",lw=.8); ax.text(q-1,2,l,rotation=90,va="bottom",ha="right",fontsize=11)
ax.text(30,88,"Discordantly high: 166/926 (17.9%)\nat LDL-C < 70: 65/239 (27.2%)\nat LDL-C < 55: 24/98 (24.5%)",
        va="top",fontsize=12,bbox=dict(fc="white",ec="none",alpha=.85))
ax.text(99,3,"Discordantly low: 169/926 (18.3%)",ha="right",fontsize=12,bbox=dict(fc="white",ec="none",alpha=.85))
ax.set(xlim=(0,100),ylim=(0,100),xlabel="LDL-C percentile",ylabel="ApoB percentile"); clean(ax)
ax.legend(handles=[Line2D([],[],marker="o",ls="",c=c,label=l,ms=8) for c,l in ((GR,"Concordant"),(HI,"Discordantly high apoB"),(LO,"Discordantly low apoB"))],
          loc="lower center",bbox_to_anchor=(.5,1.02),ncol=3,frameon=False,fontsize=11)
wm(ax,"POINTS ILLUSTRATIVE · numbers real"); tag(ax,"A")
ax=axs[1]
L=["< 55\n(n = 98)","55–69\n(n = 141)","70–99\n(n = XX)","100–129\n(n = XX)","≥ 130\n(n = XX)"]
P=np.array([[0,84,16],[24,52,24],[30,48,22],[34,46,20],[40,60,0]],float)  # lower, matching, higher
cols=[LO,"#c8c8c8",HI]
for i,r in enumerate(P):
    y=0
    for k,v in enumerate(r):
        ax.bar(i,v,bottom=y,width=.7,color=cols[k],edgecolor="white",lw=1.2)
        if v>=4: ax.text(i,y+v/2,f"{v:.0f}%",ha="center",va="center",fontsize=12)
        y+=v
ax.set_xticks(range(5)); ax.set_xticklabels(L,fontsize=11); ax.set_ylim(0,110); ax.set_yticks(range(0,101,20))
ax.set_xlabel("LDL-C (mg/dL)"); ax.set_ylabel("Patients within LDL-C stratum (%)"); clean(ax)
ax.legend(handles=[Patch(color=cols[k],label=l) for k,l in ((2,"ApoB category higher"),(1,"Matching"),(0,"ApoB category lower"))],
          loc="lower center",bbox_to_anchor=(.5,1.02),ncol=3,frameon=False,fontsize=11)
wm(ax,"ILLUSTRATIVE except < 55 (16%)"); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure1_mock.png"); plt.close()

# ---------------- Figure 2 ----------------
fig,axs=plt.subplots(1,2,figsize=(18,7.5),dpi=200)
ax=axs[0]
rows=[("Hypothyroidism","= 0.61",(11,10,12)),("eGFR < 60","= 0.48",(24,26,23)),
      ("Prediabetes (HbA1c 5.7–6.4%)","= 0.21",(38,43,33)),("Central obesity (WHtR ≥ 0.5)","= 0.09",(88,92,86)),
      ("Hypertension","= 0.03",(80,88,79)),("Type 2 diabetes","< 0.001",(24,38,23)),("CRP > 5 mg/L","< 0.001",(27,44,22))]
for i,(lab,p,(c,h,l)) in enumerate(rows):
    ax.plot([min(c,h,l),max(c,h,l)],[i,i],c="#d9d9d9",lw=4,zorder=1,solid_capstyle="round")
    for v,cc in ((c,GR),(h,HI),(l,LO)): ax.scatter(v,i,s=90,c=cc,zorder=3,edgecolor="white")
ax.set_yticks(range(len(rows))); ax.set_yticklabels([f"{r[0]} (p {r[1]})" for r in rows],fontsize=12)
ax.set_xlim(0,100); ax.set_xlabel("Patients with the characteristic (%)"); clean(ax); ax.grid(axis="x",c="#eee")
ax.legend(handles=[Line2D([],[],marker="o",ls="",c=c,label=l,ms=9) for c,l in ((GR,"Concordant"),(HI,"Discordantly high apoB"),(LO,"Discordantly low apoB"))],
          loc="lower center",bbox_to_anchor=(.35,1.02),ncol=3,frameon=False,fontsize=11)
wm(ax); ax.text(-.62,1.04,"A",transform=ax.transAxes,fontsize=20,weight="bold")
ax=axs[1]
ri=[("Lp(a)",3.8),("HDL-C",3.3),("Glycaemic status",2.0),("CRP > 5 mg/L",1.6),("Sex",1.1),("Triglycerides",0.8),
    ("Hypertension",0.5),("Lipid-lowering therapy",0.4),("Central obesity",0.2),("Age",0.1),("eGFR < 60",0.06),("Hypothyroidism",0.04)]
ri=ri[::-1]
ax.barh(range(len(ri)),[v for _,v in ri],color="#4d4d4d",height=.65)
for i,(_,v) in enumerate(ri): ax.text(v+.05,i,f"{v:.1f}%",va="center",fontsize=12)
ax.set_yticks(range(len(ri))); ax.set_yticklabels([k for k,_ in ri],fontsize=12)
ax.set_xlim(0,4.6); ax.set_xlabel("Variance of the percentile gap explained (%)"); clean(ax)
ax.set_title("All variables together: 13.9%; unexplained: 86.1%",fontsize=13,loc="left")
wm(ax,"BARS ILLUSTRATIVE · total 13.9% real"); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure2_mock.png"); plt.close()

# ---------------- Figure 3 ----------------
fig,axs=plt.subplots(1,2,figsize=(17,6.8),dpi=200,gridspec_kw={"width_ratios":[1.15,1]})
ax=axs[0]; t=np.linspace(0,3,200)
for end,c,l in ((21.1,GR,"Concordant"),(38.3,HI,"Discordantly high apoB"),(16.0,LO,"Discordantly low apoB")):
    y=end*(1-np.exp(-1.1*t))/(1-np.exp(-3.3)); ax.step(t,y,where="post",c=c,lw=2.4,label=f"{l} ({end}% at 3 y)")
ax.text(.05,40,"Log-rank p < 0.001",fontsize=13)
ax.set(xlim=(0,3),ylim=(0,45),xlabel="Years since index angiography",ylabel="Cumulative incidence of MACE (%)")
ax.set_xticks([0,1,2,3]); clean(ax); ax.legend(frameon=False,fontsize=11,loc="lower center",bbox_to_anchor=(.5,1.0),ncol=1)
wm(ax,"CURVE SHAPE ILLUSTRATIVE · 3-y values real"); tag(ax,"A")
ax=axs[1]
rows=[("Discordantly high apoB",(2.04,1.46,2.86),(1.68,1.19,2.37)),
      ("Discordantly low apoB",(0.75,0.48,1.16),(0.73,0.47,1.14)),
      ("Percentile gap, per SD",(1.29,1.13,1.47),(1.25,1.09,1.42))]
for i,(lab,u,a) in enumerate(rows):
    y=len(rows)-1-i
    for (e,lo,hi),dy,c in ((u,.15,"#9a9a9a"),(a,-.15,"#0072B2")):
        ax.plot([lo,hi],[y+dy,y+dy],c=c,lw=2); ax.scatter(e,y+dy,c=c,s=60,zorder=3)
    ax.text(5.2,y,f"{a[0]:.2f} ({a[1]:.2f}–{a[2]:.2f})",va="center",fontsize=12)
ax.axvline(1,ls="--",c="#555",lw=1); ax.set_xscale("log"); ax.set_xlim(.4,9)
ax.set_xticks([.5,1,2,4]); ax.set_xticklabels(["0.5","1","2","4"])
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows][::-1],fontsize=12)
ax.set_xlabel("Hazard ratio for MACE (vs concordant)"); clean(ax)
ax.legend(handles=[Line2D([],[],c="#9a9a9a",marker="o",label="Unadjusted"),Line2D([],[],c="#0072B2",marker="o",label="Adjusted")],
          frameon=False,loc="lower center",bbox_to_anchor=(.5,1.02),ncol=2,fontsize=11)
ax.set_ylim(-.6,2.9); ax.text(5.2,2.7,"Adjusted HR (95% CI)",fontsize=12,weight="bold"); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure3_mock.png"); plt.close()

# ---------------- Figure 4 ----------------
rows=[("Main analysis (adjusted)",1.68,1.19,2.37,"800 / 183"),
      ("+ multivessel disease",1.64,1.16,2.32,"XX"),
      ("MACE incl. HF hospitalisation",1.56,1.14,2.13,"797 / 243"),
      ("Residual definition of discordance",1.58,1.01,2.47,"800 / 183"),
      ("Statin-treated patients",1.86,1.25,2.75,"482 / 127"),
      ("LDL-C < 70 mg/dL",1.62,0.94,2.78,"205 / 62"),
      ("LDL-C < 55 mg/dL",1.19,0.46,3.10,"84 / 25")]
fig,ax=plt.subplots(figsize=(13,6.5),dpi=200)
for i,(lab,e,lo,hi,ne) in enumerate(rows):
    y=len(rows)-1-i
    ax.plot([lo,hi],[y,y],c=HI,lw=2.2); ax.scatter(e,y,c=HI,s=70,zorder=3,marker="s" if i==0 else "o")
    ax.text(5.6,y,f"{e:.2f} ({lo:.2f}–{hi:.2f})",va="center",fontsize=12)
    ax.text(10.5,y,ne,va="center",fontsize=12)
ax.axvline(1,ls="--",c="#555",lw=1); ax.set_xscale("log"); ax.set_xlim(.35,16)
ax.set_xticks([.5,1,2,4]); ax.set_xticklabels(["0.5","1","2","4"])
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows][::-1],fontsize=12)
ax.text(5.6,len(rows)-.35,"HR (95% CI)",fontsize=12,weight="bold"); ax.text(10.5,len(rows)-.35,"n / events",fontsize=12,weight="bold")
ax.set_xlabel("Hazard ratio for MACE, discordantly high apoB"); clean(ax)
ax.text(.0,-.17,"Subgroups adjusted for age, sex and diabetes; residual definition vs concordant by residual method.",
        transform=ax.transAxes,fontsize=10)
plt.tight_layout(); plt.savefig(OUT+"Figure4_mock.png"); plt.close()
print("ok")
