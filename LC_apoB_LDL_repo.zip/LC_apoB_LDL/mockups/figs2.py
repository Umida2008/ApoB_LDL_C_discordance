import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Patch, FancyBboxPatch
from matplotlib.lines import Line2D
plt.rcParams.update({"font.size":13,"axes.edgecolor":"black","text.color":"black","axes.labelcolor":"black",
                     "xtick.color":"black","ytick.color":"black","font.family":"DejaVu Sans"})
OUT="/mnt/user-data/outputs/mock_results/"
GR,HI,LO="#9a9a9a","#D55E00","#0072B2"
GRP=["Concordant","Discordantly\nhigh apoB","Discordantly\nlow apoB"]; GC=[GR,HI,LO]
def wm(ax,txt="ILLUSTRATIVE DATA"):
    ax.text(.99,.99,txt,transform=ax.transAxes,ha="right",va="top",fontsize=9,color="#b00020",weight="bold",
            bbox=dict(fc="white",ec="#b00020",lw=.8,alpha=.9),zorder=10)
def tag(ax,s,x=-.13): ax.text(x,1.04,s,transform=ax.transAxes,fontsize=20,weight="bold")
def clean(ax):
    for s in ("top","right"): ax.spines[s].set_visible(False)
def wil(k,n,z=1.96):
    p=k/n; d=1+z*z/n; m=(p+z*z/(2*n))/d; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return 100*p,100*max(0,m-h),100*min(1,m+h)
def grpbars(ax,labels,series,cols,names,ylab,ymax):
    w=.8/len(series); x=np.arange(len(labels))
    for j,(s,c,nm) in enumerate(zip(series,cols,names)):
        for i,(k,n) in enumerate(s):
            p,lo,hi=wil(k,n); xi=x[i]-.4+w*(j+.5)
            ax.bar(xi,p,w*.92,color=c,label=nm if i==0 else None)
            ax.errorbar(xi,p,yerr=[[p-lo],[hi-p]],c="black",capsize=3,lw=1)
            ax.text(xi,hi+1,f"{p:.0f}%",ha="center",va="bottom",fontsize=11)
    ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_ylim(0,ymax); ax.set_ylabel(ylab); clean(ax)
def forest(ax,rows,col,xlim,txtx,head="HR (95% CI)",xlabel="",ticks=(.5,1,2,4),star=()):
    for i,(lab,e,lo,hi) in enumerate(rows):
        y=len(rows)-1-i; c=col[i] if isinstance(col,list) else col
        ax.plot([lo,hi],[y,y],c=c,lw=2.2); ax.scatter(e,y,c=c,s=70,zorder=3)
        ax.text(txtx,y,f"{e:.2f} ({lo:.2f}–{hi:.2f})"+(" *" if i in star else ""),va="center",fontsize=12)
    ax.axvline(1,ls="--",c="#555",lw=1); ax.set_xscale("log"); ax.set_xlim(*xlim)
    ax.set_xticks(ticks); ax.set_xticklabels([f"{t:g}" for t in ticks]); ax.minorticks_off()
    ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows][::-1],fontsize=12)
    ax.set_ylim(-.6,len(rows)-.2); ax.text(txtx,len(rows)-.45,head,fontsize=12,weight="bold")
    ax.set_xlabel(xlabel); clean(ax)

# ===== Figure 5: prevalence by therapy and at target (REAL) =====
fig,axs=plt.subplots(1,2,figsize=(17,6.8),dpi=200,gridspec_kw={"width_ratios":[1.25,1]})
ax=axs[0]
L=["No LLT\n(n = 353)","Moderate-intensity\nstatin (n = 281)","High-intensity\nstatin (n = 283)"]
grpbars(ax,L,[[(49,353),(65,281),(51,283)],[(66,353),(39,281),(62,283)]],[HI,LO],
        ["Discordantly high apoB","Discordantly low apoB"],"Prevalence (%, 95% CI)",40)
ax.legend(frameon=False,loc="lower center",bbox_to_anchor=(.5,1.02),ncol=2,fontsize=12)
ax.text(.0,-.2,"'Other' LLT (n = 9) not shown. p across therapies: XX",transform=ax.transAxes,fontsize=11); tag(ax,"A")
ax=axs[1]
L=["All patients\n(n = 926)","LDL-C < 70\n(n = 239)","LDL-C < 55\n(n = 98)"]
grpbars(ax,L,[[(166,926),(65,239),(24,98)],[(169,926),(13,239),(0,98)]],[HI,LO],
        ["Discordantly high apoB","Discordantly low apoB"],"Prevalence (%, 95% CI)",40)
ax.legend(frameon=False,loc="lower center",bbox_to_anchor=(.5,1.02),ncol=2,fontsize=12); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure5_mock.png"); plt.close()

# ===== Figure 6: lipid & metabolic phenotype by group (REAL medians/IQR) =====
P6=[("Triglycerides (mg/dL)",[(121,90,174),(132,104,190),(106,82,147)],"p < 0.001",False),
    ("HDL-C (mg/dL)",[(47.5,39,59),(41,34,52.8),(56,45.8,68.2)],"p < 0.001",False),
    ("Lp(a) (nmol/L)",[(19.3,6,72.1),(41.1,9.8,123.9),(11.9,5,29.9)],"p < 0.001",False),
    ("LDL-C/apoB ratio",[(1.1,1.1,1.2),(0.9,0.8,1.0),(1.4,1.3,1.5)],"p < 0.001",False),
    ("HbA1c (%)",[(5.7,5.4,6.1),(5.8,5.5,6.5),(5.6,5.3,6.0)],"p < 0.001",False),
    ("On a statin (%)",[(58.7,),(69.9,),(59.8,)],"p = 0.032",True)]
fig,axs=plt.subplots(2,3,figsize=(16,9),dpi=200); axs=axs.ravel()
for k,(ttl,v,p,isbar) in enumerate(P6):
    ax=axs[k]
    for i,t in enumerate(v):
        if isbar:
            ax.bar(i,t[0],.6,color=GC[i]); ax.text(i,t[0]+1.5,f"{t[0]:.1f}",ha="center",fontsize=12)
        else:
            ax.plot([i,i],[t[1],t[2]],c=GC[i],lw=6,solid_capstyle="butt",alpha=.45)
            ax.scatter(i,t[0],c=GC[i],s=110,zorder=3,edgecolor="black",lw=.6)
            ax.text(i+.13,t[0],f"{t[0]:g}",va="center",fontsize=12)
    ax.set_xticks(range(3)); ax.set_xticklabels(GRP,fontsize=11); ax.set_xlim(-.5,2.6)
    ax.set_title(f"{ttl}   ({p})",fontsize=13,loc="left"); clean(ax)
    if isbar: ax.set_ylim(0,85)
    tag(ax,"ABCDEF"[k],-.16)
fig.text(.5,.005,"Points: median; bars: interquartile range. p: Kruskal–Wallis / chi-square across the three groups.",ha="center",fontsize=11)
plt.tight_layout(rect=(0,.03,1,1)); plt.savefig(OUT+"Figure6_mock.png"); plt.close()

# ===== Figure 7: sex (A real, B illustrative) =====
fig,axs=plt.subplots(1,2,figsize=(16,6.5),dpi=200)
ax=axs[0]
grpbars(ax,["Men\n(n = 654)","Women\n(n = 272)"],[[(140,654),(26,272)],[(120,654),(49,272)]],[HI,LO],
        ["Discordantly high apoB","Discordantly low apoB"],"Prevalence (%, 95% CI)",32)
ax.legend(frameon=False,loc="lower center",bbox_to_anchor=(.5,1.02),ncol=2,fontsize=12)
ax.text(.0,-.17,"Adjusted OR for discordantly high apoB, women vs men: 0.44 (0.26–0.74)",transform=ax.transAxes,fontsize=11)
tag(ax,"A")
ax=axs[1]; rng=np.random.default_rng(3)
gm=rng.normal(1.5,13,654); gw=rng.normal(-3,12,272); b=np.linspace(-45,45,37)
ax.hist(gm,b,density=True,alpha=.55,color="#333",label="Men"); ax.hist(gw,b,density=True,alpha=.55,color="#E69F00",label="Women")
for x in (-10,10): ax.axvline(x,ls="--",c="#444",lw=1)
ax.set(xlabel="Percentile gap (apoB − LDL-C percentile)",ylabel="Density"); clean(ax)
ax.legend(frameon=False,fontsize=12,loc="upper left"); wm(ax); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure7_mock.png"); plt.close()

# ===== Figure 8: what lies behind discordantly high apoB (REAL) =====
fig,axs=plt.subplots(1,2,figsize=(16,6.5),dpi=200,gridspec_kw={"width_ratios":[1.1,1]})
ax=axs[0]
seg=[("TRL only (TG ≥ 175 mg/dL)",23,"#CC79A7"),("Elevated Lp(a) only",19,"#009E73"),("Both",7,"#7f7f7f"),("Neither",51,"#e5e5e5")]
x0=0
for lab,v,c in seg:
    ax.barh(0,v,left=x0,color=c,edgecolor="white",height=.5); ax.text(x0+v/2,0,f"{v}%",ha="center",va="center",fontsize=15,weight="bold")
    x0+=v
ax.set_xlim(0,100); ax.set_ylim(-.45,.75); ax.set_yticks([]); ax.set_xlabel("Patients with discordantly high apoB (n = 166), %")
ax.legend(handles=[Patch(color=c,label=l) for l,_,c in seg],frameon=False,ncol=2,loc="lower center",bbox_to_anchor=(.5,.68),fontsize=12)
ax.text(0,-.4,"TRL 30% · elevated Lp(a) 26% · both 7% · neither 51%",fontsize=12); clean(ax); ax.spines["left"].set_visible(False)
tag(ax,"A",-.04)
ax=axs[1]
ax.pie([30,70],colors=[HI,"#e5e5e5"],startangle=90,counterclock=False,wedgeprops=dict(width=.38,edgecolor="white"))
ax.text(0,.08,"30%",ha="center",va="center",fontsize=30,weight="bold",color=HI)
ax.text(0,-.2,"also flagged\nby non-HDL-C",ha="center",va="center",fontsize=12)
ax.set_title("Discordantly high apoB (vs LDL-C):\nwould non-HDL-C have found them?",fontsize=13)
ax.legend(handles=[Patch(color=HI,label="Non-HDL-C also discordantly high (30%)"),Patch(color="#e5e5e5",label="Missed by non-HDL-C (70%)")],
          frameon=False,loc="lower center",bbox_to_anchor=(.5,-.12),fontsize=12)
tag(ax,"B",-.05)
plt.tight_layout(); plt.savefig(OUT+"Figure8_mock.png"); plt.close()

# ===== Figure 9: multivessel disease (REAL) =====
fig,axs=plt.subplots(1,2,figsize=(16,6.3),dpi=200,gridspec_kw={"width_ratios":[.8,1]})
ax=axs[0]
for i,(k,n) in enumerate([(320,590),(107,166),(83,169)]):
    p,lo,hi=wil(k,n); ax.bar(i,p,.6,color=GC[i]); ax.errorbar(i,p,yerr=[[p-lo],[hi-p]],c="black",capsize=4)
    ax.text(i,hi+1.5,f"{p:.1f}%\n({k}/{n})",ha="center",fontsize=12)
ax.set_xticks(range(3)); ax.set_xticklabels(GRP); ax.set_ylim(0,85); ax.set_ylabel("Multivessel disease (%, 95% CI)")
ax.text(.04,.95,"p = 0.014",transform=ax.transAxes,fontsize=13); clean(ax); tag(ax,"A")
ax=axs[1]
forest(ax,[("Discordantly high apoB",1.24,.83,1.84),("Discordantly low apoB",.63,.42,.92),("Percentile gap, per SD",1.19,1.02,1.38)],
       [HI,LO,"black"],(.3,6),2.6,"Adjusted OR (95% CI)","Odds ratio for multivessel disease (vs concordant)",(.5,1,2))
tag(ax,"B",-.35)
plt.tight_layout(); plt.savefig(OUT+"Figure9_mock.png"); plt.close()

# ===== Figure 10: continuous gap and MACE (illustrative curve) =====
fig,axs=plt.subplots(1,2,figsize=(16,6.5),dpi=200,gridspec_kw={"width_ratios":[1.3,1]})
ax=axs[0]; g=np.linspace(-40,40,200); sd=14
lhr=np.log(1.25)*g/sd+.002*np.maximum(g,0)**1.3/sd; hr=np.exp(lhr); se=.08+.0025*np.abs(g)**1.2
ax.fill_between(g,np.exp(lhr-1.96*se),np.exp(lhr+1.96*se),color=HI,alpha=.15,lw=0); ax.plot(g,hr,c=HI,lw=2.5)
ax.axhline(1,ls="--",c="#555",lw=1); ax.axvspan(-10,10,color="#eee",zorder=0)
ax.set_yscale("log"); ax.set_yticks([.5,1,2,4]); ax.set_yticklabels(["0.5","1","2","4"]); ax.minorticks_off()
ax.set(xlabel="Percentile gap (apoB − LDL-C percentile)",ylabel="Adjusted HR for MACE (ref. gap = 0)",xlim=(-40,40))
ax.text(-38,3.2,"Linear term: HR 1.25 (1.09–1.42) per SD\np for non-linearity: XX",fontsize=12)
rng=np.random.default_rng(5); r=rng.normal(0,sd,926); ax2=ax.twinx()
ax2.hist(r,np.linspace(-40,40,33),color="#bbb",alpha=.5); ax2.set_ylim(0,600); ax2.set_yticks([])
clean(ax); ax2.spines["top"].set_visible(False); wm(ax,"CURVE ILLUSTRATIVE · per-SD HR real"); tag(ax,"A")
ax=axs[1]
q=["Q1\n(most\nnegative)","Q2","Q3","Q4","Q5\n(most\npositive)"]; inc=[15.8,19.4,22.0,24.9,35.6]
ax.bar(range(5),inc,.6,color=["#0072B2","#6aa3cf","#bdbdbd","#e69a6c","#D55E00"])
for i,v in enumerate(inc): ax.text(i,v+.8,f"{v:.0f}%",ha="center",fontsize=12)
ax.set_xticks(range(5)); ax.set_xticklabels(q,fontsize=11); ax.set_ylim(0,45)
ax.set(xlabel="Quintile of the percentile gap",ylabel="3-year cumulative incidence of MACE (%)"); clean(ax)
ax.text(.02,.95,"p for trend: XX",transform=ax.transAxes,fontsize=12); wm(ax); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure10_mock.png"); plt.close()

# ===== Figure 11: mediation through multivessel disease (REAL point estimates) =====
fig,ax=plt.subplots(figsize=(13,6),dpi=200); ax.set_xlim(0,13); ax.set_ylim(0,6); ax.axis("off")
def box(x,y,t,c):
    ax.add_patch(FancyBboxPatch((x-1.6,y-.55),3.2,1.1,boxstyle="round,pad=.08",fc="white",ec=c,lw=2.5))
    ax.text(x,y,t,ha="center",va="center",fontsize=15,weight="bold")
box(2,1.4,"Discordantly\nhigh apoB",HI); box(6.5,4.5,"Multivessel\ndisease",GR); box(11,1.4,"3-year MACE","black")
kw=dict(arrowstyle="-|>",mutation_scale=25,lw=2.2,color="black")
ax.annotate("",xy=(5.0,4.1),xytext=(2.8,2.0),arrowprops=kw); ax.annotate("",xy=(10.2,2.0),xytext=(8.0,4.1),arrowprops=kw)
ax.annotate("",xy=(9.3,1.4),xytext=(3.7,1.4),arrowprops=kw)
ax.text(3.2,3.2,"OR 1.24\n(0.83–1.84)",fontsize=13,ha="right",va="center")
ax.text(9.8,3.2,"HR XX",fontsize=13,ha="left",va="center")
ax.text(6.5,1.75,"Total effect: HR 1.68 (1.19–2.37)",ha="center",fontsize=14)
ax.text(6.5,.85,"Direct effect: HR 1.64 (1.16–2.32)\n(adjusted for multivessel disease)",ha="center",va="center",fontsize=14)
ax.text(6.5,.05,"Proportion mediated ≈ 5% (95% CI XX)",ha="center",fontsize=14,weight="bold")
plt.tight_layout(); plt.savefig(OUT+"Figure11_mock.png"); plt.close()

# ===== Figure 12: effect modification by lipid-lowering therapy =====
fig,ax=plt.subplots(figsize=(13,5.2),dpi=200)
rows=[("All patients (adjusted)",1.68,1.19,2.37),("On a statin",1.86,1.25,2.75),("No statin",1.10,.55,2.20),
      ("LDL-C < 70 mg/dL",1.62,.94,2.78),("LDL-C < 55 mg/dL",1.19,.46,3.10)]
forest(ax,rows,[HI,HI,"#bbbbbb",HI,HI],(.3,16),5.6,"HR (95% CI)","Hazard ratio for MACE, discordantly high apoB vs others")
ne=["800 / 183","482 / 127","XX","205 / 62","84 / 25"]
for i,t in enumerate(ne): ax.text(10.5,len(rows)-1-i,t,va="center",fontsize=12)
ax.text(10.5,len(rows)-.45,"n / events",fontsize=12,weight="bold")
ax.text(.0,-.2,"Grey: 'No statin' estimate illustrative (to be computed). p for interaction statin × discordance: XX.",transform=ax.transAxes,fontsize=11,color="#b00020")
plt.tight_layout(); plt.savefig(OUT+"Figure12_mock.png"); plt.close()

# ===== Figure 13: robustness to LDL-C heterogeneity within the concordant group (illustrative) =====
fig,ax=plt.subplots(figsize=(13,5.2),dpi=200)
rows=[("Groups (main model)",1.68,1.19,2.37),("Groups + LDL-C (spline, 3 df)",1.71,1.20,2.44),
      ("Percentile gap per SD + LDL-C",1.27,1.10,1.46),("ApoB per SD | LDL-C per SD",1.55,1.12,2.15),
      ("LDL-C per SD | apoB per SD",0.80,0.58,1.10)]
forest(ax,rows,[HI,"#bbbbbb","#bbbbbb","#bbbbbb","#bbbbbb"],(.3,8),4.4,"HR (95% CI)","Adjusted hazard ratio for MACE")
ax.text(.0,-.2,"Only the main model (orange) is real. Grey estimates are placeholders for the concordant-heterogeneity checks.",
        transform=ax.transAxes,fontsize=11,color="#b00020")
plt.tight_layout(); plt.savefig(OUT+"Figure13_mock.png"); plt.close()

# ===== Figure 14: planned APOE and diet analyses (no data yet) =====
fig,axs=plt.subplots(1,2,figsize=(16,6.3),dpi=200)
ax=axs[0]
L=["APOE ε2 carrier\n(n = XX)","ε3/ε3\n(n = XX)","ε4 carrier\n(n = XX)"]
hi_=[11,17,23]; lo_=[27,18,14]; x=np.arange(3)
ax.bar(x-.2,hi_,.38,color=HI,label="Discordantly high apoB"); ax.bar(x+.2,lo_,.38,color=LO,label="Discordantly low apoB")
for i in range(3): ax.text(i-.2,hi_[i]+.6,f"{hi_[i]}%",ha="center",fontsize=12); ax.text(i+.2,lo_[i]+.6,f"{lo_[i]}%",ha="center",fontsize=12)
ax.set_xticks(x); ax.set_xticklabels(L); ax.set_ylim(0,35); ax.set_ylabel("Prevalence (%)"); clean(ax)
ax.legend(frameon=False,loc="lower center",bbox_to_anchor=(.5,1.02),ncol=2,fontsize=12); wm(ax,"PLANNED · NO DATA YET"); tag(ax,"A")
ax=axs[1]
L=["T1\n(lowest)","T2","T3\n(highest)"]; m=[4,1,-3]; e=[2.2,2.1,2.3]
ax.errorbar(range(3),m,yerr=e,fmt="o",c="black",ms=10,capsize=5,lw=2); ax.axhline(0,ls="--",c="#555",lw=1)
ax.set_xticks(range(3)); ax.set_xticklabels(L); ax.set_xlim(-.5,2.5)
ax.set(xlabel="Diet-quality score (FFQ2), tertile",ylabel="Adjusted mean percentile gap (95% CI)"); clean(ax)
wm(ax,"PLANNED · NO DATA YET"); tag(ax,"B")
plt.tight_layout(); plt.savefig(OUT+"Figure14_mock.png"); plt.close()
print("ok")
