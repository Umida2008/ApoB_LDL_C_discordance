import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
plt.rcParams.update({"font.size":13,"axes.edgecolor":"black","text.color":"black","axes.labelcolor":"black",
                     "xtick.color":"black","ytick.color":"black","font.family":"DejaVu Sans"})
OUT="/mnt/user-data/outputs/mock_results/"
GR,HI,LO,INK="#9a9a9a","#D55E00","#0072B2","#111111"
def wm(ax,txt="ILLUSTRATIVE DATA",loc="tr"):
    x,ha=(.99,"right") if loc[1]=="r" else (.01,"left"); y,va=(.99,"top") if loc[0]=="t" else (.01,"bottom")
    ax.text(x,y,txt,transform=ax.transAxes,ha=ha,va=va,fontsize=9,color="#b00020",weight="bold",
            bbox=dict(fc="white",ec="#b00020",lw=.8,alpha=.92),zorder=20)
def tag(ax,s,x=-.12): ax.text(x,1.04,s,transform=ax.transAxes,fontsize=20,weight="bold")
def clean(ax):
    for s in ("top","right"): ax.spines[s].set_visible(False)
def sup(fig,t): fig.suptitle(t,x=.01,ha="left",fontsize=16,weight="bold")
rng=np.random.default_rng(2026)

# ===== 15  guideline goal pairs are not percentile-equivalent (quartiles REAL) =====
fig,axs=plt.subplots(1,2,figsize=(17,7),dpi=200,gridspec_kw={"width_ratios":[1.1,1]})
ax=axs[0]
q_l=np.array([69,91,123]); q_b=np.array([65,81,100])        # observed Q1/median/Q3
xl=np.linspace(10,170,200); xb=np.interp(xl,q_l,q_b,left=None,right=None)
sl,ib=np.polyfit(q_l,q_b,1); ext=sl*xl+ib
ax.plot(xl,ext,ls="--",c="#777",lw=1.5)
ax.plot(q_l,q_b,"-",c=INK,lw=3.5,solid_capstyle="round",label="Cohort equipercentile line (observed Q1–Q3)")
ax.scatter(q_l,q_b,s=70,c=INK,zorder=4)
for (L,B,nm) in ((55,65,"Very high risk"),(70,80,"High risk"),(100,100,"Moderate risk")):
    ax.scatter(L,B,marker="*",s=420,c=HI,ec="white",lw=1,zorder=5)
    eq=sl*L+ib; ax.annotate("",xy=(L,eq),xytext=(L,B),arrowprops=dict(arrowstyle="-",ls=":",color=HI,lw=1.6))
    ax.text(L-3,B+4,f"{nm}\nLDL-C {L} ↔ apoB {B}",fontsize=11.5,color=HI,weight="bold",ha="right")
ax.set(xlim=(10,170),ylim=(40,140),xlabel="LDL-C (mg/dL)",ylabel="ApoB (mg/dL)"); clean(ax)
ax.legend(handles=[Line2D([],[],c=INK,lw=3.5,label="Equipercentile line (observed quartiles)"),
                   Line2D([],[],c="#777",ls="--",label="Linear extension"),
                   Line2D([],[],marker="*",ls="",c=HI,ms=17,label="ESC/EAS goal pairs")],frameon=False,loc="lower right",fontsize=11.5)
ax.text(.02,.97,"Star above the line: apoB goal more lenient than the paired LDL-C goal\n(i.e., set at a higher cohort percentile)",
        transform=ax.transAxes,va="top",fontsize=11.5)
tag(ax,"A")
ax=axs[1]
rows=[("Very high risk\nLDL-C < 55 | apoB < 65",10.6,25),("High risk\nLDL-C < 70 | apoB < 80",25.8,48)]
for i,(lab,l,b) in enumerate(rows):
    y=1-i; ax.plot([l,b],[y,y],c="#ccc",lw=8,solid_capstyle="round",zorder=1)
    ax.scatter(l,y,s=260,c=INK,zorder=3); ax.scatter(b,y,s=260,c=HI,zorder=3)
    ax.text(l,y+.17,f"{l:.1f}%",ha="center",fontsize=13,weight="bold")
    ax.text(b,y+.17,f"≈{b}%",ha="center",fontsize=13,weight="bold",color=HI)
ax.set_yticks([1,0]); ax.set_yticklabels([r[0] for r in rows],fontsize=12.5); ax.set_ylim(-.6,1.6); ax.set_xlim(0,60)
ax.set_xlabel("Patients at goal (%)"); clean(ax); ax.grid(axis="x",c="#eee")
ax.legend(handles=[Line2D([],[],marker="o",ls="",c=INK,ms=13,label="At LDL-C goal"),
                   Line2D([],[],marker="o",ls="",c=HI,ms=13,label="At apoB goal")],frameon=False,loc="lower right",fontsize=12)
ax.text(0,-.2,"apoB % approximated from observed quartiles (Q1 65, median 81 mg/dL); exact values XX",transform=ax.transAxes,fontsize=10.5)
tag(ax,"B",-.3)
sup(fig,"Guideline LDL-C and apoB goals are not percentile-equivalent in patients referred for angiography")
plt.tight_layout(rect=(0,0,1,.95)); plt.savefig(OUT+"Figure15_mock.png"); plt.close()

# ===== 16  joint risk surface =====
fig,axs=plt.subplots(1,2,figsize=(17,7),dpi=200,gridspec_kw={"width_ratios":[1.15,1]})
ax=axs[0]; g=np.linspace(0,100,201); L,B=np.meshgrid(g,g)
lp=-1.9+0.022*(B-50)+0.003*(L-50)+0.00012*(B-50)**2*np.sign(B-50)
risk=100/(1+np.exp(-lp))
cmap=LinearSegmentedColormap.from_list("o",["#f7f7f7","#fde0c5","#f4a261","#D55E00","#7a2b00"])
cf=ax.contourf(L,B,risk,levels=np.arange(6,46,2),cmap=cmap)
cs=ax.contour(L,B,risk,levels=[10,15,20,25,30,35],colors=INK,linewidths=.9)
ax.clabel(cs,fmt="%d%%",fontsize=11)
for o in (10,-10): ax.plot([0,100],[o,100+o],ls="--",c="white",lw=1.6)
ax.plot([0,100],[0,100],c="white",lw=.8)
ax.set(xlabel="LDL-C percentile",ylabel="ApoB percentile",xlim=(0,100),ylim=(0,100)); ax.set_aspect("equal")
cb=fig.colorbar(cf,ax=ax,fraction=.046,pad=.03); cb.set_label("Predicted 3-year MACE (%)")
ax.text(22,78,"discordantly\nhigh apoB",color="white",fontsize=12,weight="bold",va="top",ha="center")
wm(ax,"ILLUSTRATIVE · tensor-spline Cox model","br"); tag(ax,"A")
ax=axs[1]; x=np.linspace(0,100,200)
for fix,c,lab in ((30,HI,"ApoB varies (LDL-C fixed at 30th pct)"),(30,LO,"LDL-C varies (apoB fixed at 30th pct)")):
    if c==HI: lp1=-1.9+0.022*(x-50)+0.003*(fix-50)+0.00012*(x-50)**2*np.sign(x-50)
    else:     lp1=-1.9+0.022*(fix-50)+0.003*(x-50)+0.00012*(fix-50)**2*np.sign(fix-50)
    r=100/(1+np.exp(-lp1)); se=1.5+2.5*np.abs(x-30)/70
    ax.fill_between(x,r-se,r+se,color=c,alpha=.15,lw=0); ax.plot(x,r,c=c,lw=3,label=lab)
ax.set(xlabel="Percentile of the varying marker",ylabel="Predicted 3-year MACE (%)",xlim=(0,100),ylim=(0,45)); clean(ax)
ax.legend(frameon=False,loc="upper left",fontsize=12); ax.grid(c="#eee")
ax.text(98,3,"Risk follows apoB,\nnot LDL-C",ha="right",fontsize=14,weight="bold")
wm(ax,"ILLUSTRATIVE","tr"); tag(ax,"B")
sup(fig,"Joint distribution of apoB and LDL-C and 3-year MACE: risk tracks particle number")
plt.tight_layout(rect=(0,0,1,.95)); plt.savefig(OUT+"Figure16_mock.png"); plt.close()

# ===== 17  Sankey: LDL-C goal -> apoB goal -> MACE =====
def flow(ax,x0,x1,y0a,y0b,y1a,y1b,c,a=.45):
    t=np.linspace(0,1,100); s=3*t**2-2*t**3; xx=x0+(x1-x0)*t
    ax.fill_between(xx,y0a+(y1a-y0a)*s,y0b+(y1b-y0b)*s,color=c,alpha=a,lw=0)
fig,ax=plt.subplots(figsize=(16,8.5),dpi=200); ax.axis("off"); ax.set_xlim(-.3,3.6); ax.set_ylim(-60,990)
N=926; gap=40
L=[("LDL-C < 70 mg/dL",239,"#4d4d4d"),("LDL-C ≥ 70 mg/dL",687,"#bdbdbd")]
combo={(0,0):178,(0,1):61,(1,0):262,(1,1):425}        # (ldl,apob) counts; apoB goal 80 mg/dL
mace={(0,0):13,(0,1):31,(1,0):18,(1,1):25}
colB={0:LO,1:HI}
# left nodes
yl=[];y=N+2*gap
for nm,n,c in L:
    ax.add_patch(Rectangle((0,y-n),.08,n,fc=c,ec="none")); ax.text(-.03,y-n/2,f"{nm}\nn = {n}",ha="right",va="center",fontsize=13,weight="bold")
    yl.append(y); y-=n+gap
# middle nodes: ordered (0,0),(0,1),(1,0),(1,1)
order=[(0,0),(0,1),(1,0),(1,1)]
labs={(0,0):"LDL-C & apoB at goal",(0,1):"LDL-C at goal,\napoB ABOVE goal",(1,0):"LDL-C above,\napoB at goal",(1,1):"Both above goal"}
ym={};y=N+3*gap
for k in order:
    n=combo[k]; ym[k]=y; ax.add_patch(Rectangle((1.5,y-n),.08,n,fc=colB[k[1]],ec="none"))
    ax.text(1.62,y-n/2,f"{labs[k]}  ({n})",va="center",fontsize=12.5,weight="bold" if k==(0,1) else "normal",color=HI if k==(0,1) else INK)
    y-=n+gap
# flows left->middle
off={0:0,1:0}
for k in order:
    n=combo[k]; l=k[0]; a0=yl[l]-off[l]; off[l]+=n
    flow(ax,.08,1.5,a0,a0-n,ym[k],ym[k]-n,colB[k[1]],.55 if k==(0,1) else .3)
# right: MACE bars
for k in order:
    n=combo[k]; yc=ym[k]-n/2; r=mace[k]
    ax.add_patch(Rectangle((2.75,yc-22),.75,44,fc="#eeeeee",ec="none"))
    ax.add_patch(Rectangle((2.75,yc-22),.75*r/40,44,fc=HI if k[1] else LO,ec="none"))
    ax.text(2.75+.75*r/40+.03,yc,f"{r}%",va="center",fontsize=14,weight="bold")
ax.text(.04,N+3*gap+45,"LDL-C status",ha="center",fontsize=14,weight="bold")
ax.text(1.54,N+3*gap+45,"ApoB status (goal < 80 mg/dL)",ha="center",fontsize=14,weight="bold")
ax.text(3.12,N+3*gap+45,"3-year MACE",ha="center",fontsize=14,weight="bold")
ax.text(1.3,-45,"61/239 patients at LDL-C goal are NOT at apoB goal — and carry the highest event rate",
        ha="center",fontsize=13,style="italic")
wm(ax,"ILLUSTRATIVE except n = 926 / 239","br")
plt.tight_layout(); plt.savefig(OUT+"Figure17_mock.png"); plt.close()

# ===== 18  incremental prognostic value =====
fig,axs=plt.subplots(1,3,figsize=(19,6.5),dpi=200,gridspec_kw={"width_ratios":[1.1,1,1]})
ax=axs[0]
M=[("Clinical model",.651,.612,.690,"#bdbdbd"),("+ LDL-C",.653,.614,.692,"#8c8c8c"),
   ("+ apoB",.672,.634,.710,HI),("+ discordance group",.676,.638,.714,"#7a2b00")]
for i,(n,c,lo,hi,col) in enumerate(M):
    y=len(M)-1-i; ax.plot([lo,hi],[y,y],c=col,lw=3); ax.scatter(c,y,s=150,c=col,zorder=3,ec="white")
    ax.text(.735,y,f"{c:.3f}"+("" if i==0 else f"   Δ {c-M[0][1]:+.3f}"),va="center",fontsize=12.5)
ax.set_yticks(range(len(M))); ax.set_yticklabels([m[0] for m in M][::-1],fontsize=12.5)
ax.set_xlim(.6,.8); ax.set_xlabel("Harrell's C (95% CI)"); clean(ax); ax.grid(axis="x",c="#eee")
ax.text(.735,len(M)-.45,"C     ΔC vs clinical",fontsize=12,weight="bold"); ax.set_ylim(-.6,len(M)-.1)
wm(ax,"ILLUSTRATIVE","br"); tag(ax,"A",-.36)
ax=axs[1]; p=np.linspace(.08,.42,10); o1=p*1.0+rng.normal(0,.012,10); o0=.21+(p-.21)*.55+rng.normal(0,.01,10)
ax.plot([0,.5],[0,.5],c="#777",ls="--",lw=1)
ax.plot(p,o0,"o-",c="#8c8c8c",lw=2,ms=8,label="Clinical + LDL-C")
ax.plot(p,o1,"o-",c=HI,lw=2.5,ms=9,label="Clinical + apoB")
ax.set(xlim=(0,.5),ylim=(0,.5),xlabel="Predicted 3-year risk (decile mean)",ylabel="Observed 3-year risk (KM)"); ax.set_aspect("equal")
ax.legend(frameon=False,loc="upper left",fontsize=12); clean(ax); wm(ax,"ILLUSTRATIVE","br"); tag(ax,"B")
ax=axs[2]
cats=["Events\nreclassified up","Non-events\nreclassified down"]; up=[14.2,6.1]; dn=[5.5,3.9]
x=np.arange(2)
ax.bar(x-.18,up,.34,color=HI,label="Correctly"); ax.bar(x+.18,dn,.34,color="#bdbdbd",label="Incorrectly")
for i in range(2): ax.text(i-.18,up[i]+.4,f"{up[i]}%",ha="center",fontsize=12.5,weight="bold"); ax.text(i+.18,dn[i]+.4,f"{dn[i]}%",ha="center",fontsize=12.5)
ax.set_xticks(x); ax.set_xticklabels(cats); ax.set_ylim(0,20); ax.set_ylabel("Patients (%)"); clean(ax)
ax.legend(frameon=False,fontsize=12,loc="upper right")
ax.set_title("Categorical NRI (10/20%): +10.9% (XX–XX)",fontsize=12.5,weight="bold")
wm(ax,"ILLUSTRATIVE","bl"); tag(ax,"C")
sup(fig,"Does apoB add prognostic information beyond a clinical model with LDL-C?")
plt.tight_layout(rect=(0,0,1,.93)); plt.savefig(OUT+"Figure18_mock.png"); plt.close()

# ===== 19  decision-curve analysis =====
fig,ax=plt.subplots(figsize=(13,7),dpi=200)
pt=np.linspace(.05,.45,200); prev=.229
nb_all=prev-(1-prev)*pt/(1-pt)
def nb(sens,spec): return sens*prev-(1-spec)*(1-prev)*pt/(1-pt)
s1=np.clip(.80-.9*(pt-.05),.2,1); s2=np.clip(.86-.75*(pt-.05),.3,1)
ax.plot(pt,0*pt,c=INK,lw=1.4,label="Intensify in no one")
ax.plot(pt,nb_all,c="#bdbdbd",lw=2.5,label="Intensify in all")
ax.plot(pt,nb(.64,.42+.6*pt),c=LO,lw=3,label="LDL-C-guided (LDL-C ≥ 55 mg/dL)")
ax.plot(pt,nb(s2,.55+.6*pt),c=HI,lw=3.5,label="apoB-guided (apoB ≥ 65 mg/dL)")
ax.fill_between(pt,nb(.64,.42+.6*pt),nb(s2,.55+.6*pt),where=nb(s2,.55+.6*pt)>nb(.64,.42+.6*pt),color=HI,alpha=.12,lw=0)
ax.set(xlim=(.05,.45),ylim=(-.05,.2),xlabel="Threshold probability for treatment intensification (3-year MACE)",ylabel="Net benefit")
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v,_: f"{100*v:.0f}%"))
ax.legend(frameon=False,fontsize=12.5,loc="upper right"); clean(ax); ax.grid(c="#eee")
ax.text(.30,.135,"Shaded: net benefit of apoB-guided\nover LDL-C-guided intensification",fontsize=12.5,color=HI)
wm(ax,"ILLUSTRATIVE","bl")
ax.set_title("Clinical utility: decision-curve analysis of apoB- vs LDL-C-guided intensification",loc="left",fontsize=15,weight="bold")
plt.tight_layout(); plt.savefig(OUT+"Figure19_mock.png"); plt.close()

# ===== 20  "then what": closing the apoB gap =====
fig,axs=plt.subplots(1,2,figsize=(17,7),dpi=200,gridspec_kw={"width_ratios":[1.1,1]})
ax=axs[0]; ab=65+np.abs(rng.gamma(2.2,7.5,65))
ax.hist(ab,bins=np.arange(60,130,4),color=HI,alpha=.85,ec="white")
ax.axvline(65,c=INK,lw=2); ax.text(65.8,15.3,"apoB goal\n65 mg/dL",fontsize=12,weight="bold",va="top")
med=np.median(ab); ax.axvline(med,c=INK,ls="--",lw=1.3); ax.text(med+1,13,f"median {med:.0f} mg/dL\n(Δ {med-65:.0f} mg/dL to goal)",fontsize=12)
ax.set(xlabel="ApoB (mg/dL)",ylabel="Patients",xlim=(58,128),ylim=(0,16)); clean(ax)
ax.set_title("Discordantly high apoB at LDL-C < 70 mg/dL (n = 65)",loc="left",fontsize=13)
wm(ax,"DISTRIBUTION ILLUSTRATIVE · n real"); tag(ax,"A")
ax=axs[1]
steps=["Current\ntherapy","+ high-intensity\nstatin","+ ezetimibe","+ PCSK9\ninhibitor"]; reach=[0,34,61,94]
cols=["#d9d9d9","#f4a261","#e07b39",HI]
ax.bar(range(4),reach,.62,color=cols)
for i,v in enumerate(reach): ax.text(i,v+2,f"{v}%",ha="center",fontsize=15,weight="bold")
for i in range(3): ax.annotate("",xy=(i+.72,reach[i+1]*.5),xytext=(i+.28,reach[i]*.5+1),arrowprops=dict(arrowstyle="->",lw=1.6,color="#555"))
ax.set_xticks(range(4)); ax.set_xticklabels(steps,fontsize=12); ax.set_ylim(0,110); ax.set_ylabel("Reaching apoB < 65 mg/dL (%)"); clean(ax)
ax.text(.02,.97,"Expected apoB lowering per step: statin up-titration ≈ 15%,\nezetimibe ≈ 15%, PCSK9 inhibitor ≈ 50%\n→ ≈ XX MACE prevented per 1000 over 3 years\n   (HR 0.77 per 10 mg/dL lower apoB; Ference 2019)",
        transform=ax.transAxes,va="top",fontsize=11.5,bbox=dict(fc="#fdf0e8",ec=HI,lw=1))
wm(ax,"SIMULATION","br"); tag(ax,"B")
sup(fig,"Then what? Closing the apoB gap in patients already at LDL-C goal")
plt.tight_layout(rect=(0,0,1,.94)); plt.savefig(OUT+"Figure20_mock.png"); plt.close()

# ===== 21  phenotype fingerprint (standardised differences) =====
V=[("Lipids","LDL-C/apoB ratio",-1.85,1.62),("Lipids","Triglycerides (log)",.28,-.24),("Lipids","HDL-C",-.46,.52),
   ("Lipids","Lp(a) (log)",.42,-.33),("Lipids","Remnant cholesterol",.31,-.27),
   ("Metabolic","HbA1c",.24,-.15),("Metabolic","Waist-to-height ratio",.12,-.06),("Metabolic","Hepatic steatosis index",.19,-.12),
   ("Inflammation","CRP (log)",.33,-.11),("Inflammation","Leukocytes",.14,-.05),
   ("Organ","eGFR",-.03,.02),("Organ","TSH",.02,.04),
   ("Treatment","Statin use",.23,.02),("Treatment","High-intensity statin",.05,.11),
   ("Demography","Female sex",-.40,-.03),("Demography","Age",-.05,.07),
   ("Disease","Multivessel disease",.21,-.10),("Disease","Previous MI",.12,-.04)]
rows=[];prev=None
for v in V:
    if v[0]!=prev: rows.append((v[0].upper(),None,None)); prev=v[0]
    rows.append(("   "+v[1],v[2],v[3]))
Mx=np.array([[np.nan,np.nan] if r[1] is None else [r[1],r[2]] for r in rows])
fig,ax=plt.subplots(figsize=(10,13),dpi=200)
cm=LinearSegmentedColormap.from_list("d",[LO,"#cfe3f2","white","#f9d3b8",HI]); cm.set_bad("white")
im=ax.imshow(np.ma.masked_invalid(Mx),cmap=cm,norm=TwoSlopeNorm(0,-1,1),aspect="auto")
for i,r in enumerate(rows):
    if r[1] is None: continue
    for j in range(2):
        v=Mx[i,j]; ax.text(j,i,f"{v:+.2f}",ha="center",va="center",fontsize=12.5,color="white" if abs(v)>.8 else INK,weight="bold" if abs(v)>=.2 else "normal")
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows],fontsize=12.5)
for t,r in zip(ax.get_yticklabels(),rows):
    if r[1] is None: t.set_weight("bold"); t.set_color("#555")
ax.tick_params(axis="y",length=0)
ax.set_xticks([0,1]); ax.set_xticklabels(["High apoB\nvs concordant","Low apoB\nvs concordant"],fontsize=12.5); ax.xaxis.tick_top()
for i,r in enumerate(rows):
    if r[1] is None and i>0: ax.axhline(i-.5,c=INK,lw=1.2)
for sp in ax.spines.values(): sp.set_visible(False)
cb=fig.colorbar(im,ax=ax,fraction=.06,pad=.04,ticks=[-1,-.5,0,.5,1],shrink=.6); cb.set_label("Standardised mean difference (vs concordant)")
ax.set_title("Phenotypic fingerprint of apoB–LDL-C discordance",fontsize=15,weight="bold",pad=50)
fig.text(.02,.01,"ILLUSTRATIVE (directions match real medians)",color="#b00020",weight="bold",fontsize=10,
         bbox=dict(fc="white",ec="#b00020",lw=.8))
plt.tight_layout(rect=(0,.03,1,1)); plt.savefig(OUT+"Figure21_mock.png"); plt.close()

# ===== 22  ridgelines: cholesterol per particle =====
fig,axs=plt.subplots(1,2,figsize=(17,8),dpi=200)
def ridge(ax,groups,title):
    xx=np.linspace(.5,1.8,300)
    for i,(nm,mu,sd,c) in enumerate(groups):
        base=(len(groups)-1-i)*1.0; y=np.exp(-.5*((xx-mu)/sd)**2); y=y/y.max()*1.25
        ax.fill_between(xx,base,base+y,color=c,alpha=.8,lw=0,zorder=10-i); ax.plot(xx,base+y,c="white",lw=1.5,zorder=10-i)
        ax.plot([mu,mu],[base,base+1.25],c=INK,lw=1.2,zorder=11); ax.text(1.5,base+.15,nm,fontsize=12.5,weight="bold",zorder=12)
        ax.text(mu+.015,base+1.1,f"{mu:.2f}",fontsize=11.5,zorder=12)
    ax.axvline(1.0,c=INK,ls=":",lw=1.2); ax.set_yticks([]); ax.set_xlim(.5,1.8)
    ax.set_xlabel("LDL-C/apoB ratio  (cholesterol per particle)"); ax.set_title(title,loc="left",fontsize=14,weight="bold")
    for s in ("top","right","left"): ax.spines[s].set_visible(False)
ridge(axs[0],[("No lipid-lowering therapy",1.17,.13,"#cfcfcf"),("Moderate-intensity statin",1.08,.13,"#f4b183"),
              ("High-intensity statin",1.04,.14,"#e07b39"),("Statin + ezetimibe",1.00,.15,HI)],"By lipid-lowering therapy")
ridge(axs[1],[("Normoglycaemia",1.15,.13,"#cfcfcf"),("Prediabetes",1.10,.13,"#9ecae1"),
              ("Type 2 diabetes",1.03,.14,LO)],"By glycaemic status")
wm(axs[0],"ILLUSTRATIVE","tr"); wm(axs[1],"ILLUSTRATIVE","tr"); tag(axs[0],"A",-.03); tag(axs[1],"B",-.03)
sup(fig,"Statins and dysglycaemia shift LDL toward cholesterol-depleted particles")
plt.tight_layout(rect=(0,0,1,.94)); plt.savefig(OUT+"Figure22_mock.png"); plt.close()

# ===== 23  MACE components + time-varying HR =====
fig,axs=plt.subplots(1,2,figsize=(17,7),dpi=200,gridspec_kw={"width_ratios":[1,1.15]})
ax=axs[0]
G=[("Concordant",21.1,(9.6,7.0,4.5)),("Discordantly\nhigh apoB",38.3,(12.9,17.6,7.8)),("Discordantly\nlow apoB",16.0,(8.3,4.6,3.1))]
cc=["#4d4d4d",HI,"#f4b183"]; nm=["Death","Myocardial infarction","Stroke"]
for i,(g,tot,parts) in enumerate(G):
    b=0
    for k,v in enumerate(parts):
        ax.bar(i,v,.6,bottom=b,color=cc[k],ec="white",lw=1.2,label=nm[k] if i==0 else None)
        if v>4: ax.text(i,b+v/2,f"{v:.0f}",ha="center",va="center",color="white",fontsize=12,weight="bold")
        b+=v
    ax.text(i,b+1.2,f"{tot}%",ha="center",fontsize=14,weight="bold")
ax.set_xticks(range(3)); ax.set_xticklabels([g[0] for g in G],fontsize=12.5); ax.set_ylim(0,48)
ax.set_ylabel("First MACE component by 3 years (%)"); clean(ax)
ax.legend(frameon=False,loc="upper right",fontsize=12)
wm(ax,"SPLIT ILLUSTRATIVE · totals real","tl"); tag(ax,"A")
ax=axs[1]; t=np.linspace(.1,3,200); lhr=np.log(1.68)+.35-.25*t; se=.42-.06*t
ax.fill_between(t,np.exp(lhr-1.96*se),np.exp(lhr+1.96*se),color=HI,alpha=.15,lw=0)
ax.plot(t,np.exp(lhr),c=HI,lw=3,label="Time-varying HR (Schoenfeld residuals)")
ax.axhline(1.68,c=INK,ls="--",lw=1.4,label="Average adjusted HR 1.68")
ax.axhline(1,c="#777",lw=1)
ax.set_yscale("log"); ax.set_yticks([.5,1,2,4]); ax.set_yticklabels(["0.5","1","2","4"]); ax.minorticks_off()
ax.set(xlim=(0,3),ylim=(.5,5),xlabel="Years since index angiography",ylabel="HR, discordantly high vs concordant"); clean(ax)
ax.set_xticks([0,1,2,3]); ax.legend(frameon=False,fontsize=12,loc="upper right")
ax.text(.05,.6,"Global test for proportional hazards: p = XX",fontsize=12)
wm(ax,"CURVE ILLUSTRATIVE","bl"); tag(ax,"B")
sup(fig,"What drives the excess risk, and when?")
plt.tight_layout(rect=(0,0,1,.94)); plt.savefig(OUT+"Figure23_mock.png"); plt.close()

# ===== 24  subgroup forest with interaction p =====
S=[("Overall",None,1.68,1.19,2.37,800,183,None,True),
   ("Age","< 70 years",1.82,1.08,3.07,330,58,.58,False),("","≥ 70 years",1.59,1.03,2.45,470,125,None,False),
   ("Sex","Men",1.71,1.17,2.50,563,135,.71,False),("","Women",1.45,.62,3.40,237,48,None,False),
   ("Type 2 diabetes","No",1.49,.98,2.27,580,118,.31,False),("","Yes",2.07,1.18,3.63,220,65,None,False),
   ("CRP > 5 mg/L","No",1.42,.90,2.24,420,82,.19,False),("","Yes",2.21,1.27,3.85,150,52,None,False),
   ("Lp(a) ≥ 125 nmol/L","No",1.61,1.08,2.40,620,136,.66,False),("","Yes",1.89,1.00,3.57,180,47,None,False),
   ("Multivessel disease","No",1.75,.92,3.33,350,58,.88,False),("","Yes",1.64,1.09,2.47,450,125,None,False)]
fig,ax=plt.subplots(figsize=(15,9.5),dpi=200)
n=len(S); ax.set_xlim(-3.2,8.4); ax.set_ylim(-.8,n+.6); ax.axis("off")
xs=lambda v:(np.log(v)-np.log(.25))/(np.log(8)-np.log(.25))*4.6  # log scale -> 0..4.6
ax.plot([xs(1)]*2,[-.4,n-.4],c="#555",ls="--",lw=1)
for i,(g,s,e,lo,hi,nn,ev,pi,ov) in enumerate(S):
    y=n-1-i
    if i%2==0 and i>0: ax.add_patch(Rectangle((-3.2,y-.5),11.6,2,fc="#f6f6f6",ec="none",zorder=0))
    ax.text(-3.1,y,g,fontsize=12.5,weight="bold",va="center"); ax.text(-1.2,y,s,fontsize=12.5,va="center")
    ax.plot([xs(lo),xs(hi)],[y,y],c=INK if not ov else HI,lw=2)
    sz=40+ev*1.4
    ax.scatter(xs(e),y,s=sz if not ov else 260,marker="s" if not ov else "D",c=INK if not ov else HI,zorder=3)
    ax.text(5.0,y,f"{e:.2f} ({lo:.2f}–{hi:.2f})",fontsize=12,va="center",weight="bold" if ov else "normal")
    ax.text(6.9,y,f"{nn} / {ev}",fontsize=12,va="center")
    if pi is not None: ax.text(8.1,y-.5,f"{pi:.2f}",fontsize=12,va="center",ha="center")
for v in (.5,1,2,4): ax.text(xs(v),-.85,f"{v:g}",ha="center",fontsize=12); ax.plot([xs(v)]*2,[-.45,-.35],c=INK)
ax.plot([0,4.6],[-.4,-.4],c=INK,lw=1)
ax.text(xs(1),-1.5,"Hazard ratio for MACE, discordantly high apoB vs concordant",ha="center",fontsize=12.5)
for x,t in ((-3.1,"Subgroup"),(5.0,"HR (95% CI)"),(6.9,"n / events"),(8.1,"p-int")):
    ax.text(x,n+.15,t,fontsize=12.5,weight="bold",ha="center" if t=="p-int" else "left")
ax.text(-3.1,n+.85,"Consistency of the association across clinical subgroups",fontsize=15,weight="bold")
wm(ax,"ILLUSTRATIVE except overall","br")
plt.tight_layout(); plt.savefig(OUT+"Figure24_mock.png"); plt.close()
print("ok")
